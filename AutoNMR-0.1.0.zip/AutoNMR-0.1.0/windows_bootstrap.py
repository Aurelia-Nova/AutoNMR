"""Robust Windows installer bootstrap for Open NMR Workbench.

This file deliberately uses only the Python standard library.  It is launched
by ``install_windows.bat`` with a known-good base interpreter, repairs a
partially-created virtual environment when possible, and always invokes pip
through the virtual environment's absolute Python path.
"""

from __future__ import annotations

import argparse
import os
import platform
import shlex
import struct
import subprocess
import sys
import traceback
from datetime import datetime
from pathlib import Path
from typing import Iterable, TextIO


INSTALLER_REVISION = "0.3.0-r1"
MIN_PYTHON = (3, 10)
MAX_PYTHON = (3, 14)


class InstallFailure(RuntimeError):
    """Raised when an installation step cannot be completed safely."""


class InstallLog:
    def __init__(self, path: Path) -> None:
        self.path = path
        self._stream: TextIO | None = None

    def __enter__(self) -> "InstallLog":
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._stream = self.path.open("w", encoding="utf-8", newline="\n")
        return self

    def __exit__(self, *_args: object) -> None:
        if self._stream is not None:
            self._stream.close()
            self._stream = None

    def write(self, message: str = "") -> None:
        print(message, flush=True)
        if self._stream is not None:
            self._stream.write(message + "\n")
            self._stream.flush()


def venv_python_path(venv_dir: Path) -> Path:
    if os.name == "nt":
        return venv_dir / "Scripts" / "python.exe"
    return venv_dir / "bin" / "python"


def _format_command(command: Iterable[object]) -> str:
    return " ".join(shlex.quote(str(part)) for part in command)


def run_command(
    command: list[object],
    log: InstallLog,
    *,
    cwd: Path | None = None,
    check: bool = True,
) -> int:
    rendered = [str(part) for part in command]
    log.write(f"> {_format_command(rendered)}")
    environment = os.environ.copy()
    environment.setdefault("PYTHONUTF8", "1")
    environment.setdefault("PYTHONIOENCODING", "utf-8")
    process = subprocess.Popen(
        rendered,
        cwd=str(cwd) if cwd is not None else None,
        env=environment,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
        encoding="utf-8",
        errors="replace",
    )
    assert process.stdout is not None
    for raw_line in process.stdout:
        log.write(raw_line.rstrip("\r\n"))
    return_code = process.wait()
    if check and return_code:
        raise InstallFailure(
            f"Command failed with exit code {return_code}: "
            f"{_format_command(rendered)}"
        )
    return return_code


def validate_base_python(log: InstallLog) -> None:
    version = sys.version_info[:2]
    if not (MIN_PYTHON <= version <= MAX_PYTHON):
        raise InstallFailure(
            "A 64-bit Python version from 3.10 through 3.14 is required; "
            f"found {platform.python_version()}."
        )
    if struct.calcsize("P") * 8 != 64:
        raise InstallFailure("A 64-bit Python runtime is required.")
    try:
        import ensurepip  # noqa: F401
        import tkinter  # noqa: F401
        import venv  # noqa: F401
    except ImportError as exc:
        raise InstallFailure(
            "The selected Python is missing venv, ensurepip, or tkinter. "
            "Repair the standard 64-bit Python installation."
        ) from exc
    log.write(
        f"Base Python: {platform.python_version()} (64-bit) at "
        f"{Path(sys.executable).resolve()}"
    )


def python_starts(python_exe: Path, log: InstallLog) -> bool:
    if not python_exe.is_file():
        return False
    command = [python_exe, "-I", "-c", "import sys; print(sys.executable)"]
    return run_command(command, log, check=False) == 0


def pip_is_usable(python_exe: Path, log: InstallLog) -> bool:
    return (
        run_command(
            [python_exe, "-I", "-m", "pip", "--version"],
            log,
            check=False,
        )
        == 0
    )


def repair_pip(python_exe: Path, log: InstallLog) -> bool:
    log.write("pip is missing or unusabled; repairing it with ensurepip...")
    result = run_command(
        [python_exe, "-I", "-m", "ensurepip", "--upgrade", "--default-pip"],
        log,
        check=False,
    )
    if result != 0:
        return False
    return pip_is_usable(python_exe, log)


def backup_incomplete_venv(venv_dir: Path, log: InstallLog) -> Path:
    timestamp = datetime.now().strftime("%Y%m%d-%H%M%S")
    candidate = venv_dir.with_name(f"{venv_dir.name}-incomplete-{timestamp}")
    suffix = 1
    while candidate.exists():
        candidate = venv_dir.with_name(
            f"{venv_dir.name}-incomplete-{timestamp}-{suffix}"
        )
        suffix += 1
    venv_dir.rename(candidate)
    log.write(f"Preserved the incomplete environment as: {candidate}")
    return candidate


def ensure_virtual_environment(project_root: Path, log: InstallLog) -> Path:
    venv_dir = project_root / ".venv"
    python_exe = venv_python_path(venv_dir)

    if venv_dir.exists():
        log.write(f"Checking existing environment: {venv_dir}")
        if python_starts(python_exe, log):
            if pip_is_usable(python_exe, log) or repair_pip(python_exe, log):
                log.write("Existing environment is usable.")
                return python_exe
            log.write("The existing environment could not repair pip.")
        else:
            log.write("The existing environment cannot start at its current path.")
        backup_incomplete_venv(venv_dir, log)

    log.write(f"Creating a new isolated environment at: {venv_dir}")
    run_command(
        [sys.executable, "-I", "-m", "venv", str(venv_dir)],
        log,
        cwd=project_root,
    )
    python_exe = venv_python_path(venv_dir)
    if not python_starts(python_exe, log):
        raise InstallFailure("The new virtual environment cannot start.")
    if not pip_is_usable(python_exe, log) and not repair_pip(python_exe, log):
        raise InstallFailure(
            "The new virtual environment was created, but pip could not be "
            "bootstrapped with ensurepip."
        )
    return python_exe


def install_dependencies(
    project_root: Path, python_exe: Path, log: InstallLog
) -> None:
    requirements = project_root / "requirements.txt"
    pyproject = project_root / "pyproject.toml"
    if not requirements.is_file() or not pyproject.is_file():
        raise InstallFailure(
            "requirements.txt or pyproject.toml is missing from the application "
            "folder. Re-extract the complete package."
        )

    pip = [python_exe, "-I", "-m", "pip", "--disable-pip-version-check"]
    run_command(
        pip + ["install", "--upgrade", "pip", "setuptools", "wheel"],
        log,
        cwd=project_root,
    )
    run_command(
        pip
        + [
            "install",
            "--only-binary=:all:",
            "-r",
            str(requirements),
        ],
        log,
        cwd=project_root,
    )
    run_command(
        pip
        + [
            "install",
            "--no-deps",
            "--no-build-isolation",
            "-e",
            str(project_root),
        ],
        log,
        cwd=project_root,
    )
    run_command(
        [python_exe, "-I", "-m", "pip", "check"],
        log,
        cwd=project_root,
    )
    smoke_test = (
        "import sys, tkinter, numpy, scipy, matplotlib, rdkit, nmr_workbench; "
        "print('Python', sys.version.split()[0]); "
        "print('NumPy', numpy.__version__); "
        "print('SciPy', scipy.__version__); "
        "print('Matplotlib', matplotlib.__version__); "
        "print('RDKit', rdkit.__version__); "
        "print('Open NMR Workbench', nmr_workbench.__version__)"
    )
    run_command(
        [python_exe, "-I", "-c", smoke_test],
        log,
        cwd=project_root,
    )


def parse_args(argv: list[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("project_root", help="Extracted application folder")
    parser.add_argument(
        "--venv-only",
        action="store_true",
        help="Create/repair the environment and pip without downloading packages",
    )
    return parser.parse_args(argv)


def main(argv: list[str] | None = None) -> int:
    args = parse_args(argv)
    project_root = Path(args.project_root).expanduser().resolve()
    log_path = project_root / "install_log.txt"
    error_path = project_root / "install_error.txt"
    project_root.mkdir(parents=True, exist_ok=True)
    try:
        error_path.unlink(missing_ok=True)
    except OSError:
        pass

    with InstallLog(log_path) as log:
        log.write(f"Open NMR Workbench installer revision {INSTALLER_REVISION}")
        log.write(f"Application folder: {project_root}")
        try:
            validate_base_python(log)
            python_exe = ensure_virtual_environment(project_root, log)
            if not args.venv_only:
                install_dependencies(project_root, python_exe, log)
                marker = project_root / ".installation-ok"
                marker.write_text(
                    f"{INSTALLER_REVISION}\n{datetime.now().isoformat()}\n"
                    f"{python_exe}\n",
                    encoding="utf-8",
                )
            log.write("Installation environment is ready.")
            return 0
        except Exception as exc:
            details = traceback.format_exc()
            message = (
                f"Installation failed: {exc}\n\n{details}\n"
                f"Full log: {log_path}\n"
            )
            error_path.write_text(message, encoding="utf-8")
            log.write("")
            log.write(f"[ERROR] {exc}")
            log.write(f"Details were saved to: {error_path}")
            return 1


if __name__ == "__main__":
    raise SystemExit(main())
