import unittest

import numpy as np

from nmr_workbench.demo import generate_demo_fid
from nmr_workbench.processing import (
    ProcessingConfig,
    asymmetric_least_squares,
    process_fid,
    reference_spectrum,
)


class ProcessingTests(unittest.TestCase):
    def test_auto_phase_and_fft_axis(self):
        fid = generate_demo_fid(points=4096, phase0_deg=32.0)
        spectrum = process_fid(
            fid,
            ProcessingConfig(zero_fill_factor=2, baseline_method="asls"),
        )
        ph0 = spectrum.metadata["ph0_deg"]
        phase_error = abs(((ph0 + 32.0 + 180.0) % 360.0) - 180.0)
        self.assertLess(phase_error, 5.0)
        self.assertLess(abs(spectrum.metadata["ph1_deg"]), 8.0)
        self.assertGreater(spectrum.ppm[0], spectrum.ppm[-1])
        for expected in (4.12, 2.05, 1.26):
            mask = np.abs(spectrum.ppm - expected) < 0.025
            self.assertGreater(np.max(spectrum.intensity[mask]), np.percentile(spectrum.intensity, 95))

    def test_baseline_estimation(self):
        x = np.linspace(-1, 1, 3000)
        baseline = 0.4 + 0.2 * x + 0.1 * x**2
        peak = 4.0 * np.exp(-((x - 0.2) / 0.015) ** 2)
        estimated = asymmetric_least_squares(baseline + peak, lam=1e6, asymmetry=0.002)
        mask = np.abs(x - 0.2) > 0.08
        self.assertLess(np.sqrt(np.mean((estimated[mask] - baseline[mask]) ** 2)), 0.03)

    def test_reference_shift(self):
        fid = generate_demo_fid(points=1024, phase0_deg=0.0)
        spectrum = process_fid(fid, ProcessingConfig(auto_phase=False, baseline_method="none"))
        shifted = reference_spectrum(spectrum, observed_ppm=7.25, target_ppm=7.26)
        np.testing.assert_allclose(shifted.ppm - spectrum.ppm, 0.01)


if __name__ == "__main__":
    unittest.main()

