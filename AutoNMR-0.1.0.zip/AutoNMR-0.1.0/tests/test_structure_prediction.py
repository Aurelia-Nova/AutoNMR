import json
import tempfile
import unittest
from pathlib import Path

import numpy as np

from nmr_workbench.prediction import (
    predict_nmr,
    simulate_prediction_spectrum,
    write_prediction,
)
from nmr_workbench.structure import MoleculeGraph


def ethanol() -> MoleculeGraph:
    graph = MoleculeGraph()
    methyl = graph.add_atom("C", 0, 0)
    methylene = graph.add_atom("C", 1, 0)
    oxygen = graph.add_atom("O", 2, 0)
    graph.add_bond(methyl, methylene)
    graph.add_bond(methylene, oxygen)
    return graph


def aromatic_ring() -> tuple[MoleculeGraph, list[int]]:
    graph = MoleculeGraph()
    atoms = [graph.add_atom("C", index, 0, aromatic=True) for index in range(6)]
    for index in range(6):
        graph.add_bond(atoms[index], atoms[(index + 1) % 6], 1.5)
    return graph, atoms


class StructureGraphTests(unittest.TestCase):
    def test_formula_validation_and_roundtrip(self):
        graph = ethanol()
        self.assertEqual(graph.formula(), "C2H6O")
        self.assertTrue(graph.validate().valid)
        restored = MoleculeGraph.from_dict(json.loads(json.dumps(graph.to_dict())))
        self.assertEqual(restored.formula(), "C2H6O")
        self.assertEqual(len(restored.bonds), 2)

    def test_invalid_carbon_valence_is_reported(self):
        graph = MoleculeGraph()
        carbon = graph.add_atom("C", 0, 0)
        for index in range(5):
            neighbour = graph.add_atom("C", index + 1, 0)
            graph.add_bond(carbon, neighbour)
        result = graph.validate()
        self.assertFalse(result.valid)
        self.assertTrue(any("超过常见上限" in error for error in result.errors))

    def test_aromatic_formula_and_equivalence(self):
        graph, _ = aromatic_ring()
        self.assertEqual(graph.formula(), "C6H6")
        result = predict_nmr(graph, "13C")
        self.assertEqual(len(result.signals), 1)
        self.assertEqual(result.signals[0].integral, 6.0)


class PredictionTests(unittest.TestCase):
    def test_ethanol_proton_and_carbon_predictions(self):
        graph = ethanol()
        proton = predict_nmr(graph, "1H")
        self.assertEqual(len(proton.signals), 3)
        methyl = min(proton.signals, key=lambda item: abs(item.shift_ppm - 0.9))
        methylene = min(proton.signals, key=lambda item: abs(item.shift_ppm - 3.7))
        self.assertEqual((methyl.integral, methyl.multiplicity), (3.0, "t"))
        self.assertEqual((methylene.integral, methylene.multiplicity), (2.0, "q"))
        carbon = predict_nmr(graph, "13C")
        shifts = sorted(signal.shift_ppm for signal in carbon.signals)
        self.assertAlmostEqual(shifts[0], 14.0, delta=2.0)
        self.assertAlmostEqual(shifts[1], 63.0, delta=4.0)

    def test_carbonyl_carbon(self):
        graph = MoleculeGraph()
        left = graph.add_atom("C", 0, 0)
        carbonyl = graph.add_atom("C", 1, 0)
        oxygen = graph.add_atom("O", 1, -1)
        right = graph.add_atom("C", 2, 0)
        graph.add_bond(left, carbonyl)
        graph.add_bond(carbonyl, oxygen, 2.0)
        graph.add_bond(carbonyl, right)
        result = predict_nmr(graph, "13C")
        peak = max(result.signals, key=lambda item: item.shift_ppm)
        self.assertAlmostEqual(peak.shift_ppm, 205.0, delta=12.0)
        self.assertIn("酮羰基", peak.environment)

    def test_fluorine_and_phosphorus_predictions(self):
        fluoro, ring = aromatic_ring()
        fluorine = fluoro.add_atom("F", -1, 0)
        fluoro.add_bond(ring[0], fluorine)
        f_result = predict_nmr(fluoro, "19F")
        self.assertEqual(len(f_result.signals), 1)
        self.assertTrue(-175.0 <= f_result.signals[0].shift_ppm <= -90.0)

        phosphate = MoleculeGraph()
        phosphorus = phosphate.add_atom("P", 0, 0)
        oxygen = phosphate.add_atom("O", 0, -1)
        phosphate.add_bond(phosphorus, oxygen, 2.0)
        for index in range(3):
            linker = phosphate.add_atom("O", index + 1, 0)
            methyl = phosphate.add_atom("C", index + 1, 1)
            phosphate.add_bond(phosphorus, linker)
            phosphate.add_bond(linker, methyl)
        p_result = predict_nmr(phosphate, "31P")
        self.assertEqual(len(p_result.signals), 1)
        self.assertAlmostEqual(p_result.signals[0].shift_ppm, -1.0, delta=12.0)
        self.assertIn("磷酸", p_result.signals[0].environment)

    def test_spectrum_simulation_and_exports(self):
        result = predict_nmr(ethanol(), "1H", frequency_mhz=400.0)
        ppm, intensity = simulate_prediction_spectrum(result, points=2048)
        self.assertEqual(ppm.size, intensity.size)
        self.assertAlmostEqual(float(np.max(intensity)), 1.0)
        with tempfile.TemporaryDirectory() as folder:
            json_path = write_prediction(result, Path(folder) / "prediction.json")
            csv_path = write_prediction(result, Path(folder) / "prediction.csv")
            data = json.loads(json_path.read_text(encoding="utf-8"))
            self.assertEqual(data["formula"], "C2H6O")
            self.assertIn("shift_ppm", csv_path.read_text(encoding="utf-8-sig"))


if __name__ == "__main__":
    unittest.main()
