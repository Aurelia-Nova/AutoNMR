import sys
import unittest
from pathlib import Path

try:
    import tomllib
except ModuleNotFoundError:  # Python 3.10 compatibility
    tomllib = None


ROOT = Path(__file__).resolve().parents[1]


class Python314PackagingTests(unittest.TestCase):
    @unittest.skipIf(tomllib is None, "tomllib is built in from Python 3.11")
    def test_python_314_dependency_floor_and_version(self):
        assert tomllib is not None
        project = tomllib.loads((ROOT / "pyproject.toml").read_text(encoding="utf-8"))[
            "project"
        ]
        dependencies = "\n".join(project["dependencies"])
        self.assertEqual(project["version"], "0.3.0")
        self.assertEqual(project["requires-python"], ">=3.10,<3.15")
        self.assertIn("numpy>=2.4.3,<3; python_version >= '3.14'", dependencies)
        self.assertIn("scipy>=1.18.0,<2; python_version >= '3.14'", dependencies)
        self.assertIn("matplotlib>=3.11.1,<4; python_version >= '3.14'", dependencies)
        self.assertIn("rdkit>=2026.3.4,<2027; python_version >= '3.14'", dependencies)
        package_data = tomllib.loads((ROOT / "pyproject.toml").read_text(encoding="utf-8"))[
            "tool"
        ]["setuptools"]["package-data"]["nmr_workbench"]
        self.assertIn("data/locales/*.json", package_data)

    def test_windows_installer_prefers_python_314(self):
        installer = (ROOT / "install_windows.bat").read_text(encoding="utf-8")
        self.assertLess(
            installer.index("call :try_pymanager 3.14"),
            installer.index("call :try_pymanager 3.13"),
        )
        self.assertLess(
            installer.index("call :try_py 3.14"), installer.index("call :try_py 3.13")
        )
        self.assertIn("(3, 14)", installer)
        self.assertIn('set "APP_DIR=%~dp0"', installer)
        self.assertIn('set "APP_ROOT=%~dp0."', installer)
        self.assertIn('"%APP_DIR%windows_bootstrap.py"', installer)
        self.assertNotIn("activate.bat", installer)
        self.assertNotIn("python -m pip", installer)
        self.assertIn(":try_python_locator", installer)
        self.assertIn(":try_python_locator_install", installer)
        self.assertIn("-InstallIfMissing", installer)
        self.assertNotIn("CANDIDATE:\\WindowsApps\\=", installer)
        locator = (ROOT / "find_python.ps1").read_text(encoding="utf-8")
        self.assertIn("PythonSoftwareFoundation.PythonManager_", locator)
        self.assertIn("HKCU:\\Software\\Python", locator)
        self.assertIn("python_path.txt", locator)
        self.assertIn('Invoke-Manager $manager @("install", "--refresh")', locator)
        self.assertIn('Invoke-Manager $manager @("install", "3.14")', locator)
        self.assertIn("Get-Command $name -All -CommandType Application", locator)

    def test_windows_bootstrap_repairs_pip_and_uses_absolute_paths(self):
        bootstrap = (ROOT / "windows_bootstrap.py").read_text(encoding="utf-8")
        self.assertIn('"ensurepip", "--upgrade", "--default-pip"', bootstrap)
        self.assertIn('"pip", "--version"', bootstrap)
        self.assertIn("venv_dir.name}-incomplete-", bootstrap)
        self.assertIn("--only-binary=:all:", bootstrap)
        self.assertIn('"pip", "check"', bootstrap)
        self.assertIn("Path(args.project_root).expanduser().resolve()", bootstrap)
        self.assertNotIn("shell=True", bootstrap)

        runner = (ROOT / "run_windows.bat").read_text(encoding="utf-8")
        self.assertIn('set "APP_DIR=%~dp0"', runner)
        self.assertIn('"%APP_DIR%launcher.py"', runner)
        self.assertIn("run_error.txt", runner)

        builder = (ROOT / "build_windows_exe.bat").read_text(encoding="utf-8")
        self.assertIn('set "APP_DIR=%~dp0"', builder)
        self.assertIn('"%VENV_PYTHON%" -I -m PyInstaller', builder)
        self.assertNotIn("activate.bat", builder)

    @unittest.skipUnless(sys.version_info >= (3, 14), "Python 3.14 runtime smoke test")
    def test_imports_under_python_314(self):
        import matplotlib
        import numpy
        import rdkit
        import scipy

        self.assertGreaterEqual(
            tuple(map(int, numpy.__version__.split(".")[:2])), (2, 4)
        )
        self.assertGreaterEqual(
            tuple(map(int, scipy.__version__.split(".")[:2])), (1, 18)
        )
        self.assertGreaterEqual(
            tuple(map(int, matplotlib.__version__.split(".")[:2])), (3, 11)
        )
        self.assertGreaterEqual(
            tuple(map(int, rdkit.__version__.split(".")[:2])), (2026, 3)
        )


if __name__ == "__main__":
    unittest.main()
