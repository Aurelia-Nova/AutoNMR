import unittest

from nmr_workbench.formula import degree_of_unsaturation, formulas_equal, hydrogen_count, parse_formula


class FormulaTests(unittest.TestCase):
    def test_parse_and_hydrogen_count(self):
        self.assertEqual(parse_formula("C8H10ClNO"), {"C": 8, "H": 10, "Cl": 1, "N": 1, "O": 1})
        self.assertEqual(hydrogen_count("C4H8O2"), 8)

    def test_parentheses(self):
        self.assertEqual(parse_formula("C6H4(OH)2"), {"C": 6, "H": 6, "O": 2})

    def test_dbe_and_formula_comparison(self):
        self.assertAlmostEqual(degree_of_unsaturation("C8H8O"), 5.0)
        self.assertTrue(formulas_equal("C4H8O2", "H8C4O2"))
        self.assertFalse(formulas_equal("C4H8O2", "C4H10O"))

    def test_invalid_formula(self):
        with self.assertRaises(ValueError):
            parse_formula("C8H10??")


if __name__ == "__main__":
    unittest.main()

