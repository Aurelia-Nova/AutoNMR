import unittest

from nmr_workbench.analysis import AnalysisConfig, analyze_spectrum
from nmr_workbench.demo import generate_demo_spectrum


class AnalysisTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.spectrum = generate_demo_spectrum(points=32768)
        cls.report = analyze_spectrum(
            cls.spectrum,
            AnalysisConfig(molecular_formula="C4H8O2", snr_threshold=6.0),
        )

    def test_expected_signal_centers(self):
        centers = [signal.center_ppm for signal in self.report.signals]
        for expected in (7.26, 4.12, 2.05, 1.56, 1.26):
            self.assertLess(min(abs(value - expected) for value in centers), 0.015)

    def test_expected_multiplicities_and_couplings(self):
        q = min(self.report.signals, key=lambda item: abs(item.center_ppm - 4.12))
        t = min(self.report.signals, key=lambda item: abs(item.center_ppm - 1.26))
        self.assertEqual(q.multiplicity, "q")
        self.assertEqual(t.multiplicity, "t")
        self.assertAlmostEqual(q.coupling_hz[0], 7.1, delta=0.35)
        self.assertAlmostEqual(t.coupling_hz[0], 7.1, delta=0.35)

    def test_integrals_and_reference_matching(self):
        analyte = [
            min(self.report.signals, key=lambda item: abs(item.center_ppm - shift))
            for shift in (4.12, 2.05, 1.26)
        ]
        protons = [signal.estimated_protons for signal in analyte]
        for observed, expected in zip(protons, (2.0, 3.0, 3.0)):
            self.assertIsNotNone(observed)
            self.assertAlmostEqual(observed, expected, delta=0.25)
        solvent = min(self.report.signals, key=lambda item: abs(item.center_ppm - 7.26))
        water = min(self.report.signals, key=lambda item: abs(item.center_ppm - 1.56))
        self.assertEqual(solvent.reference_match.category, "residual solvent")
        self.assertEqual(water.reference_match.category, "water")

    def test_fragment_and_candidate(self):
        self.assertTrue(any("乙基" in item.label for item in self.report.fragments))
        self.assertGreater(len(self.report.candidates), 0)
        self.assertEqual(self.report.candidates[0].name, "乙酸乙酯")
        self.assertGreater(self.report.candidates[0].score, 95.0)


if __name__ == "__main__":
    unittest.main()

