import os
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
BOOTSTRAP = ROOT / "windows_bootstrap.py"


def venv_python(venv_dir: Path) -> Path:
    if os.name == "nt":
        return venv_dir / "Scripts" / "python.exe"
    return venv_dir / "bin" / "python"


class WindowsBootstrapTests(unittest.TestCase):
    def test_repairs_missing_pip_in_chinese_deep_path(self):
        with tempfile.TemporaryDirectory() as temporary:
            project_root = (
                Path(temporary)
                / "E盘 解谱OpenNMRWorkbench"
                / "解谱OpenNMRWorkbench-0.3.0-Python-3.14-Extensible"
            )
            project_root.mkdir(parents=True)
            environment = project_root / ".venv"
            subprocess.run(
                [sys.executable, "-m", "venv", "--without-pip", str(environment)],
                check=True,
                capture_output=True,
                text=True,
            )
            python_exe = venv_python(environment)
            before = subprocess.run(
                [str(python_exe), "-I", "-m", "pip", "--version"],
                capture_output=True,
                text=True,
            )
            self.assertNotEqual(before.returncode, 0)

            repaired = subprocess.run(
                [
                    sys.executable,
                    "-I",
                    str(BOOTSTRAP),
                    str(project_root),
                    "--venv-only",
                ],
                check=False,
                capture_output=True,
                text=True,
            )
            self.assertEqual(repaired.returncode, 0, repaired.stdout + repaired.stderr)
            after = subprocess.run(
                [str(python_exe), "-I", "-m", "pip", "--version"],
                check=False,
                capture_output=True,
                text=True,
            )
            self.assertEqual(after.returncode, 0, after.stdout + after.stderr)
            self.assertFalse(list(project_root.glob(".venv-incomplete-*")))
            log = (project_root / "install_log.txt").read_text(encoding="utf-8")
            self.assertIn("repairing it with ensurepip", log)
            self.assertIn("Existing environment is usable", log)

            broken_python = python_exe.with_name("python.broken")
            python_exe.rename(broken_python)
            rebuilt = subprocess.run(
                [
                    sys.executable,
                    "-I",
                    str(BOOTSTRAP),
                    str(project_root),
                    "--venv-only",
                ],
                check=False,
                capture_output=True,
                text=True,
            )
            self.assertEqual(rebuilt.returncode, 0, rebuilt.stdout + rebuilt.stderr)
            backups = list(project_root.glob(".venv-incomplete-*"))
            self.assertEqual(len(backups), 1)
            scripts_dir = "Scripts" if os.name == "nt" else "bin"
            self.assertTrue((backups[0] / scripts_dir / "python.broken").exists())
            final_check = subprocess.run(
                [str(venv_python(environment)), "-I", "-m", "pip", "--version"],
                check=False,
                capture_output=True,
                text=True,
            )
            self.assertEqual(
                final_check.returncode, 0, final_check.stdout + final_check.stderr
            )


if __name__ == "__main__":
    unittest.main()
