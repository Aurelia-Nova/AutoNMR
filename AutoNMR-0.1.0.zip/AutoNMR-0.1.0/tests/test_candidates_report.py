import json
import tempfile
import unittest
from pathlib import Path

from nmr_workbench import __version__
from nmr_workbench.analysis import AnalysisConfig, analyze_spectrum
from nmr_workbench.candidates import load_candidate_library
from nmr_workbench.demo import generate_demo_spectrum
from nmr_workbench.report import write_report


class CandidateAndReportTests(unittest.TestCase):
    def test_custom_candidate_library(self):
        payload = [
            {
                "name": "test",
                "formula": "C2H6O",
                "smiles": "CCO",
                "signals": [
                    {"shift": 3.6, "multiplicity": "q", "protons": 2},
                    {"shift": 1.2, "multiplicity": "t", "protons": 3},
                ],
            }
        ]
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / "candidates.json"
            path.write_text(json.dumps(payload), encoding="utf-8")
            candidates = load_candidate_library(path)
            self.assertEqual(candidates[0].name, "test")
            self.assertEqual(len(candidates[0].signals), 2)

    def test_html_and_json_report(self):
        spectrum = generate_demo_spectrum(points=8192)
        report = analyze_spectrum(spectrum, AnalysisConfig(molecular_formula="C4H8O2"))
        with tempfile.TemporaryDirectory() as folder:
            html_path = write_report(report, spectrum, Path(folder) / "report.html")
            json_path = write_report(report, spectrum, Path(folder) / "report.json")
            html_text = html_path.read_text(encoding="utf-8")
            data = json.loads(json_path.read_text(encoding="utf-8"))
            self.assertIn("NMR 自动解谱报告", html_text)
            self.assertIn("乙酸乙酯", html_text)
            self.assertIn(f"Open NMR Workbench {__version__}", html_text)
            self.assertEqual(data["candidates"][0]["name"], "乙酸乙酯")


if __name__ == "__main__":
    unittest.main()
