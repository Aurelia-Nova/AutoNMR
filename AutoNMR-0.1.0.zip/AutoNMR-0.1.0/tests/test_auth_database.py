import unittest
from pathlib import Path
from tempfile import TemporaryDirectory

from nmr_workbench.auth import AccountStore, AuthError, ScryptParameters, validate_password
from nmr_workbench.databases import (
    DatabaseProfile,
    DatabaseProfileError,
    DatabaseProfileStore,
    default_database_profiles,
)


class LocalAccountTests(unittest.TestCase):
    def setUp(self):
        self.now = [1_700_000_000]
        self.store = AccountStore(
            ":memory:",
            scrypt_parameters=ScryptParameters(n=2**14, r=8, p=1),
            time_function=lambda: self.now[0],
        )

    def tearDown(self):
        self.store.close()

    def test_registration_session_and_password_revocation(self):
        user = self.store.register("Chemist_01", "Long-Lab-Passphrase-42!", "chemist@example.org")
        self.assertEqual(user.role, "admin")
        result = self.store.authenticate("chemist_01", "Long-Lab-Passphrase-42!")
        self.assertTrue(result.success)
        session = self.store.create_session(user.id)
        self.assertEqual(self.store.validate_session(session.token).id, user.id)
        self.store.change_password(user.id, "Long-Lab-Passphrase-42!", "Another-Lab-Passphrase-73!")
        self.assertIsNone(self.store.validate_session(session.token))
        self.assertTrue(self.store.authenticate("Chemist_01", "Another-Lab-Passphrase-73!").success)
        events = {item["event"] for item in self.store.audit_events()}
        self.assertIn("password.changed", events)
        self.assertFalse(any("Passphrase" in str(item) for item in self.store.audit_events()))

    def test_duplicate_and_password_policy(self):
        self.store.register("chemist", "A-Laboratory-Passphrase-42!")
        with self.assertRaises(AuthError):
            self.store.register("CHEMIST", "Another-Laboratory-Pass-77!")
        with self.assertRaises(AuthError):
            validate_password("password123!")

    def test_rate_limit_locks_then_recovers(self):
        self.store.register("operator", "Valid-Laboratory-Pass-42!")
        for _ in range(self.store.MAX_FAILURES):
            result = self.store.authenticate("operator", "Incorrect-Lab-Pass-99!")
        self.assertGreater(result.retry_after_seconds, 0)
        blocked = self.store.authenticate("operator", "Valid-Laboratory-Pass-42!")
        self.assertFalse(blocked.success)
        self.now[0] += self.store.LOCK_SECONDS + 1
        self.assertTrue(self.store.authenticate("operator", "Valid-Laboratory-Pass-42!").success)


class DatabaseProfileTests(unittest.TestCase):
    def test_default_mainstream_profiles(self):
        ids = {item.id for item in default_database_profiles()}
        self.assertTrue({"pubchem", "nmrshiftdb2", "sdbs", "hmdb", "bmrb"}.issubset(ids))
        self.assertTrue({"reaxys", "scifinder-n"}.issubset(ids))

    def test_custom_template_encoding_and_security(self):
        profile = DatabaseProfile(
            id="lab-db",
            name="Laboratory DB",
            category="internal",
            home_url="https://spectra.example.org/",
            search_url="https://spectra.example.org/search?q={query}&smiles={smiles}",
            custom=True,
        )
        url = profile.build_url({"query": "ethyl acetate", "smiles": "CCOC(=O)C"})
        self.assertIn("ethyl%20acetate", url)
        self.assertIn("CCOC%28%3DO%29C", url)
        with self.assertRaises(DatabaseProfileError):
            DatabaseProfile(
                id="bad-db",
                name="Bad",
                category="test",
                home_url="http://example.org/",
            ).validated()
        with self.assertRaises(DatabaseProfileError):
            DatabaseProfile(
                id="bad-auth",
                name="Bad",
                category="test",
                home_url="https://user:secret@example.org/",
            ).validated()

    def test_lan_http_requires_explicit_opt_in_and_store_roundtrip(self):
        local = DatabaseProfile(
            id="local-db",
            name="Internal spectra",
            category="internal",
            home_url="http://192.168.1.30/",
            search_url="http://192.168.1.30/find?q={query}",
            custom=True,
            allow_insecure_local=True,
        ).validated()
        with TemporaryDirectory() as folder:
            store = DatabaseProfileStore(Path(folder) / "profiles.json")
            store.save([local])
            loaded = store.load()
        self.assertEqual(loaded[0].build_url("A/B"), "http://192.168.1.30/find?q=A%2FB")


if __name__ == "__main__":
    unittest.main()
