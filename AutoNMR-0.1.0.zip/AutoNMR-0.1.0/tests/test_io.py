import tempfile
import unittest
from pathlib import Path

import numpy as np

from nmr_workbench.demo import generate_demo_spectrum
from nmr_workbench.io import (
    read_bruker_fid,
    read_bruker_parameters,
    read_bruker_processed,
    read_csv_spectrum,
    save_spectrum_csv,
)


class IOTests(unittest.TestCase):
    def test_bruker_parameter_and_fid_reader(self):
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            (root / "acqus").write_text(
                "\n".join(
                    (
                        "##TITLE= test",
                        "##$BYTORDA= 0",
                        "##$DTYPA= 0",
                        "##$TD= 32",
                        "##$SW_h= 4000",
                        "##$SFO1= 400.13",
                        "##$O1= 2400.78",
                        "##$NUC1= <1H>",
                        "##$SOLVENT= <CDCl3>",
                        "##$GRPDLY= 0",
                        "##$TESTARR= (0..3)",
                        "1 2 3 4",
                        "##END=",
                    )
                ),
                encoding="latin-1",
            )
            raw = np.arange(32, dtype="<i4")
            raw.tofile(root / "fid")
            params = read_bruker_parameters(root / "acqus")
            self.assertEqual(params["TESTARR"], [1, 2, 3, 4])
            fid = read_bruker_fid(root)
            self.assertEqual(fid.data.size, 16)
            self.assertAlmostEqual(fid.dwell_time_s, 1 / 4000)
            self.assertAlmostEqual(fid.carrier_ppm, 6.0, places=4)
            self.assertEqual(fid.solvent, "CDCl3")

    def test_bruker_processed_reader(self):
        with tempfile.TemporaryDirectory() as folder:
            experiment = Path(folder) / "sample" / "1"
            pdata = experiment / "pdata" / "1"
            pdata.mkdir(parents=True)
            (experiment / "acqus").write_text(
                "##$NUC1= <1H>\n##$SOLVENT= <DMSO-d6>\n",
                encoding="latin-1",
            )
            (pdata / "procs").write_text(
                "##$BYTORDP= 0\n##$DTYPP= 0\n##$SI= 16\n##$SF= 400\n##$SW_p= 4000\n##$OFFSET= 10\n",
                encoding="latin-1",
            )
            np.arange(16, dtype="<i4").tofile(pdata / "1r")
            spectrum = read_bruker_processed(pdata / "1r")
            self.assertEqual(spectrum.intensity.size, 16)
            self.assertEqual(spectrum.solvent, "DMSO-d6")
            self.assertAlmostEqual(spectrum.ppm[0], 10.0)
            self.assertGreater(spectrum.ppm[0], spectrum.ppm[-1])

    def test_csv_roundtrip(self):
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / "spectrum.csv"
            original = generate_demo_spectrum(points=1024)
            save_spectrum_csv(original, path)
            loaded = read_csv_spectrum(path)
            self.assertEqual(loaded.ppm.size, original.ppm.size)
            np.testing.assert_allclose(loaded.ppm, original.ppm)
            np.testing.assert_allclose(loaded.intensity, original.intensity)


if __name__ == "__main__":
    unittest.main()

