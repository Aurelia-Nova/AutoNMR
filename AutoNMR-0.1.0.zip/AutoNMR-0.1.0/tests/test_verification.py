import unittest

from nmr_workbench.models import AnalysisReport, Peak, ReferenceMatch, Signal
from nmr_workbench.prediction import PredictionResult, PredictionSignal
from nmr_workbench.verification import verify_prediction


def _signal(shift: float, integral: float, multiplicity: str, reference=None) -> Signal:
    peak = Peak(shift, 1.0, 1.0, 1.0, 30.0, 0)
    return Signal(
        center_ppm=shift,
        start_ppm=shift + 0.02,
        end_ppm=shift - 0.02,
        peaks=[peak],
        area=integral,
        relative_integral=integral,
        estimated_protons=integral,
        multiplicity=multiplicity,
        coupling_hz=[7.1] if multiplicity in {"t", "q"} else [],
        region="test",
        reference_match=reference,
        confidence=90.0,
    )


class ExperimentalPredictionVerificationTests(unittest.TestCase):
    def test_perfect_assignment_excludes_solvent_and_reports_coverage(self):
        prediction = PredictionResult(
            nucleus="1H",
            solvent="CDCl3",
            frequency_mhz=400.0,
            formula="C2H6O",
            canonical_smiles="CCO",
            method="test",
            signals=[
                PredictionSignal("1H", (1,), 3.70, 2.0, "q", (7.1,), "OCH2", 90.0, 0.10),
                PredictionSignal("1H", (2,), 1.20, 3.0, "t", (7.1,), "CH3", 90.0, 0.10),
            ],
            warnings=[],
        )
        solvent = ReferenceMatch("CDCl3 residual", "residual solvent", [7.26], [7.26], 100.0)
        report = AnalysisReport(
            title="synthetic",
            nucleus="1H",
            solvent="CDCl3",
            spectrometer_mhz=400.0,
            noise_sigma=0.01,
            signals=[_signal(7.26, 1.0, "s", solvent), _signal(3.70, 2.0, "q"), _signal(1.20, 3.0, "t")],
            quality_score=95.0,
        )
        result = verify_prediction(prediction, report)
        self.assertEqual(len(result.assignments), 2)
        self.assertEqual(result.missing_predicted, [])
        self.assertEqual(result.unexplained_observed, [])
        self.assertAlmostEqual(result.predicted_coverage, 1.0)
        self.assertAlmostEqual(result.observed_coverage, 1.0)
        self.assertGreater(result.score, 98.0)
        self.assertAlmostEqual(result.shift_rmse, 0.0)

    def test_nucleus_mismatch_is_rejected(self):
        prediction = PredictionResult("13C", "CDCl3", 100.0, "C", "C", "test", [], [])
        report = AnalysisReport("sample", "1H", "CDCl3", 400.0, 0.0, [])
        with self.assertRaises(ValueError):
            verify_prediction(prediction, report)


if __name__ == "__main__":
    unittest.main()
