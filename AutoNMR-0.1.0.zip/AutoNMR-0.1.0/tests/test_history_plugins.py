import unittest
from pathlib import Path
from tempfile import TemporaryDirectory

from nmr_workbench.history import OperationHistory
from nmr_workbench.spectral_plugins import ReaderInfo, ReaderRegistry, SpectralPluginError


class OperationHistoryTests(unittest.TestCase):
    def test_undo_redo_and_new_branch(self):
        history = OperationHistory[str](max_entries=3, max_bytes=100)
        history.record("load", "empty", approximate_bytes=10)
        history.record("process", "raw", approximate_bytes=10)
        undone = history.undo("processed", approximate_bytes=10)
        self.assertEqual((undone.label, undone.state), ("process", "raw"))
        redone = history.redo("raw", approximate_bytes=10)
        self.assertEqual((redone.label, redone.state), ("process", "processed"))
        history.undo("processed", approximate_bytes=10)
        history.record("reference", "raw", approximate_bytes=10)
        self.assertFalse(history.can_redo)
        self.assertEqual(history.undo_label, "reference")

    def test_memory_and_entry_bounds_keep_latest_state(self):
        history = OperationHistory[int](max_entries=3, max_bytes=15)
        for index in range(6):
            history.record(str(index), index, approximate_bytes=10)
        self.assertTrue(history.can_undo)
        latest = history.undo(99, approximate_bytes=10)
        assert latest is not None
        self.assertEqual((latest.label, latest.state), ("5", 5))
        self.assertFalse(history.can_undo)


class _TextReader:
    info = ReaderInfo("test-reader", "Test reader", "mass_spectrometry", "TestCo", 5, (".mock",))

    def can_read(self, path: Path) -> bool:
        return path.suffix == ".mock"

    def read(self, path: Path) -> dict[str, str]:
        return {"modality": self.info.modality, "text": path.read_text(encoding="utf-8")}


class ReaderRegistryTests(unittest.TestCase):
    def test_registry_accepts_future_vendor_and_modality(self):
        registry = ReaderRegistry()
        registry.register(_TextReader())
        with TemporaryDirectory() as folder:
            path = Path(folder) / "sample.mock"
            path.write_text("m/z,intensity", encoding="utf-8")
            result = registry.read(path)
        self.assertEqual(result["modality"], "mass_spectrometry")
        self.assertEqual(result["text"], "m/z,intensity")

    def test_unknown_data_is_a_clear_plugin_error(self):
        with self.assertRaises(SpectralPluginError):
            ReaderRegistry().read("sample.unknown")


if __name__ == "__main__":
    unittest.main()
