import json
import unittest
from importlib.resources import files

from nmr_workbench.i18n import SUPPORTED_LANGUAGES, Translator, matplotlib_font_supports_cjk
from nmr_workbench.domain_i18n import domain_text
from nmr_workbench.references import reference_entries
from nmr_workbench.solvents import (
    canonical_solvent_id,
    deuterated_solvents,
    get_solvent,
    solvent_id_from_display,
    solvent_ids,
)


class SolventReferenceTests(unittest.TestCase):
    def test_supplied_literature_solvent_set_and_aliases(self):
        expected = {
            "THF-d8",
            "CD2Cl2",
            "CDCl3",
            "toluene-d8",
            "C6D6",
            "C6D5Cl",
            "acetone-d6",
            "DMSO-d6",
            "CD3CN",
            "TFE-d3",
            "CD3OD",
            "D2O",
        }
        self.assertEqual(set(solvent_ids()), expected)
        self.assertEqual(canonical_solvent_id("MeOD"), "CD3OD")
        self.assertEqual(canonical_solvent_id("benzene-d6"), "C6D6")
        self.assertEqual(solvent_id_from_display("TFE-d3 — 2,2,2-Trifluoroethanol-d3"), "TFE-d3")

    def test_residual_proton_carbon_and_water_values(self):
        thf = get_solvent("THF-d8")
        assert thf is not None
        self.assertEqual([item.shift for item in thf.residual["1H"]], [1.72, 3.58])
        self.assertEqual([item.shift for item in thf.residual["13C"]], [25.31, 67.21])
        self.assertAlmostEqual(thf.water_1h[0].shift, 2.46)
        carbon_entries = reference_entries("CDCl3", "13C")
        residual = next(item for item in carbon_entries if item.category == "residual solvent")
        self.assertEqual(residual.shifts, [77.16])

    def test_d2o_hod_is_not_duplicated(self):
        entries = reference_entries("D2O", "1H")
        overlapping = [
            item
            for item in entries
            if any(abs(value - 4.79) < 0.01 for value in item.shifts)
        ]
        self.assertEqual(len(overlapping), 1)
        self.assertEqual(overlapping[0].category, "water")

    def test_source_metadata_names_both_supplied_pdfs(self):
        payload = json.loads(
            files("nmr_workbench")
            .joinpath("data", "deuterated_solvents.json")
            .read_text(encoding="utf-8")
        )
        fulmer = payload["sources"]["fulmer_2010"]
        self.assertEqual(fulmer["doi"], "10.1021/om100106e")
        self.assertEqual(len(fulmer["attachments"]), 2)


class TranslationTests(unittest.TestCase):
    def test_locale_key_sets_match_and_switch(self):
        self.assertEqual(set(SUPPORTED_LANGUAGES), {"zh_CN", "en_US"})
        zh = Translator("zh_CN")
        en = Translator("en_US")
        zh_resource = files("nmr_workbench").joinpath("data", "locales", "zh_CN.json")
        en_resource = files("nmr_workbench").joinpath("data", "locales", "en_US.json")
        zh_keys = set(json.loads(zh_resource.read_text(encoding="utf-8")))
        en_keys = set(json.loads(en_resource.read_text(encoding="utf-8")))
        self.assertEqual(zh_keys, en_keys)
        self.assertEqual(zh.t("menu.file"), "文件")
        self.assertEqual(en.t("menu.file"), "File")
        self.assertEqual(en.t("status.undone", label="Process"), "Undone: Process")
        self.assertEqual(domain_text("脂肪烷基区", "en_US"), "aliphatic alkyl region")
        self.assertIn("paired t/q", domain_text("同一 J≈7.1 Hz 的 t/q 成对信号，积分比约 1.50", "en_US"))
        self.assertIsInstance(matplotlib_font_supports_cjk("DejaVu Sans"), bool)


if __name__ == "__main__":
    unittest.main()
