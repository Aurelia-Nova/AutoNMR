@echo off
setlocal EnableExtensions
chcp 65001 >nul 2>&1
set "APP_DIR=%~dp0"
set "VENV_PYTHON=%APP_DIR%.venv\Scripts\python.exe"
set "VENV_PYTHONW=%APP_DIR%.venv\Scripts\pythonw.exe"

if not exist "%VENV_PYTHON%" (
  echo Open NMR Workbench has not been installed yet.
  echo Please run install_windows.bat first.
  pause
  exit /b 1
)

"%VENV_PYTHON%" -I -c "import tkinter,numpy,scipy,matplotlib,rdkit,nmr_workbench" > "%APP_DIR%run_error.txt" 2>&1
if errorlevel 1 goto :failed

if not exist "%VENV_PYTHONW%" set "VENV_PYTHONW=%VENV_PYTHON%"
start "" /D "%APP_DIR%" "%VENV_PYTHONW%" "%APP_DIR%launcher.py"
if errorlevel 1 goto :failed
exit /b 0

:failed
echo.
echo [ERROR] Open NMR Workbench could not start.
echo Re-run install_windows.bat. Diagnostic details:
echo.
type "%APP_DIR%run_error.txt" 2>nul
echo.
echo Full diagnostic file: "%APP_DIR%run_error.txt"
pause
exit /b 1
