@echo off
setlocal EnableExtensions EnableDelayedExpansion
chcp 65001 >nul 2>&1
set "APP_DIR=%~dp0"
set "APP_ROOT=%~dp0."
set "PYTHON_MANAGER_AUTOMATIC_INSTALL=false"

echo Open NMR Workbench 0.3.0 installer revision 1
echo Application folder: "%APP_DIR%"
echo.

set "PYTHON_EXE="
set "PYTHON_ARGS="
call :try_pymanager 3.14
if not defined PYTHON_EXE call :try_pymanager 3.14t
if not defined PYTHON_EXE call :try_pymanager 3.13
if not defined PYTHON_EXE call :try_pymanager 3.12
if not defined PYTHON_EXE call :try_pymanager 3.11
if not defined PYTHON_EXE call :try_pymanager 3.10
if not defined PYTHON_EXE call :try_py 3.14
if not defined PYTHON_EXE call :try_py 3.14t
if not defined PYTHON_EXE call :try_py 3.13
if not defined PYTHON_EXE call :try_py 3.12
if not defined PYTHON_EXE call :try_py 3.11
if not defined PYTHON_EXE call :try_py 3.10
if not defined PYTHON_EXE call :try_python_path
if not defined PYTHON_EXE call :try_python_locator
if not defined PYTHON_EXE (
  echo Python 3.14 runtime is not currently registered or usable.
  echo Asking the official Python Install Manager to repair the registration
  echo and, if necessary, install the standard 64-bit Python 3.14 runtime...
  echo This can take several minutes and requires an internet connection.
  call :try_python_locator_install
)
if not defined PYTHON_EXE goto :no_python

echo Using !PYTHON_EXE! !PYTHON_ARGS!
echo Creating or repairing the isolated environment and pip...
"!PYTHON_EXE!" !PYTHON_ARGS! -I "%APP_DIR%windows_bootstrap.py" "%APP_ROOT%"
if errorlevel 1 goto :failed

echo.
echo Installation completed. Double-click run_windows.bat to start.
echo Detailed installation log: "%APP_DIR%install_log.txt"
pause
exit /b 0

:failed
echo.
echo [ERROR] Installation failed.
echo Read "%APP_DIR%install_error.txt" and "%APP_DIR%install_log.txt".
echo An incomplete .venv is preserved automatically before a clean rebuild.
pause
exit /b 1

:try_py
py -%1 -I -c "import sys,venv,ensurepip,tkinter; raise SystemExit(0 if sys.maxsize ^> 2**32 else 1)" >nul 2>&1
if not errorlevel 1 (
  set "PYTHON_EXE=py"
  set "PYTHON_ARGS=-%1"
)
exit /b 0

:try_pymanager
pymanager exec -V:%1 -I -c "import sys,venv,ensurepip,tkinter; raise SystemExit(0 if sys.maxsize ^> 2**32 else 1)" >nul 2>&1
if not errorlevel 1 (
  set "PYTHON_EXE=pymanager"
  set "PYTHON_ARGS=exec -V:%1"
)
exit /b 0

:try_python_path
for %%N in (python3.14.exe python3.exe python.exe) do (
  for /f "delims=" %%P in ('where %%N 2^>nul') do (
    set "CANDIDATE=%%P"
    "!CANDIDATE!" -I -c "import sys,venv,ensurepip,tkinter; raise SystemExit(0 if (3, 10) ^<= sys.version_info[:2] ^<= (3, 14) and sys.maxsize ^> 2**32 else 1)" >nul 2>&1
    if not errorlevel 1 (
        set "PYTHON_EXE=!CANDIDATE!"
        set "PYTHON_ARGS="
        exit /b 0
      )
    )
  )
exit /b 0

:try_python_locator
if not exist "%APP_DIR%find_python.ps1" exit /b 0
for /f "usebackq delims=" %%P in (`powershell.exe -NoLogo -NoProfile -NonInteractive -ExecutionPolicy Bypass -File "%APP_DIR%find_python.ps1" -LogPath "%APP_DIR%python_detection.log" 2^>nul`) do (
  set "PYTHON_EXE=%%P"
  set "PYTHON_ARGS="
  exit /b 0
)
exit /b 0

:try_python_locator_install
if not exist "%APP_DIR%find_python.ps1" exit /b 0
for /f "usebackq delims=" %%P in (`powershell.exe -NoLogo -NoProfile -NonInteractive -ExecutionPolicy Bypass -File "%APP_DIR%find_python.ps1" -LogPath "%APP_DIR%python_detection.log" -InstallIfMissing`) do (
  set "PYTHON_EXE=%%P"
  set "PYTHON_ARGS="
  exit /b 0
)
exit /b 0

:no_python
echo.
echo [ERROR] No supported 64-bit Python runtime was found.
echo Supported versions: 64-bit Python 3.10 through 3.14.
echo Python 3.14 is preferred; Python 3.14.6 has dedicated dependency support.
echo Detection details were saved to python_detection.log.
echo.
echo The automatic Python 3.14 repair/install attempt also failed.
echo Open python_detection.log next to this installer for the exact reason.
echo.
echo Manual repair commands for Python Install Manager:
echo   pymanager install --refresh
echo   pymanager install 3.14
echo   pymanager list --format=exe
echo.
echo If pymanager is unavailable, enable "Python install manager" in Windows
echo "Manage app execution aliases", then open a NEW Command Prompt.
echo If commands are unavailable, put the full python.exe path on the first
echo line of python_path.txt next to this installer, then run it again.
pause
exit /b 1
