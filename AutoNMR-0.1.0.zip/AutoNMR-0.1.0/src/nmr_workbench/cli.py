from __future__ import annotations

import argparse
import json
import sys

from .analysis import AnalysisConfig, analyze_spectrum
from .candidates import load_candidate_library
from .demo import generate_demo_spectrum
from .io import load_nmr_data
from .models import FID1D, Spectrum1D
from .processing import ProcessingConfig, correct_baseline, process_fid
from .report import write_report


def _load_and_process(path: str, args: argparse.Namespace) -> Spectrum1D:
    source = load_nmr_data(path)
    if isinstance(source, FID1D):
        return process_fid(
            source,
            ProcessingConfig(
                line_broadening_hz=args.line_broadening,
                zero_fill_factor=args.zero_fill,
                auto_phase=not args.no_auto_phase,
                baseline_method=args.baseline,
            ),
        )
    if args.baseline != "none":
        return correct_baseline(source, ProcessingConfig(baseline_method=args.baseline))
    return source


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="nmr-workbench", description=" NMR自动解谱软件"
    )
    subparsers = parser.add_subparsers(dest="command")

    subparsers.add_parser("gui", help="启动桌面图形界面")
    analyze = subparsers.add_parser("analyze", help="处理并自动分析一个谱图")
    analyze.add_argument("input", help="Bruker 实验目录/fid/1r，或 CSV/JCAMP-DX")
    analyze.add_argument(
        "-o", "--output", default="nmr_report.html", help="输出 HTML 或 JSON 报告"
    )
    analyze.add_argument("--solvent", help="覆盖数据中的氘代溶剂名称")
    analyze.add_argument("--formula", default="", help="分子式；用于积分归一和候选约束")
    analyze.add_argument("--frequency", type=float, help="覆盖谱仪频率 / MHz")
    analyze.add_argument("--snr", type=float, default=6.0, help="自动寻峰 S/N 阈值")
    analyze.add_argument("--candidates", help="候选结构 JSON/CSV/TSV")
    analyze.add_argument(
        "--line-broadening", type=float, default=0.3, help="指数窗线宽 / Hz"
    )
    analyze.add_argument("--zero-fill", type=int, default=2, help="零填充倍数")
    analyze.add_argument("--no-auto-phase", action="store_true", help="关闭自动相位")
    analyze.add_argument(
        "--baseline", choices=("asls", "polynomial", "none"), default="asls"
    )

    demo = subparsers.add_parser("demo", help="分析内置乙酸乙酯演示谱")
    demo.add_argument("-o", "--output", default="demo_report.html")

    predict = subparsers.add_parser(
        "predict", help="从 SMILES 预测 1H/13C/31P/19F 峰表"
    )
    predict.add_argument("smiles", help="待预测结构的 SMILES")
    predict.add_argument("--nucleus", choices=("1H", "13C", "31P", "19F"), default="1H")
    predict.add_argument("--solvent", default="CDCl3", help="氘代溶剂名称")
    predict.add_argument(
        "--frequency", type=float, default=400.0, help="所选核种的观测频率 / MHz"
    )
    predict.add_argument(
        "--temperature", type=float, default=298.15, help="温度 / K（默认 298.15）"
    )
    predict.add_argument(
        "--concentration", type=float, help="样品浓度 / mol L^-1"
    )
    predict.add_argument(
        "-o", "--output", help="输出 .json 或 .csv 峰表；省略时打印 JSON"
    )
    return parser


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    if args.command in {None, "gui"}:
        from .ui import launch

        launch()
        return 0
    if args.command == "demo":
        spectrum = generate_demo_spectrum()
        report = analyze_spectrum(spectrum, AnalysisConfig(molecular_formula="C4H8O2"))
        path = write_report(report, spectrum, args.output)
        print(f"已生成：{path.resolve()}")
        return 0
    if args.command == "analyze":
        try:
            spectrum = _load_and_process(args.input, args)
            if args.solvent:
                spectrum.solvent = args.solvent
            if args.frequency:
                spectrum.spectrometer_mhz = args.frequency
            candidates = (
                load_candidate_library(args.candidates) if args.candidates else None
            )
            report = analyze_spectrum(
                spectrum,
                AnalysisConfig(snr_threshold=args.snr, molecular_formula=args.formula),
                candidates=candidates,
            )
            path = write_report(report, spectrum, args.output)
            print(f"已生成：{path.resolve()}")
            if report.candidates:
                top = report.candidates[0]
                print(f"最高候选：{top.name}，一致性得分 {top.score:.1f}/100")
            return 0
        except Exception as exc:
            print(f"错误：{exc}", file=sys.stderr)
            return 2
    if args.command == "predict":
        try:
            from .prediction import predict_nmr, write_prediction
            from .structure import MoleculeGraph

            graph = MoleculeGraph.from_smiles(args.smiles)
            result = predict_nmr(
                graph,
                args.nucleus,
                solvent=args.solvent,
                frequency_mhz=args.frequency,
                temperature_k=args.temperature,
                concentration_m=args.concentration,
            )
            if args.output:
                path = write_prediction(result, args.output)
                print(f"已生成：{path.resolve()}")
            else:
                print(json.dumps(result.to_dict(), ensure_ascii=False, indent=2))
            return 0
        except Exception as exc:
            print(f"错误：{exc}", file=sys.stderr)
            return 2
    parser.print_help()
    return 1


if __name__ == "__main__":
    raise SystemExit(main())
