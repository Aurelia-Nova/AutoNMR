"""Local account prototype with production-shaped security boundaries.

Passwords are never stored or logged.  The desktop preview uses salted scrypt,
parameterized SQLite statements, bounded login attempts, hashed session tokens,
and an audit trail.  Remote authentication, e-mail recovery and MFA belong in a
future server-backed ``AuthBackend`` implementation rather than this local file.
"""

from __future__ import annotations

import base64
import hashlib
import hmac
import re
import secrets
import sqlite3
import time
import unicodedata
from dataclasses import dataclass
from pathlib import Path
from typing import Protocol, runtime_checkable

from .app_paths import accounts_path


USERNAME_RE = re.compile(r"^[\w.@+-]{3,64}$", re.UNICODE)
COMMON_PASSWORDS = {
    "password123!",
    "123456789012",
    "qwerty123456",
    "admin123456!",
    "openpassword",
}


class AuthError(ValueError):
    pass


@dataclass(frozen=True, slots=True)
class ScryptParameters:
    n: int = 2**17
    r: int = 8
    p: int = 1
    dklen: int = 32


@dataclass(frozen=True, slots=True)
class UserAccount:
    id: int
    username: str
    email: str
    role: str
    created_at: int
    last_login_at: int | None


@dataclass(frozen=True, slots=True)
class AuthenticationResult:
    success: bool
    message: str
    user: UserAccount | None = None
    retry_after_seconds: int = 0


@dataclass(frozen=True, slots=True)
class Session:
    token: str
    user: UserAccount
    expires_at: int


def _normalise_username(value: str) -> str:
    return unicodedata.normalize("NFKC", value).strip().casefold()


def validate_username(value: str) -> str:
    cleaned = unicodedata.normalize("NFKC", value).strip()
    if not USERNAME_RE.fullmatch(cleaned):
        raise AuthError("用户名需为 3-64 个字母、数字或 . _ @ + - 字符")
    return cleaned


def validate_password(password: str, *, username: str = "") -> None:
    if not isinstance(password, str):
        raise AuthError("密码必须是文本")
    normalized = unicodedata.normalize("NFKC", password)
    if len(normalized) < 12:
        raise AuthError("密码至少需要 12 个字符；建议使用不重复的长口令")
    if len(normalized) > 256:
        raise AuthError("密码不能超过 256 个字符")
    folded = normalized.casefold()
    if folded in COMMON_PASSWORDS:
        raise AuthError("该密码过于常见，请使用不重复的长口令")
    if username and _normalise_username(username) in folded:
        raise AuthError("密码不能包含完整用户名")
    classes = sum(
        (
            any(ch.islower() for ch in normalized),
            any(ch.isupper() for ch in normalized),
            any(ch.isdigit() for ch in normalized),
            any(not ch.isalnum() for ch in normalized),
        )
    )
    if len(normalized) < 16 and classes < 3:
        raise AuthError("少于 16 字符的密码需包含至少三类字符；长口令可不受此限制")


def _hash_password(password: str, params: ScryptParameters) -> str:
    salt = secrets.token_bytes(16)
    normalized = unicodedata.normalize("NFKC", password).encode("utf-8")
    digest = hashlib.scrypt(
        normalized,
        salt=salt,
        n=params.n,
        r=params.r,
        p=params.p,
        dklen=params.dklen,
        maxmem=max(256 * 1024 * 1024, 2 * params.n * params.r * 128),
    )
    salt64 = base64.urlsafe_b64encode(salt).decode("ascii")
    digest64 = base64.urlsafe_b64encode(digest).decode("ascii")
    return f"$scrypt$n={params.n},r={params.r},p={params.p},dklen={params.dklen}${salt64}${digest64}"


def _verify_password(password: str, encoded: str) -> bool:
    try:
        _, algorithm, parameter_text, salt64, digest64 = encoded.split("$")
        if algorithm != "scrypt":
            return False
        parameters = dict(item.split("=", 1) for item in parameter_text.split(","))
        n, r, p, dklen = (int(parameters[key]) for key in ("n", "r", "p", "dklen"))
        if n < 2**14 or n > 2**20 or r < 1 or r > 32 or p < 1 or p > 16 or dklen < 16 or dklen > 64:
            return False
        salt = base64.urlsafe_b64decode(salt64.encode("ascii"))
        expected = base64.urlsafe_b64decode(digest64.encode("ascii"))
        actual = hashlib.scrypt(
            unicodedata.normalize("NFKC", password).encode("utf-8"),
            salt=salt,
            n=n,
            r=r,
            p=p,
            dklen=dklen,
            maxmem=max(256 * 1024 * 1024, 2 * n * r * 128),
        )
        return hmac.compare_digest(actual, expected)
    except (ValueError, KeyError, TypeError):
        return False


class AccountStore:
    MAX_FAILURES = 5
    LOCK_SECONDS = 15 * 60
    SESSION_SECONDS = 12 * 60 * 60

    def __init__(
        self,
        path: str | Path | None = None,
        *,
        scrypt_parameters: ScryptParameters | None = None,
        time_function=time.time,
    ) -> None:
        self.path = str(path) if path is not None else str(accounts_path())
        if self.path != ":memory:":
            target = Path(self.path)
            target.parent.mkdir(parents=True, exist_ok=True)
        self.scrypt_parameters = scrypt_parameters or ScryptParameters()
        self._time = time_function
        self._connection = sqlite3.connect(self.path, timeout=10.0, check_same_thread=False)
        self._connection.row_factory = sqlite3.Row
        self._connection.execute("PRAGMA foreign_keys = ON")
        if self.path != ":memory:":
            self._connection.execute("PRAGMA journal_mode = WAL")
        self._migrate()
        if self.path != ":memory:":
            try:
                Path(self.path).chmod(0o600)
            except OSError:
                pass
        self._dummy_hash = _hash_password("NotARealPassword-OnlyForTiming-7!", self.scrypt_parameters)

    def close(self) -> None:
        self._connection.close()

    def _migrate(self) -> None:
        self._connection.executescript(
            """
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT NOT NULL,
                username_norm TEXT NOT NULL UNIQUE,
                email TEXT NOT NULL DEFAULT '',
                email_norm TEXT NOT NULL DEFAULT '',
                password_hash TEXT NOT NULL,
                role TEXT NOT NULL DEFAULT 'user' CHECK(role IN ('user','admin')),
                created_at INTEGER NOT NULL,
                password_changed_at INTEGER NOT NULL,
                last_login_at INTEGER,
                failed_attempts INTEGER NOT NULL DEFAULT 0,
                locked_until INTEGER NOT NULL DEFAULT 0,
                disabled INTEGER NOT NULL DEFAULT 0 CHECK(disabled IN (0,1))
            );
            CREATE UNIQUE INDEX IF NOT EXISTS users_email_unique
                ON users(email_norm) WHERE email_norm <> '';
            CREATE TABLE IF NOT EXISTS sessions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
                token_hash TEXT NOT NULL UNIQUE,
                created_at INTEGER NOT NULL,
                expires_at INTEGER NOT NULL,
                revoked_at INTEGER
            );
            CREATE TABLE IF NOT EXISTS audit_log (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                occurred_at INTEGER NOT NULL,
                user_id INTEGER REFERENCES users(id) ON DELETE SET NULL,
                event TEXT NOT NULL,
                detail TEXT NOT NULL DEFAULT ''
            );
            CREATE INDEX IF NOT EXISTS sessions_expiry ON sessions(expires_at);
            CREATE INDEX IF NOT EXISTS audit_time ON audit_log(occurred_at);
            """
        )
        self._connection.commit()

    def register(self, username: str, password: str, email: str = "") -> UserAccount:
        display = validate_username(username)
        validate_password(password, username=display)
        username_norm = _normalise_username(display)
        email_clean = unicodedata.normalize("NFKC", email).strip()
        email_norm = email_clean.casefold()
        if email_clean and (len(email_clean) > 254 or "@" not in email_clean):
            raise AuthError("邮箱格式无效")
        now = int(self._time())
        password_hash = _hash_password(password, self.scrypt_parameters)
        role = "admin" if self._connection.execute("SELECT COUNT(*) FROM users").fetchone()[0] == 0 else "user"
        try:
            cursor = self._connection.execute(
                """INSERT INTO users
                   (username, username_norm, email, email_norm, password_hash, role, created_at, password_changed_at)
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
                (display, username_norm, email_clean, email_norm, password_hash, role, now, now),
            )
            self._audit(cursor.lastrowid, "account.registered", f"role={role}")
            self._connection.commit()
        except sqlite3.IntegrityError as exc:
            self._connection.rollback()
            raise AuthError("用户名或邮箱已被使用") from exc
        account = self.get_user(int(cursor.lastrowid))
        assert account is not None
        return account

    def authenticate(self, username: str, password: str) -> AuthenticationResult:
        now = int(self._time())
        username_norm = _normalise_username(username)
        row = self._connection.execute(
            "SELECT * FROM users WHERE username_norm = ?", (username_norm,)
        ).fetchone()
        if row is None:
            _verify_password(password, self._dummy_hash)
            self._audit(None, "login.failed", "unknown-user")
            self._connection.commit()
            return AuthenticationResult(False, "用户名或密码错误")
        if row["disabled"]:
            self._audit(row["id"], "login.blocked", "disabled")
            self._connection.commit()
            return AuthenticationResult(False, "账号已停用")
        if int(row["locked_until"]) > now:
            retry = int(row["locked_until"]) - now
            self._audit(row["id"], "login.blocked", "temporary-lock")
            self._connection.commit()
            return AuthenticationResult(False, "登录尝试过多，账号暂时锁定", retry_after_seconds=retry)
        if not _verify_password(password, row["password_hash"]):
            failures = int(row["failed_attempts"]) + 1
            locked_until = now + self.LOCK_SECONDS if failures >= self.MAX_FAILURES else 0
            self._connection.execute(
                "UPDATE users SET failed_attempts = ?, locked_until = ? WHERE id = ?",
                (failures, locked_until, row["id"]),
            )
            self._audit(row["id"], "login.failed", f"attempt={failures}")
            self._connection.commit()
            retry = self.LOCK_SECONDS if locked_until else 0
            return AuthenticationResult(False, "用户名或密码错误", retry_after_seconds=retry)
        self._connection.execute(
            "UPDATE users SET failed_attempts = 0, locked_until = 0, last_login_at = ? WHERE id = ?",
            (now, row["id"]),
        )
        self._audit(row["id"], "login.succeeded")
        self._connection.commit()
        user = self.get_user(int(row["id"]))
        return AuthenticationResult(True, "登录成功", user=user)

    def create_session(self, user_id: int, *, duration_seconds: int | None = None) -> Session:
        user = self.get_user(user_id)
        if user is None:
            raise AuthError("账号不存在")
        token = secrets.token_urlsafe(32)
        token_hash = hashlib.sha256(token.encode("ascii")).hexdigest()
        now = int(self._time())
        expires = now + int(duration_seconds or self.SESSION_SECONDS)
        self._connection.execute(
            "INSERT INTO sessions(user_id, token_hash, created_at, expires_at) VALUES (?, ?, ?, ?)",
            (user_id, token_hash, now, expires),
        )
        self._audit(user_id, "session.created")
        self._connection.commit()
        return Session(token=token, user=user, expires_at=expires)

    def validate_session(self, token: str) -> UserAccount | None:
        if not token or len(token) > 256:
            return None
        now = int(self._time())
        token_hash = hashlib.sha256(token.encode("utf-8")).hexdigest()
        row = self._connection.execute(
            """SELECT u.* FROM sessions s JOIN users u ON u.id = s.user_id
               WHERE s.token_hash = ? AND s.revoked_at IS NULL AND s.expires_at > ? AND u.disabled = 0""",
            (token_hash, now),
        ).fetchone()
        return self._user_from_row(row) if row is not None else None

    def revoke_session(self, token: str) -> None:
        if not token:
            return
        token_hash = hashlib.sha256(token.encode("utf-8")).hexdigest()
        now = int(self._time())
        row = self._connection.execute("SELECT user_id FROM sessions WHERE token_hash = ?", (token_hash,)).fetchone()
        self._connection.execute(
            "UPDATE sessions SET revoked_at = ? WHERE token_hash = ? AND revoked_at IS NULL",
            (now, token_hash),
        )
        if row is not None:
            self._audit(row["user_id"], "session.revoked")
        self._connection.commit()

    def change_password(self, user_id: int, current_password: str, new_password: str) -> None:
        row = self._connection.execute("SELECT * FROM users WHERE id = ?", (int(user_id),)).fetchone()
        if row is None or not _verify_password(current_password, row["password_hash"]):
            raise AuthError("当前密码错误")
        validate_password(new_password, username=row["username"])
        if hmac.compare_digest(current_password, new_password):
            raise AuthError("新密码不能与当前密码相同")
        encoded = _hash_password(new_password, self.scrypt_parameters)
        now = int(self._time())
        self._connection.execute(
            "UPDATE users SET password_hash = ?, password_changed_at = ?, failed_attempts = 0, locked_until = 0 WHERE id = ?",
            (encoded, now, user_id),
        )
        self._connection.execute(
            "UPDATE sessions SET revoked_at = ? WHERE user_id = ? AND revoked_at IS NULL",
            (now, user_id),
        )
        self._audit(user_id, "password.changed")
        self._connection.commit()

    def get_user(self, user_id: int) -> UserAccount | None:
        row = self._connection.execute("SELECT * FROM users WHERE id = ?", (int(user_id),)).fetchone()
        return self._user_from_row(row) if row is not None else None

    def audit_events(self, *, limit: int = 100) -> list[dict[str, object]]:
        rows = self._connection.execute(
            "SELECT occurred_at, user_id, event, detail FROM audit_log ORDER BY id DESC LIMIT ?",
            (max(1, min(int(limit), 1000)),),
        ).fetchall()
        return [dict(row) for row in rows]

    def _audit(self, user_id: int | None, event: str, detail: str = "") -> None:
        self._connection.execute(
            "INSERT INTO audit_log(occurred_at, user_id, event, detail) VALUES (?, ?, ?, ?)",
            (int(self._time()), user_id, event, detail[:500]),
        )

    @staticmethod
    def _user_from_row(row: sqlite3.Row) -> UserAccount:
        return UserAccount(
            id=int(row["id"]),
            username=str(row["username"]),
            email=str(row["email"]),
            role=str(row["role"]),
            created_at=int(row["created_at"]),
            last_login_at=int(row["last_login_at"]) if row["last_login_at"] is not None else None,
        )


@runtime_checkable
class AuthBackend(Protocol):
    def authenticate(self, username: str, password: str) -> AuthenticationResult: ...

    def create_session(self, user_id: int, *, duration_seconds: int | None = None) -> Session: ...

