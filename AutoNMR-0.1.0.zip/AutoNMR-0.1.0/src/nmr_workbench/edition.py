"""Edition capability model.

The current build is completely free and source-buildable.  A later commercial
client can obtain entitlements from a signed service without putting proprietary
implementations in the community source tree.
"""

from __future__ import annotations

import json
from dataclasses import dataclass
from importlib.resources import files
from typing import Protocol, runtime_checkable


@dataclass(frozen=True, slots=True)
class EditionPolicy:
    edition: str
    allow_guest: bool
    allow_source_build: bool
    features: dict[str, bool]

    def enabled(self, feature: str) -> bool:
        return bool(self.features.get(feature, False))


def bundled_edition_policy() -> EditionPolicy:
    resource = files("nmr_workbench").joinpath("data", "edition.json")
    payload = json.loads(resource.read_text(encoding="utf-8"))
    return EditionPolicy(
        edition=str(payload.get("edition", "community-internal-preview")),
        allow_guest=bool(payload.get("allow_guest", True)),
        allow_source_build=bool(payload.get("allow_source_build", True)),
        features={str(key): bool(value) for key, value in payload.get("features", {}).items()},
    )


@runtime_checkable
class EntitlementProvider(Protocol):
    def policy_for(self, user_id: int | None) -> EditionPolicy: ...

