"""Explainable assignment of a predicted structure to an experimental spectrum."""

from __future__ import annotations

from dataclasses import asdict, dataclass, field

import numpy as np
from scipy.optimize import linear_sum_assignment

from .models import AnalysisReport, Signal
from .prediction import PredictionResult, PredictionSignal, normalise_nucleus


@dataclass(frozen=True, slots=True)
class SignalAssignment:
    predicted_index: int
    observed_index: int
    atom_ids: tuple[int, ...]
    predicted_shift: float
    observed_shift: float
    error_ppm: float
    normalized_error: float
    score: float


@dataclass(slots=True)
class VerificationResult:
    nucleus: str
    score: float
    predicted_coverage: float
    observed_coverage: float
    shift_rmse: float | None
    assignments: list[SignalAssignment]
    missing_predicted: list[int]
    unexplained_observed: list[int]
    warnings: list[str] = field(default_factory=list)

    def to_dict(self) -> dict[str, object]:
        return {
            "nucleus": self.nucleus,
            "score": self.score,
            "predicted_coverage": self.predicted_coverage,
            "observed_coverage": self.observed_coverage,
            "shift_rmse": self.shift_rmse,
            "assignments": [asdict(item) for item in self.assignments],
            "missing_predicted": self.missing_predicted,
            "unexplained_observed": self.unexplained_observed,
            "warnings": self.warnings,
        }


def _usable_observed(signals: list[Signal]) -> list[tuple[int, Signal]]:
    excluded = {"residual solvent", "water", "reference"}
    return [
        (index, signal)
        for index, signal in enumerate(signals)
        if signal.reference_match is None or signal.reference_match.category not in excluded
    ]


def _multiplicity_score(observed: str, predicted: str, nucleus: str) -> float:
    if nucleus != "1H":
        return 1.0
    left = observed.casefold().replace(" ", "")
    right = predicted.casefold().replace(" ", "")
    if left == right:
        return 1.0
    if "m" in {left, right} or left.startswith("br") or right.startswith("br"):
        return 0.65
    if left.startswith(right) or right.startswith(left):
        return 0.78
    return 0.25


def verify_prediction(
    prediction: PredictionResult,
    report: AnalysisReport,
) -> VerificationResult:
    nucleus = normalise_nucleus(prediction.nucleus)
    observed_nucleus = normalise_nucleus(report.nucleus)
    if nucleus != observed_nucleus:
        raise ValueError(f"核种不一致：预测为 {nucleus}，实验谱为 {observed_nucleus}")
    predicted = prediction.signals
    observed = _usable_observed(report.signals)
    warnings: list[str] = []
    if not predicted or not observed:
        return VerificationResult(
            nucleus=nucleus,
            score=0.0,
            predicted_coverage=0.0,
            observed_coverage=0.0,
            shift_rmse=None,
            assignments=[],
            missing_predicted=list(range(len(predicted))),
            unexplained_observed=[index for index, _ in observed],
            warnings=["预测或实验谱没有可用于比较的分析物信号。"],
        )

    base_sigma = {"1H": 0.06, "13C": 1.2, "19F": 1.5, "31P": 1.5}[nucleus]
    cost = np.full((len(predicted), len(observed)), 1.0e6, dtype=float)
    details: dict[tuple[int, int], tuple[float, float, float]] = {}
    for i, expected in enumerate(predicted):
        sigma = max(base_sigma, float(expected.uncertainty_ppm) / 2.0)
        for j, (_, actual) in enumerate(observed):
            error = abs(float(expected.shift_ppm) - float(actual.center_ppm))
            normalized = error / sigma
            if normalized > 3.5:
                continue
            mult = _multiplicity_score(actual.multiplicity, expected.multiplicity, nucleus)
            shift_component = float(np.exp(-0.5 * normalized**2))
            pair_score = 100.0 * (0.82 * shift_component + 0.18 * mult)
            cost[i, j] = normalized**2 + 0.35 * (1.0 - mult)
            details[(i, j)] = (error, normalized, pair_score)

    rows, columns = linear_sum_assignment(cost)
    assignments: list[SignalAssignment] = []
    for i, j in zip(rows, columns):
        i, j = int(i), int(j)
        if cost[i, j] >= 12.5 or (i, j) not in details:
            continue
        error, normalized, pair_score = details[(i, j)]
        observed_index, actual = observed[j]
        expected = predicted[i]
        assignments.append(
            SignalAssignment(
                predicted_index=i,
                observed_index=observed_index,
                atom_ids=tuple(expected.atom_ids),
                predicted_shift=float(expected.shift_ppm),
                observed_shift=float(actual.center_ppm),
                error_ppm=error,
                normalized_error=normalized,
                score=pair_score,
            )
        )

    used_predicted = {item.predicted_index for item in assignments}
    used_observed = {item.observed_index for item in assignments}
    missing = [index for index in range(len(predicted)) if index not in used_predicted]
    unexplained = [index for index, _ in observed if index not in used_observed]
    predicted_coverage = len(assignments) / len(predicted)
    observed_coverage = len(assignments) / len(observed)
    rmse = (
        float(np.sqrt(np.mean([item.error_ppm**2 for item in assignments])))
        if assignments
        else None
    )
    pair_quality = float(np.mean([item.score for item in assignments])) / 100.0 if assignments else 0.0

    integral_score = 0.5
    if nucleus == "1H" and assignments:
        expected_integrals = np.asarray([predicted[item.predicted_index].integral for item in assignments], dtype=float)
        actual_integrals = np.asarray(
            [report.signals[item.observed_index].estimated_protons or report.signals[item.observed_index].relative_integral for item in assignments],
            dtype=float,
        )
        if expected_integrals.sum() > 0 and actual_integrals.sum() > 0:
            expected_integrals /= expected_integrals.sum()
            actual_integrals /= actual_integrals.sum()
            integral_score = float(np.exp(-5.0 * np.mean(np.abs(expected_integrals - actual_integrals))))

    score = 100.0 * (
        0.35 * predicted_coverage
        + 0.20 * observed_coverage
        + 0.30 * pair_quality
        + 0.15 * integral_score
    )
    if report.quality_score < 55:
        warnings.append("实验谱质量评分偏低；结构一致性分数的可靠性受限。")
        score *= 0.92
    if missing:
        warnings.append(f"有 {len(missing)} 组预测信号未在实验谱中找到可信匹配。")
    if unexplained:
        warnings.append(f"有 {len(unexplained)} 组实验信号未被该结构解释，可能来自杂质、异构体、漏配或模型偏差。")
    warnings.append("一致性评分用于候选结构验证，不是对未知物结构的唯一证明。")
    return VerificationResult(
        nucleus=nucleus,
        score=float(np.clip(score, 0.0, 100.0)),
        predicted_coverage=predicted_coverage,
        observed_coverage=observed_coverage,
        shift_rmse=rmse,
        assignments=sorted(assignments, key=lambda item: item.predicted_index),
        missing_predicted=missing,
        unexplained_observed=unexplained,
        warnings=warnings,
    )

