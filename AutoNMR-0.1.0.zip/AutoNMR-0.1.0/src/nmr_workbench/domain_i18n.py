"""Presentation-only translation of chemistry annotations from the core."""

from __future__ import annotations

import re


_EXACT_EN = {
    "羰基碳区": "carbonyl-carbon region",
    "sp² 碳区": "sp²-carbon region",
    "杂原子取代 sp³ 碳区": "heteroatom-substituted sp³-carbon region",
    "脂肪 sp³ 碳区": "aliphatic sp³-carbon region",
    "强去屏蔽/可交换氢区": "strongly deshielded / exchangeable-proton region",
    "醛基/杂芳环区": "aldehyde / heteroaromatic region",
    "芳香/烯烃区": "aromatic / alkene region",
    "烯烃/缩醛区": "alkene / acetal region",
    "杂原子邻位区": "heteroatom-adjacent region",
    "苄位/羰基 α 位区": "benzylic / carbonyl α region",
    "脂肪烷基区": "aliphatic alkyl region",
    "高场区": "upfield region",
    "可能存在乙基 –CH2CH3": "possible ethyl group –CH2CH3",
    "可能存在叔丁基 C(CH3)3": "possible tert-butyl group C(CH3)3",
    "可能存在异丙基 –CH(CH3)2": "possible isopropyl group –CH(CH3)2",
    "可能存在强氢键可交换氢": "possible strongly hydrogen-bonded exchangeable proton",
    "可能存在甲氧基 OCH3": "possible methoxy group OCH3",
    "可能存在羰基/烯基相邻甲基": "possible methyl adjacent to a carbonyl or alkene",
    "可能存在近似对称的二取代芳环": "possible approximately symmetric disubstituted aromatic ring",
    "可能存在相互偶合的烯烃/芳香氢": "possible mutually coupled alkene/aromatic protons",
    "可能存在醛基 –CHO": "possible aldehyde –CHO",
    "芳香或杂芳香氢证据": "aromatic or heteroaromatic proton evidence",
    "谱图整体 S/N 偏低，弱峰和多重性判断可靠性有限。": "Overall spectrum S/N is low; weak-peak and multiplicity assignments are less reliable.",
    "负峰面积偏高，建议复查相位与基线。": "Negative-peak area is high; review phase and baseline correction.",
    "谱窗边缘存在强信号，可能发生截谱或谱宽设置不足。": "A strong signal is present near the spectral boundary; acquisition width may be insufficient.",
    "信号数很多，可能存在混合物、噪声误检或严重重叠。": "Many signals were found; consider a mixture, noise picks, or severe overlap.",
    "估算氢数按可积分信号总面积缩放；交换峰、重叠峰或漏峰会造成偏差。": "Estimated proton counts are scaled to total integrable area; exchange, overlap, and missed peaks can bias them.",
    "当前多重性、积分归一和片段规则主要针对 1H；其他核种结果仅作寻峰参考。": "Multiplicity, integral normalization, and fragment rules currently target 1H; other nuclei are peak-picking references only.",
    "输入分子式给出负不饱和度，请检查分子式或电荷。": "The formula gives a negative degree of unsaturation; check formula and charge.",
    "未检出超过阈值的正峰；请检查相位、谱图极性或降低 S/N 阈值。": "No positive peaks exceeded the threshold; check phase/polarity or reduce the S/N threshold.",
    "候选分子式与输入分子式一致": "Candidate formula matches the supplied formula",
    "候选分子式与输入分子式不一致，已施加惩罚": "Candidate formula differs from the supplied formula; a penalty was applied",
    "候选物没有预期 1H 信号数据，无法进行谱图评分": "The candidate has no expected 1H signals and cannot be scored",
    "未检出可用于评分的分析物信号": "No analyte signals are available for scoring",
    "输入分子式无法规范比较": "The supplied formula could not be normalized for comparison",
    "筛查匹配；位移随温度、浓度和含水量变化": "Screening match; shifts vary with temperature, concentration, and water content",
    "普通烷基氢": "ordinary alkyl proton",
    "芳环、杂芳环或烯烃氢": "aromatic, heteroaromatic, or alkene proton",
    "O–CH、N–CH 或卤代烷基": "O–CH, N–CH, or haloalkyl",
    "苄位、烯丙位、炔丙位或羰基 α-氢": "benzylic, allylic, propargylic, or carbonyl α proton",
    "高度屏蔽烷基、硅烷/硅氧烷或内标": "strongly shielded alkyl, silane/siloxane, or internal standard",
    "芳环、烯烃或杂芳环碳": "aromatic, alkene, or heteroaromatic carbon",
    "烷基或羰基 α-碳": "alkyl or carbonyl α carbon",
    "C–O/C–N/C–X 或缩醛碳": "C–O/C–N/C–X or acetal carbon",
    "醛/酮/羧酸衍生物羰基碳": "aldehyde/ketone/carboxylic-derivative carbonyl carbon",
    "醛氢或强去屏蔽杂芳环氢": "aldehyde or strongly deshielded heteroaromatic proton",
    "羧酸、强氢键酚或其他可交换氢": "carboxylic acid, strongly hydrogen-bonded phenol, or other exchangeable proton",
    "烯烃氢、缩醛/异头氢或二杂原子取代碳上的氢": "alkene, acetal/anomeric, or diheteroatom-substituted proton",
    "Open NMR Workbench 0.3 可解释环境增量模型": "Open NMR Workbench 0.3 explainable environment-increment model",
    "化学位移来自离线、可解释的环境增量规则；数值用于画板预览和初步指认，不是实验鉴定结论。": "Chemical shifts come from offline, explainable environment-increment rules. Values support drawing previews and preliminary assignments, not experimental identification.",
    "当前规则以约 298 K 数据为中心；已因所填温度扩大不确定度，但未施加经验性全局位移。": "The rules are centered near 298 K. Uncertainty was widened for the entered temperature, without applying an empirical global shift.",
    "未提供浓度；氢键、聚集和交换相关信号的不确定度已适度放宽。": "No concentration was supplied; uncertainty for hydrogen bonding, aggregation, and exchange-sensitive signals was widened.",
    "未显式处理构象、氢键、快速交换及非对映异位氢；OH/NH 峰可能移动、展宽或消失。": "Conformation, hydrogen bonding, rapid exchange, and diastereotopic protons are not modeled explicitly; OH/NH peaks may move, broaden, or disappear.",
    "CH2 中的两个 H 默认合并；手性/刚性环境下可能成为 AB 或两组非对映异位信号。": "The two protons of CH2 are merged by default; chiral or rigid environments may produce an AB system or two diastereotopic signals.",
    "13C 默认按宽带质子去耦谱显示；“CH3/CH2/CH/Cq”是碳类型，不是实测裂分。": "13C is displayed as broadband proton-decoupled data; CH3/CH2/CH/Cq are carbon types, not observed splitting.",
    "19F 位移对取代、溶剂与构象非常敏感；经验范围较宽，尤其是 P–F/S–F 和多氟体系。": "19F shifts are highly sensitive to substitution, solvent, and conformation; empirical ranges are broad, especially for P–F/S–F and polyfluorinated systems.",
    "31P 位移强烈依赖氧化态、配位、pH 与质子化；金属配合物和超价磷需用专门方法复核。": "31P shifts depend strongly on oxidation state, coordination, pH, and protonation; metal complexes and hypervalent phosphorus require specialized validation.",
}


_REPLACEMENTS_EN = (
    ("；在该溶剂中可能交换消失", "; may exchange away in this solvent"),
    ("酰胺/脲羰基", "amide/urea carbonyl"),
    ("酯/碳酸酯羰基", "ester/carbonate carbonyl"),
    ("羧酸羰基", "carboxylic-acid carbonyl"),
    ("酮羰基", "ketone carbonyl"),
    ("醛羰基", "aldehyde carbonyl"),
    ("酰卤羰基", "acyl-halide carbonyl"),
    ("芳香 C–H", "aromatic C–H"),
    ("烯烃 C=C–H", "alkene C=C–H"),
    ("端炔 C≡C–H", "terminal alkyne C≡C–H"),
    ("醛基 CHO", "aldehyde CHO"),
    ("醇 O–H（交换性）", "alcohol O–H (exchangeable)"),
    ("酚羟基 O–H（交换性）", "phenol O–H (exchangeable)"),
    ("羧酸/强氢键 O–H", "carboxylic/strongly H-bonded O–H"),
    ("胺 N–H（交换性）", "amine N–H (exchangeable)"),
    ("酰胺 N–H（交换性）", "amide N–H (exchangeable)"),
    ("芳香 N–H（交换性）", "aromatic N–H (exchangeable)"),
    ("硫醇 S–H（交换性）", "thiol S–H (exchangeable)"),
    ("羰基 α 位", "carbonyl α position"),
    ("烯丙位", "allylic"),
    ("炔丙位", "propargylic"),
    ("苄位", "benzylic"),
    ("芳基 F", "aryl F"),
    ("酰氟 F", "acyl fluoride F"),
    ("脂肪族 CF3", "aliphatic CF3"),
    ("脂肪族 CF2", "aliphatic CF2"),
    ("脂肪族 C–F", "aliphatic C–F"),
    ("磷酸酯/磷酸盐 P(V)", "phosphate/phosphate ester P(V)"),
    ("膦酸酯 P(V)", "phosphonate P(V)"),
    ("氧化膦 P(V)", "phosphine oxide P(V)"),
    ("次膦酸酯/膦氧 P(V)", "phosphinate/phosphinyl P(V)"),
    ("亚磷酸酯 P(III)", "phosphite P(III)"),
    ("芳基膦 P(III)", "aryl phosphine P(III)"),
    ("烷基膦 P(III)", "alkyl phosphine P(III)"),
    ("含 P–F 的磷中心", "P–F-containing phosphorus center"),
    ("未分类磷中心", "unclassified phosphorus center"),
    ("芳香 ", "aromatic "),
    ("烯烃 ", "alkene "),
    ("炔碳 ", "alkyne carbon "),
    ("脂肪族 ", "aliphatic "),
    ("连 ", "attached to "),
)


_PATTERNS_EN = (
    (re.compile(r"同一 J≈([\d.]+) Hz 的 t/q 成对信号，积分比约 ([\d.]+)"), r"paired t/q signals share J≈\1 Hz; integral ratio ≈\2"),
    (re.compile(r"同一 J≈([\d.]+) Hz 的 d/sept 成对信号"), r"paired d/sept signals share J≈\1 Hz"),
    (re.compile(r"匹配 (\d+)/(\d+) 个预期信号；实验非溶剂信号覆盖 ([\d%]+)"), r"Matched \1/\2 expected signals; non-solvent observed coverage \3"),
    (re.compile(r"匹配信号位移 RMSE = ([\d.]+) ppm"), r"Matched-shift RMSE = \1 ppm"),
    (re.compile(r"δ ([\d.]+) ppm 的去屏蔽 1H 信号"), r"deshielded 1H signal at δ \1 ppm"),
    (re.compile(r"高场单峰积分约 ([\d.]+)"), r"upfield singlet with integral ≈\1"),
)


def domain_text(text: str, language: str) -> str:
    """Translate stable analysis wording at the presentation boundary."""

    if language != "en_US" or not text:
        return text
    if text in _EXACT_EN:
        return _EXACT_EN[text]
    result = text
    for pattern, replacement in _PATTERNS_EN:
        result = pattern.sub(replacement, result)
    for source, target in _REPLACEMENTS_EN:
        result = result.replace(source, target)
    return result
