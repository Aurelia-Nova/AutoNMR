"""Extensible reader registry for NMR today and other spectra later.

External packages may expose readers through the
``open_nmr_workbench.readers`` Python entry-point group.  A reader is isolated
behind this protocol so adding JEOL, Agilent/Varian, JCAMP variants or MS does
not require changes to the processing UI.
"""

from __future__ import annotations

from dataclasses import dataclass
from importlib import metadata
from pathlib import Path
from typing import Any, Protocol, runtime_checkable


class SpectralPluginError(ValueError):
    pass


@dataclass(frozen=True, slots=True)
class ReaderInfo:
    id: str
    name: str
    modality: str
    vendor: str = "generic"
    priority: int = 0
    extensions: tuple[str, ...] = ()


@runtime_checkable
class SpectralReader(Protocol):
    info: ReaderInfo

    def can_read(self, path: Path) -> bool: ...

    def read(self, path: Path) -> Any: ...


class ReaderRegistry:
    def __init__(self) -> None:
        self._readers: dict[str, SpectralReader] = {}
        self.plugin_errors: list[str] = []

    @property
    def readers(self) -> tuple[SpectralReader, ...]:
        return tuple(
            sorted(self._readers.values(), key=lambda item: item.info.priority, reverse=True)
        )

    def register(self, reader: SpectralReader, *, replace: bool = False) -> None:
        if not isinstance(reader, SpectralReader):
            raise TypeError("Reader plugin does not implement the SpectralReader protocol")
        plugin_id = reader.info.id.strip()
        if not plugin_id:
            raise ValueError("Reader plugin id cannot be empty")
        if plugin_id in self._readers and not replace:
            raise ValueError(f"Reader plugin already registered: {plugin_id}")
        self._readers[plugin_id] = reader

    def discover_entry_points(self) -> None:
        try:
            points = metadata.entry_points()
            selected = points.select(group="open_nmr_workbench.readers") if hasattr(points, "select") else points.get("open_nmr_workbench.readers", [])
        except Exception as exc:
            self.plugin_errors.append(f"Could not enumerate reader plugins: {exc}")
            return
        for point in selected:
            try:
                loaded = point.load()
                reader = loaded() if isinstance(loaded, type) else loaded
                self.register(reader)
            except Exception as exc:
                self.plugin_errors.append(f"Reader plugin {point.name!r} was not loaded: {exc}")

    def matching_readers(self, path: str | Path) -> tuple[SpectralReader, ...]:
        source = Path(path)
        matches: list[SpectralReader] = []
        for reader in self.readers:
            try:
                if reader.can_read(source):
                    matches.append(reader)
            except Exception as exc:
                self.plugin_errors.append(f"Reader {reader.info.id!r} probe failed: {exc}")
        return tuple(matches)

    def read(self, path: str | Path) -> Any:
        source = Path(path)
        matches = self.matching_readers(source)
        if not matches:
            raise SpectralPluginError(f"No installed reader recognizes: {source.name}")
        errors: list[str] = []
        for reader in matches:
            try:
                return reader.read(source)
            except Exception as exc:
                errors.append(f"{reader.info.name}: {exc}")
        raise SpectralPluginError("All matching readers failed. " + " | ".join(errors))


class BrukerReader:
    info = ReaderInfo("bruker-nmr", "Bruker NMR", "nmr", "Bruker", 100, ("fid", "1r"))

    def can_read(self, path: Path) -> bool:
        if path.is_dir():
            return (path / "fid").exists() or (path / "pdata").exists() or (path / "1r").exists()
        return path.name.lower() in {"fid", "1r"}

    def read(self, path: Path) -> Any:
        from .io import read_bruker_fid, read_bruker_processed

        if path.name.lower() == "fid" or (path.is_dir() and (path / "fid").exists()):
            return read_bruker_fid(path)
        return read_bruker_processed(path)


class JcampReader:
    info = ReaderInfo("jcamp-dx", "JCAMP-DX", "spectroscopy", "generic", 50, (".dx", ".jdx", ".jcamp"))

    def can_read(self, path: Path) -> bool:
        return path.is_file() and path.suffix.lower() in self.info.extensions

    def read(self, path: Path) -> Any:
        from .io import read_jcamp_spectrum

        return read_jcamp_spectrum(path)


class DelimitedReader:
    info = ReaderInfo("delimited-xy", "CSV / TSV XY", "spectroscopy", "generic", 20, (".csv", ".tsv", ".txt"))

    def can_read(self, path: Path) -> bool:
        return path.is_file() and path.suffix.lower() in self.info.extensions

    def read(self, path: Path) -> Any:
        from .io import read_csv_spectrum

        return read_csv_spectrum(path)


_DEFAULT_REGISTRY: ReaderRegistry | None = None


def default_reader_registry(*, discover_external: bool = True) -> ReaderRegistry:
    global _DEFAULT_REGISTRY
    if _DEFAULT_REGISTRY is None:
        registry = ReaderRegistry()
        registry.register(BrukerReader())
        registry.register(JcampReader())
        registry.register(DelimitedReader())
        if discover_external:
            registry.discover_entry_points()
        _DEFAULT_REGISTRY = registry
    return _DEFAULT_REGISTRY

