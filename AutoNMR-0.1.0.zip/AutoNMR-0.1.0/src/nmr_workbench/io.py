from __future__ import annotations

import csv
import json
import re
from pathlib import Path
from typing import Any

import numpy as np

from .models import FID1D, Spectrum1D


class NMRDataError(ValueError):
    """Raised when an NMR data source cannot be interpreted safely."""


_PARAM_START = re.compile(r"^##\$(?P<key>[^=]+)=\s*(?P<value>.*)$")


def _coerce_bruker_value(raw: str) -> Any:
    raw = raw.strip()
    if raw.startswith("<") and raw.endswith(">"):
        return raw[1:-1]
    if raw.startswith("("):
        return raw
    parts = raw.split()
    if len(parts) > 1:
        return [_coerce_bruker_value(part) for part in parts]
    try:
        if any(c in raw.lower() for c in (".", "e")):
            return float(raw)
        return int(raw)
    except ValueError:
        return raw


def read_bruker_parameters(path: str | Path) -> dict[str, Any]:
    """Parse the scalar and short-array subset of a Bruker JCAMP parameter file."""
    source = Path(path)
    if not source.exists():
        raise NMRDataError(f"找不到 Bruker 参数文件：{source}")
    lines = source.read_text(encoding="latin-1", errors="replace").splitlines()
    params: dict[str, Any] = {}
    i = 0
    while i < len(lines):
        match = _PARAM_START.match(lines[i])
        if not match:
            i += 1
            continue
        key, raw = match.group("key").strip(), match.group("value").strip()
        if raw.startswith("("):
            values: list[str] = []
            i += 1
            while i < len(lines) and not lines[i].startswith("##"):
                values.extend(lines[i].strip().split())
                i += 1
            params[key] = [_coerce_bruker_value(v) for v in values]
            continue
        params[key] = _coerce_bruker_value(raw)
        i += 1
    return params


def _first_number(params: dict[str, Any], key: str, default: float) -> float:
    value = params.get(key, default)
    if isinstance(value, list):
        value = value[0] if value else default
    try:
        return float(value)
    except (TypeError, ValueError):
        return float(default)


def _find_acqus(start: Path) -> Path | None:
    for folder in (start, *start.parents):
        candidate = folder / "acqus"
        if candidate.exists():
            return candidate
    return None


def read_bruker_fid(path: str | Path) -> FID1D:
    source = Path(path)
    if source.is_dir():
        source = source / "fid"
    if source.name != "fid" or not source.exists():
        raise NMRDataError("请选择包含 acqus 与 fid 的 Bruker 一维实验目录")
    acqus_path = source.parent / "acqus"
    params = read_bruker_parameters(acqus_path)

    byte_order = ">" if int(_first_number(params, "BYTORDA", 0)) else "<"
    data_type = int(_first_number(params, "DTYPA", 0))
    dtype_map = {0: "i4", 1: "f4", 2: "f8"}
    if data_type not in dtype_map:
        raise NMRDataError(f"暂不支持 Bruker DTYPA={data_type}")
    raw = np.fromfile(source, dtype=np.dtype(byte_order + dtype_map[data_type]))
    td = int(_first_number(params, "TD", raw.size))
    if td > 0:
        raw = raw[: min(td, raw.size)]
    if raw.size % 2:
        raw = raw[:-1]
    if raw.size < 16:
        raise NMRDataError("fid 文件有效点数过少")
    nc = int(_first_number(params, "NC", 0))
    if nc:
        raw = raw.astype(float) * (2.0**nc)
    data = raw[0::2].astype(float) + 1j * raw[1::2].astype(float)

    sw_h = _first_number(params, "SW_h", 0.0)
    sfo1 = abs(_first_number(params, "SFO1", _first_number(params, "BF1", 400.0)))
    if sw_h <= 0:
        sw_ppm = _first_number(params, "SW", 20.0)
        sw_h = sw_ppm * sfo1
    dwell = 1.0 / sw_h
    o1_hz = _first_number(params, "O1", 0.0)
    carrier = o1_hz / sfo1 if sfo1 else 0.0
    nucleus = str(params.get("NUC1", "1H")).strip("<>")
    solvent = str(params.get("SOLVENT", "CDCl3")).strip("<>")
    group_delay = _first_number(params, "GRPDLY", 0.0)
    title_file = source.parent / "title"
    title = (
        title_file.read_text(encoding="latin-1", errors="replace").strip()
        if title_file.exists()
        else source.parent.name
    )
    return FID1D(
        data=data,
        dwell_time_s=dwell,
        spectrometer_mhz=sfo1,
        carrier_ppm=carrier,
        nucleus=nucleus,
        solvent=solvent,
        title=title or source.parent.name,
        group_delay_points=group_delay,
        metadata={"source": str(source), "format": "Bruker fid", "acqus": params},
    )


def read_bruker_processed(path: str | Path) -> Spectrum1D:
    source = Path(path)
    if source.is_dir():
        candidates = list(source.glob("pdata/*/1r")) + list(source.glob("1r"))
        if not candidates:
            raise NMRDataError("目录中没有找到 Bruker pdata/*/1r")
        source = candidates[0]
    if source.name != "1r" or not source.exists():
        raise NMRDataError("请选择 Bruker 处理后的一维 1r 文件")
    procs_path = source.parent / "procs"
    params = read_bruker_parameters(procs_path)
    byte_order = ">" if int(_first_number(params, "BYTORDP", 0)) else "<"
    dtypp = int(_first_number(params, "DTYPP", 0))
    dtype = {0: "i4", 1: "f4", 2: "f8"}.get(dtypp, "i4")
    values = np.fromfile(source, dtype=np.dtype(byte_order + dtype)).astype(float)
    si = int(_first_number(params, "SI", values.size))
    values = values[: min(si, values.size)]
    nc_proc = int(_first_number(params, "NC_proc", 0))
    if nc_proc:
        values *= 2.0**nc_proc
    sf = abs(_first_number(params, "SF", 400.0))
    sw_p = _first_number(params, "SW_p", 20.0 * sf)
    offset = _first_number(params, "OFFSET", sw_p / sf / 2)
    ppm = offset - np.arange(values.size) * (sw_p / sf) / max(values.size, 1)
    acqus_path = _find_acqus(source.parent)
    acqus = read_bruker_parameters(acqus_path) if acqus_path else {}
    solvent = str(acqus.get("SOLVENT", "CDCl3")).strip("<>")
    nucleus = str(acqus.get("NUC1", "1H")).strip("<>")
    return Spectrum1D(
        ppm=ppm,
        intensity=values,
        spectrometer_mhz=sf,
        nucleus=nucleus,
        solvent=solvent,
        title=source.parents[2].name if len(source.parents) > 2 else source.parent.name,
        metadata={
            "source": str(source),
            "format": "Bruker 1r",
            "procs": params,
            "acqus": acqus,
        },
    )


def read_csv_spectrum(path: str | Path) -> Spectrum1D:
    source = Path(path)
    sample = source.read_text(encoding="utf-8-sig", errors="replace")[:4096]
    try:
        dialect = csv.Sniffer().sniff(sample, delimiters=",;\t ")
        delimiter = dialect.delimiter
    except csv.Error:
        delimiter = ","
    rows: list[tuple[float, float]] = []
    with source.open("r", encoding="utf-8-sig", errors="replace", newline="") as handle:
        reader = csv.reader(handle, delimiter=delimiter, skipinitialspace=True)
        for row in reader:
            if len(row) < 2:
                continue
            try:
                rows.append((float(row[0]), float(row[1])))
            except ValueError:
                continue
    if len(rows) < 8:
        raise NMRDataError("CSV/TSV 至少应包含 8 行数值型 ppm,intensity 数据")
    array = np.asarray(rows, dtype=float)
    return Spectrum1D(
        ppm=array[:, 0],
        intensity=array[:, 1],
        title=source.stem,
        metadata={"source": str(source), "format": "CSV/TSV"},
    )


def read_jcamp_spectrum(path: str | Path) -> Spectrum1D:
    """Read plain-text JCAMP-DX XYDATA/PEAK TABLE files.

    AFFN numeric data are supported.  Vendor-specific SQZ/DIF/DUP compressed
    JCAMP encodings intentionally raise a clear error instead of silently
    producing a wrong axis.
    """
    source = Path(path)
    lines = source.read_text(encoding="latin-1", errors="replace").splitlines()
    headers: dict[str, str] = {}
    data_start = None
    mode = ""
    for i, line in enumerate(lines):
        if line.startswith("##") and "=" in line:
            key, value = line[2:].split("=", 1)
            headers[key.strip().upper()] = value.strip()
            if key.strip().upper() in {"XYDATA", "PEAK TABLE", "PEAKTABLE"}:
                data_start = i + 1
                mode = key.strip().upper()
                break
    if data_start is None:
        raise NMRDataError("JCAMP-DX 中未找到 XYDATA 或 PEAK TABLE")

    xfactor = float(headers.get("XFACTOR", "1"))
    yfactor = float(headers.get("YFACTOR", "1"))
    points: list[tuple[float, float]] = []
    compressed_tokens = re.compile(r"[A-Za-z@%]")
    if mode in {"PEAK TABLE", "PEAKTABLE"}:
        for line in lines[data_start:]:
            if line.startswith("##END"):
                break
            for x, y in re.findall(
                r"([-+]?\d*\.?\d+(?:[Ee][-+]?\d+)?)\s*[,; ]\s*([-+]?\d*\.?\d+(?:[Ee][-+]?\d+)?)",
                line,
            ):
                points.append((float(x) * xfactor, float(y) * yfactor))
    else:
        first_x = float(headers.get("FIRSTX", "0"))
        last_x = float(headers.get("LASTX", "0"))
        npoints = int(float(headers.get("NPOINTS", "0")))
        delta_x = (last_x - first_x) / max(npoints - 1, 1) if npoints else 0.0
        for line in lines[data_start:]:
            if line.startswith("##END"):
                break
            if compressed_tokens.search(line.replace("E", "").replace("e", "")):
                raise NMRDataError("该 JCAMP 使用 SQZ/DIF 压缩；请先导出为 AFFN 或 CSV")
            nums = [float(x) for x in re.findall(r"[-+]?\d*\.?\d+(?:[Ee][-+]?\d+)?", line)]
            if len(nums) < 2:
                continue
            x0 = nums[0] * xfactor
            for j, y in enumerate(nums[1:]):
                points.append((x0 + j * delta_x, y * yfactor))
    if len(points) < 8:
        raise NMRDataError("JCAMP-DX 中有效谱图点不足")
    arr = np.asarray(points, dtype=float)
    observe = float(headers.get(".OBSERVE FREQUENCY", headers.get("OBSERVE FREQUENCY", "400")))
    nucleus = headers.get(".OBSERVE NUCLEUS", headers.get("OBSERVE NUCLEUS", "1H")).strip("^<> ")
    return Spectrum1D(
        ppm=arr[:, 0],
        intensity=arr[:, 1],
        spectrometer_mhz=observe,
        nucleus=nucleus,
        title=headers.get("TITLE", source.stem),
        metadata={"source": str(source), "format": "JCAMP-DX", "headers": headers},
    )


def save_spectrum_csv(spectrum: Spectrum1D, path: str | Path) -> Path:
    destination = Path(path)
    destination.parent.mkdir(parents=True, exist_ok=True)
    header = json.dumps(
        {
            "title": spectrum.title,
            "nucleus": spectrum.nucleus,
            "solvent": spectrum.solvent,
            "spectrometer_mhz": spectrum.spectrometer_mhz,
        },
        ensure_ascii=False,
    )
    np.savetxt(
        destination,
        np.column_stack((spectrum.ppm, spectrum.intensity)),
        delimiter=",",
        header=f"ppm,intensity\nmetadata={header}",
        comments="# ",
    )
    return destination


def load_nmr_data(path: str | Path) -> FID1D | Spectrum1D:
    # Kept as the stable public function while format/vendor knowledge lives in
    # reader plugins.  Future JEOL/Agilent/MS readers can therefore be installed
    # without editing this dispatch function or the desktop UI.
    from .spectral_plugins import SpectralPluginError, default_reader_registry

    source = Path(path)
    try:
        data = default_reader_registry().read(source)
    except SpectralPluginError as exc:
        raise NMRDataError(f"不支持或无法读取的数据格式：{source.name}（{exc}）") from exc
    if not isinstance(data, (FID1D, Spectrum1D)):
        raise NMRDataError(
            f"读取器返回了 {type(data).__name__}；当前 NMR 工作区尚不能显示该模态，"
            "但插件接口已保留给后续质谱/光谱工作区。"
        )
    return data
