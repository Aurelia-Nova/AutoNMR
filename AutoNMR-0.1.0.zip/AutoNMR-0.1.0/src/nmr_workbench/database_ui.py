"""Tk database profile and browser-search window."""

from __future__ import annotations

import re
import webbrowser
from dataclasses import replace
import tkinter as tk
from tkinter import messagebox, ttk

from .databases import DatabaseProfile, DatabaseProfileError, DatabaseProfileStore
from .i18n import Translator


class DatabaseWindow:
    def __init__(self, parent: tk.Misc, translator: Translator) -> None:
        self.parent = parent
        self.tr = translator
        self.store = DatabaseProfileStore()
        self.profiles = self.store.load()
        self.window = tk.Toplevel(parent)
        self.window.title(self.tr.t("database.title"))
        self.window.geometry("980x610")
        self.window.minsize(760, 480)
        self.query_var = tk.StringVar()
        self.status_var = tk.StringVar(value=self._txt("请选择数据库并输入检索词。", "Select a database and enter a query."))
        self._build()
        self._populate()

    def _txt(self, zh, en):
        return en if self.tr.language == "en_US" else zh

    def _build(self) -> None:
        header = ttk.Frame(self.window, padding=(14, 12, 14, 8))
        header.pack(fill=tk.X)
        ttk.Label(header, text=self._txt("数据库检索词", "Database query")).pack(side=tk.LEFT)
        entry = ttk.Entry(header, textvariable=self.query_var)
        entry.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=8)
        entry.bind("<Return>", lambda _event: self.open_search())
        ttk.Button(header, text=self._txt("检索所选", "Search selected"), command=self.open_search).pack(side=tk.LEFT, padx=3)
        ttk.Button(header, text=self._txt("打开主页", "Open home"), command=self.open_home).pack(side=tk.LEFT, padx=3)

        table_frame = ttk.Frame(self.window, padding=(14, 0, 14, 7))
        table_frame.pack(fill=tk.BOTH, expand=True)
        columns = ("enabled", "name", "category", "access", "url")
        self.tree = ttk.Treeview(table_frame, columns=columns, show="headings", selectmode="browse")
        headings = self._txt(
            ("启用", "数据库", "类别", "访问", "地址"),
            ("Enabled", "Database", "Category", "Access", "Address"),
        )
        widths = (65, 175, 160, 110, 380)
        for column, heading, width in zip(columns, headings, widths):
            self.tree.heading(column, text=heading)
            self.tree.column(column, width=width, minwidth=55, stretch=column == "url")
        yscroll = ttk.Scrollbar(table_frame, orient=tk.VERTICAL, command=self.tree.yview)
        self.tree.configure(yscrollcommand=yscroll.set)
        self.tree.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        yscroll.pack(side=tk.RIGHT, fill=tk.Y)
        self.tree.bind("<Double-1>", lambda _event: self.open_search())

        controls = ttk.Frame(self.window, padding=(14, 4, 14, 8))
        controls.pack(fill=tk.X)
        ttk.Button(controls, text=self._txt("启用/停用", "Enable / disable"), command=self.toggle_enabled).pack(side=tk.LEFT, padx=3)
        ttk.Button(controls, text=self._txt("新增自定义网址", "Add custom URL"), command=self.add_profile).pack(side=tk.LEFT, padx=3)
        ttk.Button(controls, text=self._txt("编辑自定义项", "Edit custom"), command=self.edit_profile).pack(side=tk.LEFT, padx=3)
        ttk.Button(controls, text=self._txt("删除自定义项", "Delete custom"), command=self.delete_profile).pack(side=tk.LEFT, padx=3)
        ttk.Button(controls, text=self._txt("恢复默认", "Restore defaults"), command=self.reset_profiles).pack(side=tk.RIGHT, padx=3)

        note = self._txt(
            "仅在浏览器中打开检索，不保存 Reaxys、SciFinder 等订阅数据库密码，也不会绕过登录或许可限制。自建库优先使用 HTTPS；局域网 HTTP 必须在自定义项中明确允许。",
            "Searches open in the browser. Subscription credentials are never stored and login or licence limits are never bypassed. Prefer HTTPS for a private database; LAN HTTP requires explicit approval in the custom profile.",
        )
        ttk.Label(self.window, text=note, wraplength=930, foreground="#536273", padding=(14, 4)).pack(fill=tk.X)
        ttk.Label(self.window, textvariable=self.status_var, relief=tk.SUNKEN, anchor=tk.W, padding=(8, 4)).pack(fill=tk.X)

    def _populate(self, select_id: str | None = None) -> None:
        self.tree.delete(*self.tree.get_children())
        for profile in self.profiles:
            self.tree.insert(
                "",
                tk.END,
                iid=profile.id,
                values=("✓" if profile.enabled else "", profile.name, profile.category, profile.access, profile.home_url),
            )
        target = select_id or next((item.id for item in self.profiles if item.enabled), None)
        if target and self.tree.exists(target):
            self.tree.selection_set(target)
            self.tree.focus(target)

    def _selected(self) -> DatabaseProfile | None:
        selected = self.tree.selection()
        if not selected:
            return None
        return next((item for item in self.profiles if item.id == selected[0]), None)

    def _persist(self, select_id: str | None = None) -> None:
        self.store.save(self.profiles)
        self._populate(select_id)

    def open_search(self) -> None:
        profile = self._selected()
        if profile is None:
            messagebox.showinfo(self.tr.t("database.title"), self._txt("请先选择数据库。", "Select a database first."), parent=self.window)
            return
        try:
            url = profile.build_url(self.query_var.get().strip())
            webbrowser.open_new_tab(url)
            self.status_var.set(self._txt(f"已在浏览器打开 {profile.name}。", f"Opened {profile.name} in the browser."))
        except Exception as exc:
            messagebox.showerror(self.tr.t("database.title"), str(exc), parent=self.window)

    def open_home(self) -> None:
        profile = self._selected()
        if profile:
            webbrowser.open_new_tab(profile.validated().home_url)

    def toggle_enabled(self) -> None:
        profile = self._selected()
        if profile is None:
            return
        self.profiles = [replace(item, enabled=not item.enabled) if item.id == profile.id else item for item in self.profiles]
        self._persist(profile.id)

    def add_profile(self) -> None:
        editor = _ProfileEditor(self.window, self.tr)
        self.window.wait_window(editor.window)
        if editor.result is None:
            return
        if any(item.id == editor.result.id for item in self.profiles):
            messagebox.showerror(self.tr.t("database.title"), self._txt("该标识已存在。", "That profile id already exists."), parent=self.window)
            return
        self.profiles.append(editor.result)
        self._persist(editor.result.id)

    def edit_profile(self) -> None:
        profile = self._selected()
        if profile is None:
            return
        if not profile.custom:
            messagebox.showinfo(self.tr.t("database.title"), self._txt("内置项只能启用或停用；可新增自定义项覆盖你的工作流。", "Built-in profiles can only be enabled or disabled. Add a custom profile for a different workflow."), parent=self.window)
            return
        editor = _ProfileEditor(self.window, self.tr, profile)
        self.window.wait_window(editor.window)
        if editor.result is None:
            return
        self.profiles = [editor.result if item.id == profile.id else item for item in self.profiles]
        self._persist(editor.result.id)

    def delete_profile(self) -> None:
        profile = self._selected()
        if profile is None or not profile.custom:
            return
        if messagebox.askyesno(self.tr.t("database.title"), self._txt(f"删除自定义项 {profile.name}？", f"Delete custom profile {profile.name}?"), parent=self.window):
            self.profiles = [item for item in self.profiles if item.id != profile.id]
            self._persist()

    def reset_profiles(self) -> None:
        if messagebox.askyesno(self.tr.t("database.title"), self._txt("恢复内置数据库列表并删除全部自定义项？", "Restore built-in profiles and remove all custom profiles?"), parent=self.window):
            self.profiles = self.store.reset()
            self._populate()


class _ProfileEditor:
    def __init__(self, parent: tk.Misc, translator: Translator, profile: DatabaseProfile | None = None) -> None:
        self.tr = translator
        self.result: DatabaseProfile | None = None
        self.original = profile
        self.window = tk.Toplevel(parent)
        self.window.title(self._txt("自定义数据库", "Custom database"))
        self.window.transient(parent)
        self.window.grab_set()
        self.window.resizable(False, False)
        self.name_var = tk.StringVar(value=profile.name if profile else "")
        self.id_var = tk.StringVar(value=profile.id if profile else "")
        self.home_var = tk.StringVar(value=profile.home_url if profile else "https://")
        self.search_var = tk.StringVar(value=profile.search_url if profile else "")
        self.insecure_var = tk.BooleanVar(value=profile.allow_insecure_local if profile else False)
        frame = ttk.Frame(self.window, padding=14)
        frame.pack(fill=tk.BOTH, expand=True)
        labels = self._txt(("名称", "标识", "主页 URL", "检索 URL 模板"), ("Name", "ID", "Home URL", "Search URL template"))
        variables = (self.name_var, self.id_var, self.home_var, self.search_var)
        for row, (label, variable) in enumerate(zip(labels, variables)):
            ttk.Label(frame, text=label).grid(row=row, column=0, sticky=tk.W, padx=3, pady=5)
            ttk.Entry(frame, textvariable=variable, width=70).grid(row=row, column=1, sticky=tk.EW, padx=3, pady=5)
        ttk.Label(frame, text=self._txt("模板可使用 {query}、{smiles}、{formula}、{inchi_key} 或 {cas}", "Template fields: {query}, {smiles}, {formula}, {inchi_key}, or {cas}"), foreground="#536273").grid(row=4, column=1, sticky=tk.W, padx=3)
        ttk.Checkbutton(frame, text=self._txt("明确允许本机/局域网使用 HTTP（仅内部测试）", "Explicitly allow HTTP for localhost/LAN (internal testing only)"), variable=self.insecure_var).grid(row=5, column=0, columnspan=2, sticky=tk.W, pady=7)
        buttons = ttk.Frame(frame)
        buttons.grid(row=6, column=0, columnspan=2, sticky=tk.E, pady=(10, 0))
        ttk.Button(buttons, text=self._txt("取消", "Cancel"), command=self.window.destroy).pack(side=tk.RIGHT, padx=3)
        ttk.Button(buttons, text=self._txt("保存", "Save"), command=self.save).pack(side=tk.RIGHT, padx=3)
        frame.columnconfigure(1, weight=1)

    def _txt(self, zh, en):
        return en if self.tr.language == "en_US" else zh

    def save(self) -> None:
        profile_id = self.id_var.get().strip().casefold()
        if not profile_id:
            profile_id = re.sub(r"[^a-z0-9._-]+", "-", self.name_var.get().strip().casefold()).strip("-")[:60]
            if len(profile_id) < 2:
                profile_id = "custom-db"
        try:
            self.result = DatabaseProfile(
                id=self.original.id if self.original else profile_id,
                name=self.name_var.get(),
                category="custom",
                home_url=self.home_var.get(),
                search_url=self.search_var.get(),
                enabled=True,
                access="custom",
                notes="User-defined database profile",
                custom=True,
                allow_insecure_local=bool(self.insecure_var.get()),
            ).validated()
        except DatabaseProfileError as exc:
            messagebox.showerror(self.tr.t("database.title"), str(exc), parent=self.window)
            return
        self.window.destroy()
