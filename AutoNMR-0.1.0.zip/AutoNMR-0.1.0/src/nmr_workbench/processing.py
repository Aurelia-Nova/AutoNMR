from __future__ import annotations

from dataclasses import asdict, dataclass
from typing import Literal

import numpy as np
from scipy import sparse
from scipy.ndimage import median_filter
from scipy.optimize import minimize
from scipy.sparse.linalg import spsolve

from .models import FID1D, Spectrum1D


@dataclass(slots=True)
class ProcessingConfig:
    apodization: Literal["exponential", "gaussian", "sinebell", "none"] = "exponential"
    line_broadening_hz: float = 0.3
    gaussian_broadening_hz: float = 0.2
    sinebell_offset: float = 0.05
    sinebell_power: float = 1.0
    zero_fill_factor: int = 2
    remove_group_delay: bool = True
    remove_dc: bool = True
    auto_phase: bool = True
    ph0_deg: float = 0.0
    ph1_deg: float = 0.0
    baseline_method: Literal["asls", "polynomial", "none"] = "asls"
    baseline_lambda: float = 1.0e6
    baseline_asymmetry: float = 0.002
    baseline_iterations: int = 8
    polynomial_order: int = 3
    auto_polarity: bool = True

    def validate(self) -> None:
        if self.zero_fill_factor < 1 or self.zero_fill_factor > 16:
            raise ValueError("zero_fill_factor 应在 1–16 之间")
        if self.line_broadening_hz < 0 or self.gaussian_broadening_hz < 0:
            raise ValueError("展宽参数不能为负")
        if not (0 < self.baseline_asymmetry < 1):
            raise ValueError("baseline_asymmetry 必须在 0–1 之间")
        if self.baseline_lambda <= 0:
            raise ValueError("baseline_lambda 必须为正数")


def next_power_of_two(value: int) -> int:
    return 1 if value <= 1 else 1 << (value - 1).bit_length()


def apodization_window(length: int, dwell_time_s: float, config: ProcessingConfig) -> np.ndarray:
    if length < 1:
        return np.empty(0, dtype=float)
    time = np.arange(length, dtype=float) * dwell_time_s
    if config.apodization == "none":
        return np.ones(length, dtype=float)
    if config.apodization == "exponential":
        return np.exp(-np.pi * config.line_broadening_hz * time)
    if config.apodization == "gaussian":
        # FWHM-like user parameter, expressed in Hz.
        return np.exp(-((np.pi * config.gaussian_broadening_hz * time) ** 2) / (4.0 * np.log(2.0)))
    if config.apodization == "sinebell":
        fraction = np.linspace(0.0, 1.0, length)
        angle = np.pi * (config.sinebell_offset + (1.0 - config.sinebell_offset) * fraction)
        return np.clip(np.sin(angle), 0.0, None) ** config.sinebell_power
    raise ValueError(f"未知窗函数：{config.apodization}")


def apply_phase(
    complex_spectrum: np.ndarray,
    ph0_deg: float,
    ph1_deg: float,
    pivot_fraction: float = 0.5,
) -> np.ndarray:
    values = np.asarray(complex_spectrum, dtype=np.complex128)
    ramp = np.linspace(0.0, 1.0, values.size) - float(pivot_fraction)
    phase = np.deg2rad(ph0_deg + ph1_deg * ramp)
    return values * np.exp(1j * phase)


def _phase_objective(phases: np.ndarray, data: np.ndarray) -> float:
    phased = apply_phase(data, float(phases[0]), float(phases[1]))
    real = phased.real
    scale = np.percentile(np.abs(real), 99.5) + np.finfo(float).eps
    real = real / scale

    derivative = np.abs(np.diff(real))
    derivative = derivative / (derivative.sum() + np.finfo(float).eps)
    derivative = derivative[derivative > 1e-12]
    entropy = -float(np.sum(derivative * np.log(derivative)))

    negative = np.minimum(real, 0.0)
    negative_penalty = float(np.mean(negative**2))
    # The imaginary channel is dispersive even at the correct absorption phase,
    # so minimizing it biases the solution. Negative real area is the stronger
    # physical constraint. A light first-order regularizer prevents noise-only
    # edge regions from driving a large phase ramp.
    first_order_guard = (float(phases[1]) / 90.0) ** 2
    return entropy + 2000.0 * negative_penalty + 0.80 * first_order_guard


def estimate_auto_phase(complex_spectrum: np.ndarray) -> tuple[float, float, float]:
    """Estimate zero/first-order phase and return (ph0, ph1, objective).

    A bounded, multistart entropy/negative-area optimizer is intentionally used
    here: it is deterministic, explainable and does not require a proprietary
    trained model.  It works well for routine positive-mode 1H spectra; spectra
    with severe truncation or mixed-phase components should be adjusted manually.
    """
    data = np.asarray(complex_spectrum, dtype=np.complex128)
    if data.size > 8192:
        indices = np.linspace(0, data.size - 1, 8192).astype(int)
        work = data[indices]
    else:
        work = data
    work = work - np.median(work.real) - 1j * np.median(work.imag)
    starts = [
        np.array([0.0, 0.0]),
        np.array([90.0, 0.0]),
        np.array([-90.0, 0.0]),
        np.array([180.0, 0.0]),
    ]
    best = None
    for start in starts:
        result = minimize(
            _phase_objective,
            start,
            args=(work,),
            method="Powell",
            bounds=((-180.0, 180.0), (-180.0, 180.0)),
            options={"maxiter": 180, "xtol": 0.05, "ftol": 1e-7},
        )
        if best is None or result.fun < best.fun:
            best = result
    assert best is not None
    ph0 = ((float(best.x[0]) + 180.0) % 360.0) - 180.0
    ph1 = float(np.clip(best.x[1], -180.0, 180.0))
    return ph0, ph1, float(best.fun)


def asymmetric_least_squares(
    values: np.ndarray,
    lam: float = 1.0e6,
    asymmetry: float = 0.002,
    iterations: int = 8,
    max_solver_points: int = 16000,
) -> np.ndarray:
    """Estimate a smooth baseline by asymmetric penalized least squares."""
    y = np.asarray(values, dtype=float)
    if y.size < 5:
        return np.zeros_like(y)
    if y.size > max_solver_points:
        indices = np.linspace(0, y.size - 1, max_solver_points).astype(int)
        coarse = asymmetric_least_squares(
            y[indices], lam, asymmetry, iterations, max_solver_points=max_solver_points + 1
        )
        return np.interp(np.arange(y.size), indices, coarse)
    n = y.size
    difference = sparse.diags([1.0, -2.0, 1.0], [0, 1, 2], shape=(n - 2, n), format="csc")
    penalty = lam * (difference.T @ difference)
    weights = np.ones(n, dtype=float)
    baseline = np.zeros(n, dtype=float)
    for _ in range(max(1, int(iterations))):
        weight_matrix = sparse.spdiags(weights, 0, n, n)
        baseline = spsolve(weight_matrix + penalty, weights * y)
        weights = np.where(y > baseline, asymmetry, 1.0 - asymmetry)
    return np.asarray(baseline, dtype=float)


def polynomial_baseline(values: np.ndarray, order: int = 3) -> np.ndarray:
    y = np.asarray(values, dtype=float)
    n = y.size
    if n < order + 3:
        return np.zeros_like(y)
    x = np.linspace(-1.0, 1.0, n)
    smooth_width = max(5, (n // 100) | 1)
    trend = median_filter(y, size=smooth_width, mode="nearest")
    residual = y - trend
    threshold = np.percentile(np.abs(residual), 60.0)
    mask = np.abs(residual) <= threshold
    for _ in range(3):
        coefficients = np.polyfit(x[mask], y[mask], min(order, int(mask.sum()) - 1))
        fitted = np.polyval(coefficients, x)
        deviation = y - fitted
        sigma = 1.4826 * np.median(np.abs(deviation[mask] - np.median(deviation[mask])))
        mask = deviation < max(3.0 * sigma, np.finfo(float).eps)
    return fitted


def correct_baseline(spectrum: Spectrum1D, config: ProcessingConfig) -> Spectrum1D:
    y = spectrum.intensity
    if config.baseline_method == "none":
        return spectrum.copy(metadata={**spectrum.metadata, "baseline": "none"})
    if config.baseline_method == "asls":
        baseline = asymmetric_least_squares(
            y,
            lam=config.baseline_lambda,
            asymmetry=config.baseline_asymmetry,
            iterations=config.baseline_iterations,
        )
    elif config.baseline_method == "polynomial":
        baseline = polynomial_baseline(y, config.polynomial_order)
    else:
        raise ValueError(f"未知基线方法：{config.baseline_method}")
    return spectrum.copy(
        intensity=y - baseline,
        metadata={
            **spectrum.metadata,
            "baseline": config.baseline_method,
            "baseline_rms": float(np.sqrt(np.mean(baseline**2))),
        },
    )


def auto_polarity(values: np.ndarray) -> tuple[np.ndarray, bool]:
    y = np.asarray(values, dtype=float)
    high = float(np.percentile(y, 99.9))
    low = abs(float(np.percentile(y, 0.1)))
    inverted = low > high * 1.15
    return (-y if inverted else y), inverted


def process_fid(fid: FID1D, config: ProcessingConfig | None = None) -> Spectrum1D:
    config = config or ProcessingConfig()
    config.validate()
    data = fid.data.copy()
    removed_points = 0
    if config.remove_group_delay and fid.group_delay_points > 0:
        removed_points = max(0, min(int(round(fid.group_delay_points)), data.size // 4))
        if removed_points:
            data = data[removed_points:]
    if config.remove_dc:
        tail = data[max(0, int(data.size * 0.8)) :]
        data = data - np.mean(tail)
    data *= apodization_window(data.size, fid.dwell_time_s, config)
    target_size = next_power_of_two(data.size * config.zero_fill_factor)
    frequency_domain = np.fft.fftshift(np.fft.fft(data, n=target_size))

    if config.auto_phase:
        ph0, ph1, phase_objective = estimate_auto_phase(frequency_domain)
    else:
        ph0, ph1, phase_objective = config.ph0_deg, config.ph1_deg, float("nan")
    frequency_domain = apply_phase(frequency_domain, ph0, ph1)
    intensity = frequency_domain.real
    inverted = False
    if config.auto_polarity:
        intensity, inverted = auto_polarity(intensity)

    frequencies_hz = np.fft.fftshift(np.fft.fftfreq(target_size, d=fid.dwell_time_s))
    ppm = fid.carrier_ppm + frequencies_hz / fid.spectrometer_mhz
    spectrum = Spectrum1D(
        ppm=ppm,
        intensity=intensity,
        spectrometer_mhz=fid.spectrometer_mhz,
        nucleus=fid.nucleus,
        solvent=fid.solvent,
        title=fid.title,
        metadata={
            **fid.metadata,
            "processing": asdict(config),
            "ph0_deg": ph0,
            "ph1_deg": ph1,
            "phase_objective": phase_objective,
            "group_delay_points_removed": removed_points,
            "polarity_inverted": inverted,
            "original_points": int(fid.data.size),
            "processed_points": int(target_size),
        },
    )
    return correct_baseline(spectrum, config)


def rephase_spectrum(spectrum: Spectrum1D, ph0_deg: float) -> Spectrum1D:
    """Apply a display-level zero-order phase approximation to a real spectrum.

    True first-order rephasing requires the retained complex spectrum.  This
    helper is deliberately limited and labeled for imported real-only data.
    """
    radians = np.deg2rad(ph0_deg)
    adjusted = spectrum.intensity * np.cos(radians)
    return spectrum.copy(
        intensity=adjusted,
        metadata={**spectrum.metadata, "real_only_phase_deg": float(ph0_deg)},
    )


def reference_spectrum(
    spectrum: Spectrum1D, observed_ppm: float, target_ppm: float
) -> Spectrum1D:
    delta = float(target_ppm) - float(observed_ppm)
    return spectrum.copy(
        ppm=spectrum.ppm + delta,
        metadata={
            **spectrum.metadata,
            "reference": {
                "observed_ppm": float(observed_ppm),
                "target_ppm": float(target_ppm),
                "shift_applied_ppm": delta,
            },
        },
    )
