"""JSON-backed user-interface translations and font fallback configuration."""

from __future__ import annotations

import json
import platform
from importlib.resources import files


SUPPORTED_LANGUAGES = {"zh_CN": "简体中文", "en_US": "English"}


class Translator:
    def __init__(self, language: str = "zh_CN") -> None:
        self.language = language if language in SUPPORTED_LANGUAGES else "zh_CN"
        self._fallback = self._load("zh_CN")
        self._messages = self._load(self.language)

    @staticmethod
    def _load(language: str) -> dict[str, str]:
        resource = files("nmr_workbench").joinpath("data", "locales", f"{language}.json")
        payload = json.loads(resource.read_text(encoding="utf-8"))
        return {str(key): str(value) for key, value in payload.items()}

    def t(self, key: str, **values: object) -> str:
        template = self._messages.get(key, self._fallback.get(key, key))
        try:
            return template.format(**values)
        except (KeyError, ValueError):
            return template


def preferred_ui_font() -> str:
    system = platform.system()
    candidates = {
        "Windows": ("Microsoft YaHei UI", "Microsoft YaHei", "Segoe UI"),
        "Darwin": ("PingFang SC", "Helvetica Neue", "Arial Unicode MS"),
    }.get(system, ("Noto Sans CJK SC", "WenQuanYi Micro Hei", "DejaVu Sans"))
    try:
        import tkinter.font as tkfont

        names = {name.casefold(): name for name in tkfont.families()}
        for candidate in candidates:
            if candidate.casefold() in names:
                return names[candidate.casefold()]
    except Exception:
        pass
    return candidates[-1]


def configure_matplotlib_fonts(language: str = "zh_CN") -> str:
    """Select a real CJK-capable font before any translated plot text is drawn."""

    from matplotlib import font_manager, rcParams

    candidates = (
        "Microsoft YaHei UI",
        "Microsoft YaHei",
        "SimHei",
        "PingFang SC",
        "Noto Sans CJK SC",
        "Source Han Sans SC",
        "WenQuanYi Micro Hei",
        "Arial Unicode MS",
        "DejaVu Sans",
    )
    installed = {item.name.casefold(): item.name for item in font_manager.fontManager.ttflist}
    selected = "DejaVu Sans"
    for candidate in candidates:
        if candidate.casefold() in installed:
            selected = installed[candidate.casefold()]
            break
    rcParams["font.family"] = "sans-serif"
    rcParams["font.sans-serif"] = [selected, "DejaVu Sans"]
    rcParams["axes.unicode_minus"] = False
    return selected


def matplotlib_font_supports_cjk(font_name: str) -> bool:
    """Verify glyph coverage instead of assuming it from a family name."""

    try:
        from matplotlib import font_manager, ft2font

        path = font_manager.findfont(
            font_manager.FontProperties(family=font_name), fallback_to_default=False
        )
        characters = ft2font.FT2Font(path).get_charmap()
        return all(ord(character) in characters for character in "核磁谱图")
    except Exception:
        return False
