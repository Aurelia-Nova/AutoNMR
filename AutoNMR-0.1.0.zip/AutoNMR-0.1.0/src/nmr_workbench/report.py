from __future__ import annotations

import html
import json
from pathlib import Path

import numpy as np

from . import __version__

from .models import AnalysisReport, Spectrum1D


def _fmt(value: float | None, digits: int = 2) -> str:
    return "—" if value is None else f"{value:.{digits}f}"


def spectrum_svg(spectrum: Spectrum1D, report: AnalysisReport, width: int = 1180, height: int = 390) -> str:
    x = spectrum.ppm
    y = spectrum.intensity
    if x.size > 5000:
        idx = np.linspace(0, x.size - 1, 5000).astype(int)
        x, y = x[idx], y[idx]
    high, low = float(np.max(x)), float(np.min(x))
    y_low = float(np.percentile(y, 0.2))
    y_high = float(np.percentile(y, 99.85))
    if y_high <= y_low:
        y_high = y_low + 1.0
    margin_left, margin_right, margin_top, margin_bottom = 55, 25, 24, 46
    plot_w = width - margin_left - margin_right
    plot_h = height - margin_top - margin_bottom

    def sx(value: float) -> float:
        return margin_left + (high - value) / max(high - low, 1e-12) * plot_w

    def sy(value: float) -> float:
        clipped = np.clip(value, y_low, y_high)
        return margin_top + (y_high - clipped) / (y_high - y_low) * plot_h

    points = " ".join(f"{sx(float(px)):.1f},{sy(float(py)):.1f}" for px, py in zip(x, y))
    ticks = []
    start, end = int(np.floor(low)), int(np.ceil(high))
    for tick in range(start, end + 1):
        tx = sx(float(tick))
        ticks.append(
            f'<line x1="{tx:.1f}" y1="{height-margin_bottom}" x2="{tx:.1f}" y2="{height-margin_bottom+5}" stroke="#475569"/>'
            f'<text x="{tx:.1f}" y="{height-18}" text-anchor="middle" font-size="11" fill="#475569">{tick}</text>'
        )
    labels = []
    for signal in report.signals:
        px = sx(signal.center_ppm)
        labels.append(
            f'<line x1="{px:.1f}" y1="{margin_top}" x2="{px:.1f}" y2="{margin_top+12}" stroke="#c2410c"/>'
            f'<text x="{px:.1f}" y="{margin_top-5}" transform="rotate(-55 {px:.1f},{margin_top-5})" '
            f'text-anchor="start" font-size="9" fill="#9a3412">{signal.center_ppm:.3f}</text>'
        )
    return (
        f'<svg viewBox="0 0 {width} {height}" role="img" aria-label="1D NMR spectrum">'
        f'<rect width="100%" height="100%" fill="white"/>'
        f'<line x1="{margin_left}" y1="{height-margin_bottom}" x2="{width-margin_right}" y2="{height-margin_bottom}" stroke="#475569"/>'
        + "".join(ticks)
        + f'<polyline points="{points}" fill="none" stroke="#0f172a" stroke-width="1" vector-effect="non-scaling-stroke"/>'
        + "".join(labels)
        + f'<text x="{width/2:.1f}" y="{height-2}" text-anchor="middle" font-size="12" fill="#334155">δ / ppm</text>'
        + "</svg>"
    )


def report_html(report: AnalysisReport, spectrum: Spectrum1D) -> str:
    signal_rows = []
    for index, signal in enumerate(report.signals, 1):
        coupling = ", ".join(f"{j:.1f}" for j in signal.coupling_hz) or "—"
        reference = (
            f"{html.escape(signal.reference_match.name)} ({signal.reference_match.score:.0f})"
            if signal.reference_match
            else "—"
        )
        signal_rows.append(
            "<tr>"
            f"<td>{index}</td><td>{signal.center_ppm:.3f}</td><td>{html.escape(signal.multiplicity)}</td>"
            f"<td>{_fmt(signal.relative_integral)}</td><td>{_fmt(signal.estimated_protons)}</td>"
            f"<td>{coupling}</td><td>{html.escape(signal.region)}</td><td>{reference}</td>"
            f"<td>{signal.confidence:.0f}</td></tr>"
        )
    fragment_rows = "".join(
        f"<tr><td>{html.escape(item.label)}</td><td>{html.escape(item.evidence)}</td><td>{item.confidence:.0f}</td></tr>"
        for item in report.fragments
    ) or '<tr><td colspan="3">未生成具有足够证据的片段提示</td></tr>'
    candidate_rows = "".join(
        f"<tr><td>{index}</td><td>{html.escape(item.name)}</td><td>{item.score:.1f}</td>"
        f"<td>{item.matched}/{item.expected}</td><td>{_fmt(item.shift_rmse, 3)}</td>"
        f"<td>{html.escape(item.formula)}</td><td><code>{html.escape(item.smiles)}</code></td></tr>"
        for index, item in enumerate(report.candidates, 1)
    ) or '<tr><td colspan="7">未载入候选结构库</td></tr>'
    warning_items = "".join(f"<li>{html.escape(item)}</li>" for item in report.warnings) or "<li>未发现明显质量警告。</li>"
    json_payload = html.escape(json.dumps(report.to_dict(), ensure_ascii=False))
    return f"""<!doctype html>
<html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>{html.escape(report.title)} — NMR 自动解谱报告</title>
<style>
body{{font-family:Inter,"Microsoft YaHei",Arial,sans-serif;margin:0;background:#f5f7fa;color:#172033;line-height:1.55}}
main{{max-width:1240px;margin:24px auto;background:white;padding:32px 40px;border:1px solid #dce3ea;border-radius:14px;box-shadow:0 8px 30px #24364b12}}
h1{{font-size:25px;margin:0 0 5px}} h2{{font-size:18px;margin-top:30px;border-bottom:1px solid #dce3ea;padding-bottom:7px}}
.meta{{color:#526174}} .metrics{{display:flex;gap:12px;flex-wrap:wrap;margin:18px 0}}
.metric{{background:#eef4f6;border-radius:8px;padding:9px 15px}} .metric b{{font-size:18px;color:#0b5963}}
.plot{{border:1px solid #dce3ea;border-radius:9px;overflow:hidden}}
table{{width:100%;border-collapse:collapse;font-size:13px}} th{{background:#edf3f5;text-align:left}} th,td{{border:1px solid #d8e0e6;padding:7px 8px;vertical-align:top}}
.notice{{background:#fff8e6;border-left:4px solid #d79716;padding:10px 14px}} code{{font-size:12px}}
footer{{margin-top:30px;color:#66778a;font-size:12px}}
@media print{{body{{background:white}} main{{box-shadow:none;border:0;margin:0;max-width:none}}}}
</style></head><body><main>
<h1>NMR 自动解谱报告</h1><div class="meta">{html.escape(report.title)} · {html.escape(report.nucleus)} · {html.escape(report.solvent)} · {report.spectrometer_mhz:.2f} MHz</div>
<div class="metrics"><div class="metric">质量评分<br><b>{report.quality_score:.0f}/100</b></div><div class="metric">信号数<br><b>{len(report.signals)}</b></div><div class="metric">噪声 σ<br><b>{report.noise_sigma:.3g}</b></div></div>
<div class="plot">{spectrum_svg(spectrum, report)}</div>
<h2>信号表</h2><table><thead><tr><th>#</th><th>δ / ppm</th><th>多重性</th><th>相对积分</th><th>估算 H</th><th>J / Hz</th><th>位移区域</th><th>参考物匹配</th><th>置信度</th></tr></thead><tbody>{''.join(signal_rows)}</tbody></table>
<h2>结构片段提示</h2><table><thead><tr><th>提示</th><th>证据</th><th>置信度</th></tr></thead><tbody>{fragment_rows}</tbody></table>
<h2>候选结构排序</h2><table><thead><tr><th>#</th><th>候选物</th><th>得分</th><th>匹配</th><th>位移 RMSE</th><th>分子式</th><th>SMILES</th></tr></thead><tbody>{candidate_rows}</tbody></table>
<h2>质量与解释边界</h2><div class="notice"><ul>{warning_items}</ul><p>候选得分是实验信号与候选库预期信号的一致性评分，并非结构鉴定证明。未知物的唯一结构确定通常还需要 13C、DEPT、COSY、HSQC、HMBC、NOE/ROE 与 HRMS 等互补证据。</p></div>
<footer>Generated by Open NMR Workbench {__version__} · 可解释本地规则与候选验证引擎</footer>
<script type="application/json" id="nmr-report-data">{json_payload}</script>
</main></body></html>"""


def write_report(report: AnalysisReport, spectrum: Spectrum1D, path: str | Path) -> Path:
    destination = Path(path)
    destination.parent.mkdir(parents=True, exist_ok=True)
    if destination.suffix.lower() == ".json":
        destination.write_text(json.dumps(report.to_dict(), ensure_ascii=False, indent=2), encoding="utf-8")
    else:
        destination.write_text(report_html(report, spectrum), encoding="utf-8")
    return destination
