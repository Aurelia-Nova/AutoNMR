"""Small, forward-compatible application settings store."""

from __future__ import annotations

import json
from dataclasses import asdict, dataclass
from pathlib import Path

from .app_paths import settings_path


@dataclass(slots=True)
class AppSettings:
    schema_version: int = 1
    language: str = "zh_CN"
    theme: str = "light"
    allow_guest: bool = True
    last_database_id: str = "pubchem"

    @classmethod
    def from_mapping(cls, payload: dict[str, object]) -> "AppSettings":
        language = str(payload.get("language", "zh_CN"))
        if language not in {"zh_CN", "en_US"}:
            language = "zh_CN"
        theme = str(payload.get("theme", "light"))
        if theme not in {"light", "system"}:
            theme = "light"
        return cls(
            schema_version=1,
            language=language,
            theme=theme,
            allow_guest=bool(payload.get("allow_guest", True)),
            last_database_id=str(payload.get("last_database_id", "pubchem")),
        )


def load_settings(path: str | Path | None = None) -> AppSettings:
    source = Path(path) if path is not None else settings_path()
    if not source.exists():
        return AppSettings()
    try:
        payload = json.loads(source.read_text(encoding="utf-8"))
        return AppSettings.from_mapping(payload if isinstance(payload, dict) else {})
    except (OSError, ValueError, TypeError):
        return AppSettings()


def save_settings(settings: AppSettings, path: str | Path | None = None) -> Path:
    destination = Path(path) if path is not None else settings_path()
    destination.parent.mkdir(parents=True, exist_ok=True)
    temporary = destination.with_suffix(destination.suffix + ".tmp")
    temporary.write_text(
        json.dumps(asdict(settings), ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    temporary.replace(destination)
    return destination

