"""Bounded reversible-operation history used by spectrum and drawing views."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Generic, TypeVar


T = TypeVar("T")


@dataclass(slots=True)
class HistoryEntry(Generic[T]):
    label: str
    state: T
    approximate_bytes: int = 0


class OperationHistory(Generic[T]):
    """Store states from immediately before an operation.

    Large spectra make an unbounded snapshot history unsafe.  Both entry count
    and estimated memory are bounded; eviction always removes the oldest state.
    """

    def __init__(self, *, max_entries: int = 30, max_bytes: int = 192 * 1024 * 1024) -> None:
        self.max_entries = max(1, int(max_entries))
        self.max_bytes = max(1, int(max_bytes))
        self._undo: list[HistoryEntry[T]] = []
        self._redo: list[HistoryEntry[T]] = []

    @property
    def can_undo(self) -> bool:
        return bool(self._undo)

    @property
    def can_redo(self) -> bool:
        return bool(self._redo)

    @property
    def undo_label(self) -> str:
        return self._undo[-1].label if self._undo else ""

    @property
    def redo_label(self) -> str:
        return self._redo[-1].label if self._redo else ""

    def record(self, label: str, state_before: T, *, approximate_bytes: int = 0) -> None:
        self._undo.append(HistoryEntry(label, state_before, max(0, int(approximate_bytes))))
        self._redo.clear()
        self._trim(self._undo)

    def undo(self, current_state: T, *, approximate_bytes: int = 0) -> HistoryEntry[T] | None:
        if not self._undo:
            return None
        entry = self._undo.pop()
        self._redo.append(HistoryEntry(entry.label, current_state, max(0, int(approximate_bytes))))
        self._trim(self._redo)
        return entry

    def redo(self, current_state: T, *, approximate_bytes: int = 0) -> HistoryEntry[T] | None:
        if not self._redo:
            return None
        entry = self._redo.pop()
        self._undo.append(HistoryEntry(entry.label, current_state, max(0, int(approximate_bytes))))
        self._trim(self._undo)
        return entry

    def clear(self) -> None:
        self._undo.clear()
        self._redo.clear()

    def _trim(self, stack: list[HistoryEntry[T]]) -> None:
        while len(stack) > self.max_entries:
            stack.pop(0)
        while len(stack) > 1 and sum(item.approximate_bytes for item in stack) > self.max_bytes:
            stack.pop(0)

