from __future__ import annotations

import csv
import json
from dataclasses import dataclass, field
from importlib.resources import files
from pathlib import Path

import numpy as np
from scipy.optimize import linear_sum_assignment, nnls

from .formula import formulas_equal
from .models import CandidateScore, Signal


@dataclass(slots=True)
class ExpectedSignal:
    shift: float
    multiplicity: str = "m"
    protons: float = 1.0
    tolerance: float = 0.20


@dataclass(slots=True)
class Candidate:
    name: str
    formula: str = ""
    smiles: str = ""
    signals: list[ExpectedSignal] = field(default_factory=list)


def _candidate_from_mapping(item: dict) -> Candidate:
    signals = [
        ExpectedSignal(
            shift=float(signal["shift"]),
            multiplicity=str(signal.get("multiplicity", "m")),
            protons=float(signal.get("protons", 1.0)),
            tolerance=float(signal.get("tolerance", 0.20)),
        )
        for signal in item.get("signals", [])
    ]
    return Candidate(
        name=str(item.get("name", "Unnamed candidate")),
        formula=str(item.get("formula", "")),
        smiles=str(item.get("smiles", "")),
        signals=signals,
    )


def load_candidate_library(path: str | Path | None = None) -> list[Candidate]:
    """Load JSON candidates or a CSV with a JSON-encoded ``signals`` column."""
    if path is None:
        resource = files("nmr_workbench").joinpath("data/demo_candidates.json")
        raw = json.loads(resource.read_text(encoding="utf-8"))
        return [_candidate_from_mapping(item) for item in raw]
    source = Path(path)
    if source.suffix.lower() == ".json":
        raw = json.loads(source.read_text(encoding="utf-8-sig"))
        if isinstance(raw, dict):
            raw = raw.get("candidates", [])
        return [_candidate_from_mapping(item) for item in raw]
    if source.suffix.lower() in {".csv", ".tsv"}:
        delimiter = "\t" if source.suffix.lower() == ".tsv" else ","
        candidates = []
        with source.open("r", encoding="utf-8-sig", newline="") as handle:
            for row in csv.DictReader(handle, delimiter=delimiter):
                item = dict(row)
                try:
                    item["signals"] = json.loads(item.get("signals", "[]"))
                except json.JSONDecodeError as exc:
                    raise ValueError(f"候选库 signals 列不是合法 JSON：{row.get('name', '')}") from exc
                candidates.append(_candidate_from_mapping(item))
        return candidates
    raise ValueError("候选结构库应为 JSON、CSV 或 TSV")


def _multiplicity_compatible(observed: str, expected: str) -> float:
    left = observed.lower().replace(" ", "")
    right = expected.lower().replace(" ", "")
    aliases = {
        "singlet": "s",
        "doublet": "d",
        "triplet": "t",
        "quartet": "q",
        "quintet": "quint",
        "sextet": "sext",
        "septet": "sept",
        "multiplet": "m",
        "brs": "m",
    }
    left, right = aliases.get(left, left), aliases.get(right, right)
    if left == right:
        return 1.0
    if "m" in {left, right}:
        return 0.65
    if left.startswith(right) or right.startswith(left):
        return 0.75
    return 0.0


def _usable_signals(signals: list[Signal]) -> list[Signal]:
    excluded = {"residual solvent", "water", "reference"}
    return [
        signal
        for signal in signals
        if signal.reference_match is None or signal.reference_match.category not in excluded
    ]


def score_candidate(
    observed_signals: list[Signal],
    candidate: Candidate,
    molecular_formula: str = "",
) -> CandidateScore:
    observed = _usable_signals(observed_signals)
    expected = candidate.signals
    if not expected:
        return CandidateScore(
            name=candidate.name,
            score=0.0,
            matched=0,
            expected=0,
            shift_rmse=None,
            coverage=0.0,
            formula=candidate.formula,
            smiles=candidate.smiles,
            explanation=["候选物没有预期 1H 信号数据，无法进行谱图评分"],
        )
    if not observed:
        return CandidateScore(
            name=candidate.name,
            score=0.0,
            matched=0,
            expected=len(expected),
            shift_rmse=None,
            coverage=0.0,
            formula=candidate.formula,
            smiles=candidate.smiles,
            explanation=["未检出可用于评分的分析物信号"],
        )

    cost = np.full((len(expected), len(observed)), 1.0e4, dtype=float)
    for i, exp in enumerate(expected):
        for j, obs in enumerate(observed):
            error = abs(exp.shift - obs.center_ppm)
            if error <= max(exp.tolerance * 2.0, 0.08):
                mult_penalty = 1.0 - _multiplicity_compatible(obs.multiplicity, exp.multiplicity)
                cost[i, j] = (error / max(exp.tolerance, 0.02)) ** 2 + 0.50 * mult_penalty
    rows, cols = linear_sum_assignment(cost)
    pairs = [(int(i), int(j)) for i, j in zip(rows, cols) if cost[i, j] < 4.5]
    matched = len(pairs)
    coverage = matched / len(expected)
    observed_coverage = matched / len(observed)
    errors = [expected[i].shift - observed[j].center_ppm for i, j in pairs]
    rmse = float(np.sqrt(np.mean(np.square(errors)))) if errors else None
    shift_scores = [
        np.exp(-0.5 * (abs(expected[i].shift - observed[j].center_ppm) / expected[i].tolerance) ** 2)
        for i, j in pairs
    ]
    shift_score = float(np.mean(shift_scores)) if shift_scores else 0.0
    mult_score = (
        float(np.mean([_multiplicity_compatible(observed[j].multiplicity, expected[i].multiplicity) for i, j in pairs]))
        if pairs
        else 0.0
    )

    exp_integrals = np.asarray([expected[i].protons for i, _ in pairs], dtype=float)
    obs_integrals = np.asarray(
        [
            observed[j].estimated_protons
            if observed[j].estimated_protons is not None
            else observed[j].relative_integral
            for _, j in pairs
        ],
        dtype=float,
    )
    if pairs and exp_integrals.sum() > 0 and obs_integrals.sum() > 0:
        exp_fraction = exp_integrals / exp_integrals.sum()
        obs_fraction = obs_integrals / obs_integrals.sum()
        integral_error = float(np.mean(np.abs(exp_fraction - obs_fraction)))
        integral_score = float(np.exp(-6.0 * integral_error))
    else:
        integral_score = 0.0

    formula_score = 1.0
    explanation = [
        f"匹配 {matched}/{len(expected)} 个预期信号；实验非溶剂信号覆盖 {observed_coverage:.0%}",
    ]
    if rmse is not None:
        explanation.append(f"匹配信号位移 RMSE = {rmse:.3f} ppm")
    if molecular_formula.strip() and candidate.formula.strip():
        try:
            if formulas_equal(molecular_formula, candidate.formula):
                explanation.append("候选分子式与输入分子式一致")
            else:
                formula_score = 0.15
                explanation.append("候选分子式与输入分子式不一致，已施加惩罚")
        except ValueError:
            formula_score = 0.5
            explanation.append("输入分子式无法规范比较")

    # Coverage dominates: a candidate must explain the spectrum rather than only
    # have one coincident peak. Formula acts as a multiplicative guard.
    raw_score = 100.0 * (
        0.34 * coverage
        + 0.18 * observed_coverage
        + 0.24 * shift_score
        + 0.12 * mult_score
        + 0.12 * integral_score
    )
    score = float(np.clip(raw_score * (0.75 + 0.25 * formula_score), 0.0, 100.0))
    return CandidateScore(
        name=candidate.name,
        score=score,
        matched=matched,
        expected=len(expected),
        shift_rmse=rmse,
        coverage=coverage,
        formula=candidate.formula,
        smiles=candidate.smiles,
        explanation=explanation,
    )


def rank_candidates(
    signals: list[Signal],
    candidates: list[Candidate],
    molecular_formula: str = "",
) -> list[CandidateScore]:
    scores = [score_candidate(signals, candidate, molecular_formula) for candidate in candidates]
    return sorted(scores, key=lambda item: item.score, reverse=True)


def fit_candidate_mixture(
    ppm: np.ndarray,
    intensity: np.ndarray,
    candidates: list[Candidate],
    linewidth_ppm: float = 0.015,
) -> list[tuple[str, float]]:
    """Fit non-negative candidate coefficients to a positive 1H spectrum.

    This is a screening decomposition.  It requires candidate expected shifts
    and cannot resolve compounds with near-identical signal sets.
    """
    x = np.asarray(ppm, dtype=float)
    y = np.clip(np.asarray(intensity, dtype=float), 0.0, None)
    if x.size > 12000:
        idx = np.linspace(0, x.size - 1, 12000).astype(int)
        x, y = x[idx], y[idx]
    columns: list[np.ndarray] = []
    names: list[str] = []
    width = max(float(linewidth_ppm), 1e-4)
    for candidate in candidates:
        if not candidate.signals:
            continue
        profile = np.zeros_like(x)
        for signal in candidate.signals:
            profile += signal.protons * np.exp(-0.5 * ((x - signal.shift) / width) ** 2)
        norm = np.linalg.norm(profile)
        if norm > 0:
            columns.append(profile / norm)
            names.append(candidate.name)
    if not columns or not np.any(y > 0):
        return []
    matrix = np.column_stack(columns)
    coefficients, _ = nnls(matrix, y)
    total = coefficients.sum()
    if total <= 0:
        return []
    fractions = coefficients / total
    return sorted(
        [(name, float(fraction)) for name, fraction in zip(names, fractions) if fraction >= 0.01],
        key=lambda item: item[1],
        reverse=True,
    )
