"""Prediction-provider registry for empirical, ML, database and DFT engines"""

from __future__ import annotations

from dataclasses import dataclass
from importlib import metadata
from typing import Protocol, runtime_checkable

from .prediction import NUCLEI, PredictionResult, predict_nmr
from .structure import MoleculeGraph


@dataclass(frozen=True, slots=True)
class PredictionRequest:
    graph: MoleculeGraph
    nucleus: str
    solvent: str = "CDCl3"
    frequency_mhz: float = 400.0
    temperature_k: float = 298.15
    concentration_m: float | None = None


@runtime_checkable
class PredictionBackend(Protocol):
    id: str
    name: str
    supported_nuclei: tuple[str, ...]

    def predict(self, request: PredictionRequest) -> PredictionResult: ...


class EmpiricalPredictionBackend:
    id = "open-rule-v0.3"
    name = "Open explainable environment model"
    supported_nuclei = NUCLEI

    def predict(self, request: PredictionRequest) -> PredictionResult:
        return predict_nmr(
            request.graph,
            request.nucleus,
            solvent=request.solvent,
            frequency_mhz=request.frequency_mhz,
            temperature_k=request.temperature_k,
            concentration_m=request.concentration_m,
        )


class PredictionBackendRegistry:
    def __init__(self) -> None:
        self._backends: dict[str, PredictionBackend] = {}
        self.plugin_errors: list[str] = []

    def register(self, backend: PredictionBackend, *, replace: bool = False) -> None:
        if not isinstance(backend, PredictionBackend):
            raise TypeError("Prediction backend does not implement the required protocol")
        if backend.id in self._backends and not replace:
            raise ValueError(f"Prediction backend already registered: {backend.id}")
        self._backends[backend.id] = backend

    @property
    def backends(self) -> tuple[PredictionBackend, ...]:
        return tuple(self._backends.values())

    def discover_entry_points(self) -> None:
        try:
            points = metadata.entry_points()
            selected = points.select(group="open_nmr_workbench.predictors") if hasattr(points, "select") else points.get("open_nmr_workbench.predictors", [])
        except Exception as exc:
            self.plugin_errors.append(f"Could not enumerate prediction plugins: {exc}")
            return
        for point in selected:
            try:
                loaded = point.load()
                backend = loaded() if isinstance(loaded, type) else loaded
                self.register(backend)
            except Exception as exc:
                self.plugin_errors.append(f"Prediction plugin {point.name!r} was not loaded: {exc}")

    def predict(self, request: PredictionRequest, backend_id: str = "open-rule-v0.3") -> PredictionResult:
        try:
            backend = self._backends[backend_id]
        except KeyError as exc:
            raise ValueError(f"Unknown prediction backend: {backend_id}") from exc
        if request.nucleus not in backend.supported_nuclei:
            raise ValueError(f"{backend.name} does not support {request.nucleus}")
        return backend.predict(request)


def default_prediction_backends(*, discover_external: bool = True) -> PredictionBackendRegistry:
    registry = PredictionBackendRegistry()
    registry.register(EmpiricalPredictionBackend())
    if discover_external:
        registry.discover_entry_points()
    return registry

