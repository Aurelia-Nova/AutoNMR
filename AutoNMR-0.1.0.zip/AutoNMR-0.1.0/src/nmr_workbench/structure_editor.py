"""Tkinter structure editor and four-nucleus prediction window."""

from __future__ import annotations

import math
import tkinter as tk
from collections.abc import Callable
from pathlib import Path
from tkinter import filedialog, messagebox, simpledialog, ttk

from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
from matplotlib.figure import Figure

from .domain_i18n import domain_text
from .i18n import Translator, configure_matplotlib_fonts, matplotlib_font_supports_cjk
from .prediction import (
    NUCLEI,
    PredictionResult,
    predict_nmr,
    simulate_prediction_spectrum,
    spectrum_limits,
    write_prediction,
)
from .solvents import solvent_ids
from .structure import SUPPORTED_ELEMENTS, BondEdge, MoleculeGraph, StructureError
from .verification import verify_prediction


class StructureEditorWindow:
    """A compact ChemDraw-like editor tailored to NMR prediction."""

    bond_length = 66.0
    hit_radius = 15.0

    def __init__(
        self,
        parent: tk.Misc,
        *,
        language: str = "zh_CN",
        experimental_report_provider: Callable[[], object | None] | None = None,
    ) -> None:
        self.parent = parent
        self.tr = Translator(language)
        self.experimental_report_provider = experimental_report_provider
        plot_font = configure_matplotlib_fonts(language)
        self.plot_language = (
            "en_US" if language == "zh_CN" and not matplotlib_font_supports_cjk(plot_font) else language
        )
        self.plot_tr = Translator(self.plot_language)
        self.window = tk.Toplevel(parent)
        self.window.title(self.tr.t("structure.title"))
        self.window.geometry("1540x920")
        self.window.minsize(1160, 720)

        self.graph = MoleculeGraph()
        self.history: list[dict[str, object]] = [self.graph.to_dict()]
        self.history_index = 0
        self.current_path: Path | None = None
        self.current_prediction: PredictionResult | None = None

        self.tool = "bond"
        self.bond_order = 1.0
        self.element = "C"
        self.selected_atom_id: int | None = None
        self.selected_bond_id: int | None = None
        self.highlight_atom_ids: set[int] = set()
        self.drag_atom_id: int | None = None
        self.drag_start_atom_id: int | None = None
        self.drag_origin: tuple[float, float] | None = None
        self.drag_moved = False
        self.preview_item: int | None = None
        self._prediction_job: str | None = None
        self._tree_atoms: dict[str, tuple[int, ...]] = {}

        self._make_variables()
        self._build_menu()
        self._build_layout()
        self._bind_shortcuts()
        self._set_tool("bond", order=1.0)
        self._draw_graph()
        self.window.protocol("WM_DELETE_WINDOW", self.close)

    def _make_variables(self) -> None:
        self.status_var = tk.StringVar(
            value=self._txt(
                "单键工具：拖动原子到空白处生成碳骨架，拖到另一原子成键。",
                "Single-bond tool: drag from an atom to extend the skeleton or connect another atom.",
            )
        )
        self.formula_var = tk.StringVar(value=self._txt("分子式：—", "Formula: —"))
        self.smiles_var = tk.StringVar(
            value=self._txt("SMILES：保存/导入需 RDKit", "SMILES: RDKit is needed for import/export")
        )
        self.nucleus_var = tk.StringVar(value="1H")
        self.solvent_var = tk.StringVar(value="CDCl3")
        self.frequency_var = tk.StringVar(value="400.0")
        self.temperature_var = tk.StringVar(value="298.15")
        self.concentration_var = tk.StringVar(value="")
        self.auto_predict_var = tk.BooleanVar(value=True)
        self.show_ids_var = tk.BooleanVar(value=True)

    def _txt(self, zh, en):
        return en if self.tr.language == "en_US" else zh

    def _build_menu(self) -> None:
        menu = tk.Menu(self.window)
        file_menu = tk.Menu(menu, tearoff=False)
        file_menu.add_command(
            label=self.tr.t("structure.new"), command=self.new_structure, accelerator="Ctrl+N"
        )
        file_menu.add_command(
            label=self._txt("打开画板结构…", "Open drawing…"), command=self.open_structure, accelerator="Ctrl+O"
        )
        file_menu.add_command(
            label=self._txt("保存画板结构…", "Save drawing…"), command=self.save_structure, accelerator="Ctrl+S"
        )
        file_menu.add_separator()
        file_menu.add_command(label=self._txt("从 SMILES 导入…", "Import SMILES…"), command=self.import_smiles)
        file_menu.add_command(label=self._txt("从 MOL/SDF 导入…", "Import MOL/SDF…"), command=self.import_mol)
        file_menu.add_command(label=self._txt("导出 MOL…", "Export MOL…"), command=self.export_mol)
        file_menu.add_command(label=self._txt("复制规范 SMILES", "Copy canonical SMILES"), command=self.copy_smiles)
        file_menu.add_separator()
        file_menu.add_command(label=self._txt("导出预测峰表…", "Export predicted peaks…"), command=self.export_prediction)
        file_menu.add_separator()
        file_menu.add_command(label=self._txt("关闭", "Close"), command=self.close)
        menu.add_cascade(label=self.tr.t("menu.file"), menu=file_menu)

        edit_menu = tk.Menu(menu, tearoff=False)
        edit_menu.add_command(label=self.tr.t("action.undo"), command=self.undo, accelerator="Ctrl+Z")
        edit_menu.add_command(label=self.tr.t("action.redo"), command=self.redo, accelerator="Ctrl+Y")
        edit_menu.add_separator()
        edit_menu.add_command(
            label=self._txt("删除所选", "Delete selected"), command=self.delete_selected, accelerator="Delete"
        )
        edit_menu.add_command(
            label=self._txt("形式电荷 +1", "Formal charge +1"), command=lambda: self.change_charge(1)
        )
        edit_menu.add_command(
            label=self._txt("形式电荷 −1", "Formal charge −1"), command=lambda: self.change_charge(-1)
        )
        edit_menu.add_command(label=self._txt("形式电荷归零", "Set charge to zero"), command=lambda: self.set_charge(0))
        edit_menu.add_separator()
        edit_menu.add_command(label=self._txt("清空画板", "Clear drawing"), command=self.clear_structure)
        menu.add_cascade(label=self.tr.t("menu.edit"), menu=edit_menu)

        example_menu = tk.Menu(menu, tearoff=False)
        example_menu.add_command(
            label=self._txt("乙醇（1H / 13C）", "Ethanol (1H / 13C)"), command=lambda: self.load_example("ethanol")
        )
        example_menu.add_command(
            label=self._txt("氟苯（19F）", "Fluorobenzene (19F)"), command=lambda: self.load_example("fluorobenzene")
        )
        example_menu.add_command(
            label=self._txt("磷酸三甲酯（31P）", "Trimethyl phosphate (31P)"),
            command=lambda: self.load_example("trimethyl_phosphate"),
        )
        menu.add_cascade(label=self._txt("示例", "Examples"), menu=example_menu)

        help_menu = tk.Menu(menu, tearoff=False)
        help_menu.add_command(label=self._txt("画板操作与预测边界", "Drawing controls and prediction limits"), command=self.show_help)
        menu.add_cascade(label=self.tr.t("menu.help"), menu=help_menu)
        self.window.config(menu=menu)

    def _build_layout(self) -> None:
        toolbar = ttk.Frame(self.window, padding=(7, 6))
        toolbar.pack(fill=tk.X)
        for label, command in (
            (self.tr.t("structure.new"), self.new_structure),
            (self.tr.t("structure.open"), self.open_structure),
            (self.tr.t("structure.save"), self.save_structure),
            ("SMILES", self.import_smiles),
        ):
            ttk.Button(toolbar, text=label, command=command).pack(side=tk.LEFT, padx=2)
        ttk.Separator(toolbar, orient=tk.VERTICAL).pack(side=tk.LEFT, fill=tk.Y, padx=6)
        ttk.Button(
            toolbar, text=self.tr.t("structure.select"), command=lambda: self._set_tool("select")
        ).pack(side=tk.LEFT, padx=2)
        for label, order in (
            (self.tr.t("structure.single"), 1.0),
            (self.tr.t("structure.double"), 2.0),
            (self.tr.t("structure.triple"), 3.0),
            (self.tr.t("structure.aromatic"), 1.5),
        ):
            ttk.Button(
                toolbar,
                text=label,
                command=lambda value=order: self._set_tool("bond", order=value),
            ).pack(side=tk.LEFT, padx=2)
        ttk.Button(
            toolbar, text=self.tr.t("structure.benzene"), command=lambda: self._set_tool("ring_aromatic")
        ).pack(side=tk.LEFT, padx=2)
        ttk.Button(
            toolbar, text=self.tr.t("structure.six_ring"), command=lambda: self._set_tool("ring_single")
        ).pack(side=tk.LEFT, padx=2)
        ttk.Button(toolbar, text=self.tr.t("structure.eraser"), command=lambda: self._set_tool("delete")).pack(
            side=tk.LEFT, padx=2
        )
        ttk.Separator(toolbar, orient=tk.VERTICAL).pack(side=tk.LEFT, fill=tk.Y, padx=6)
        ttk.Button(toolbar, text="↶", width=3, command=self.undo).pack(
            side=tk.LEFT, padx=1
        )
        ttk.Button(toolbar, text="↷", width=3, command=self.redo).pack(
            side=tk.LEFT, padx=1
        )

        atom_bar = ttk.Frame(self.window, padding=(8, 2, 8, 6))
        atom_bar.pack(fill=tk.X)
        ttk.Label(atom_bar, text=self.tr.t("structure.atoms")).pack(side=tk.LEFT)
        for element in SUPPORTED_ELEMENTS:
            ttk.Button(
                atom_bar,
                text=element,
                width=3 if len(element) == 1 else 4,
                command=lambda value=element: self._set_atom_tool(value),
            ).pack(side=tk.LEFT, padx=1)
        ttk.Separator(atom_bar, orient=tk.VERTICAL).pack(
            side=tk.LEFT, fill=tk.Y, padx=7
        )
        ttk.Button(atom_bar, text=self.tr.t("structure.charge_plus"), command=lambda: self.change_charge(1)).pack(
            side=tk.LEFT, padx=2
        )
        ttk.Button(
            atom_bar, text=self.tr.t("structure.charge_minus"), command=lambda: self.change_charge(-1)
        ).pack(side=tk.LEFT, padx=2)
        ttk.Checkbutton(
            atom_bar,
            text=self.tr.t("structure.show_ids"),
            variable=self.show_ids_var,
            command=self._draw_graph,
        ).pack(side=tk.LEFT, padx=8)
        ttk.Label(
            atom_bar,
            text=self._txt("提示：右键可删除；数字 1/2/3 切换键级；C/N/O/F/P/S 切换原子。", "Tip: right-click deletes; 1/2/3 changes bond order; C/N/O/F/P/S selects atoms."),
            foreground="#64748b",
        ).pack(side=tk.RIGHT, padx=6)

        paned = ttk.Panedwindow(self.window, orient=tk.HORIZONTAL)
        paned.pack(fill=tk.BOTH, expand=True, padx=7, pady=(0, 4))
        draw_panel = ttk.Frame(paned)
        result_panel = ttk.Frame(paned, width=590)
        paned.add(draw_panel, weight=3)
        paned.add(result_panel, weight=2)

        draw_header = ttk.Frame(draw_panel, padding=(4, 3))
        draw_header.pack(fill=tk.X)
        ttk.Label(
            draw_header,
            textvariable=self.formula_var,
            font=("Microsoft YaHei UI", 10, "bold"),
        ).pack(side=tk.LEFT)
        ttk.Label(draw_header, textvariable=self.smiles_var, foreground="#526174").pack(
            side=tk.LEFT, padx=18
        )

        canvas_frame = ttk.Frame(draw_panel, relief=tk.SUNKEN, borderwidth=1)
        canvas_frame.pack(fill=tk.BOTH, expand=True)
        self.canvas = tk.Canvas(
            canvas_frame, background="#ffffff", highlightthickness=0, cursor="crosshair"
        )
        self.canvas.pack(fill=tk.BOTH, expand=True)
        self.canvas.bind("<ButtonPress-1>", self._on_canvas_press)
        self.canvas.bind("<B1-Motion>", self._on_canvas_drag)
        self.canvas.bind("<ButtonRelease-1>", self._on_canvas_release)
        self.canvas.bind("<Button-3>", self._on_right_click)
        self.canvas.bind("<Configure>", lambda _event: self._draw_graph())

        self._build_prediction_panel(result_panel)

        status = ttk.Label(
            self.window,
            textvariable=self.status_var,
            anchor=tk.W,
            relief=tk.SUNKEN,
            padding=(8, 4),
        )
        status.pack(fill=tk.X)

    def _build_prediction_panel(self, parent: ttk.Frame) -> None:
        controls = ttk.LabelFrame(parent, text=self.tr.t("structure.prediction"), padding=7)
        controls.pack(fill=tk.X, padx=3, pady=(0, 5))
        ttk.Label(controls, text=self.tr.t("field.nucleus")).grid(
            row=0, column=0, sticky=tk.W, padx=3, pady=3
        )
        nucleus = ttk.Combobox(
            controls,
            textvariable=self.nucleus_var,
            values=NUCLEI,
            state="readonly",
            width=7,
        )
        nucleus.grid(row=0, column=1, sticky=tk.W, padx=3, pady=3)
        nucleus.bind("<<ComboboxSelected>>", self._on_nucleus_change)
        ttk.Label(controls, text=self.tr.t("field.solvent")).grid(
            row=0, column=2, sticky=tk.W, padx=(12, 3), pady=3
        )
        solvent = ttk.Combobox(
            controls,
            textvariable=self.solvent_var,
            values=solvent_ids(),
            width=11,
        )
        solvent.grid(row=0, column=3, sticky=tk.W, padx=3, pady=3)
        solvent.bind(
            "<<ComboboxSelected>>",
            lambda _event: self._schedule_prediction(immediate=True),
        )
        ttk.Label(controls, text=self.tr.t("field.frequency")).grid(
            row=0, column=4, sticky=tk.W, padx=(12, 3), pady=3
        )
        frequency = ttk.Entry(controls, textvariable=self.frequency_var, width=8)
        frequency.grid(row=0, column=5, sticky=tk.W, padx=3, pady=3)
        frequency.bind("<Return>", lambda _event: self.run_prediction())
        ttk.Label(controls, text=self._txt("温度 / K", "Temperature / K")).grid(row=1, column=0, sticky=tk.W, padx=3, pady=3)
        ttk.Entry(controls, textvariable=self.temperature_var, width=8).grid(row=1, column=1, sticky=tk.W, padx=3, pady=3)
        ttk.Label(controls, text=self._txt("浓度 / mol L⁻¹", "Concentration / mol L⁻¹")).grid(row=1, column=2, sticky=tk.W, padx=(12, 3), pady=3)
        ttk.Entry(controls, textvariable=self.concentration_var, width=9).grid(row=1, column=3, sticky=tk.W, padx=3, pady=3)
        ttk.Checkbutton(
            controls, text=self.tr.t("structure.auto_refresh"), variable=self.auto_predict_var
        ).grid(row=1, column=4, columnspan=2, sticky=tk.W, padx=3, pady=3)
        ttk.Button(controls, text=self.tr.t("structure.predict_now"), command=self.run_prediction).grid(
            row=2, column=0, columnspan=2, sticky=tk.EW, padx=3, pady=3
        )
        ttk.Button(controls, text=self.tr.t("structure.compare"), command=self.compare_with_experiment).grid(
            row=2, column=2, columnspan=2, sticky=tk.EW, padx=3, pady=3
        )
        ttk.Button(controls, text=self.tr.t("structure.export_peaks"), command=self.export_prediction).grid(
            row=2, column=4, columnspan=2, sticky=tk.EW, padx=3, pady=3
        )

        figure_frame = ttk.Frame(parent)
        figure_frame.pack(fill=tk.BOTH, expand=True, padx=3)
        self.figure = Figure(figsize=(6.2, 3.25), dpi=100, facecolor="white")
        self.axes = self.figure.add_subplot(111)
        self.prediction_canvas = FigureCanvasTkAgg(self.figure, master=figure_frame)
        self.prediction_canvas.get_tk_widget().pack(fill=tk.BOTH, expand=True)
        self._draw_empty_prediction()

        table_frame = ttk.LabelFrame(
            parent, text=self.tr.t("structure.peak_table"), padding=3
        )
        table_frame.pack(fill=tk.BOTH, expand=True, padx=3, pady=5)
        columns = (
            "site",
            "shift",
            "error",
            "integral",
            "mult",
            "j",
            "environment",
            "confidence",
        )
        self.prediction_tree = ttk.Treeview(
            table_frame, columns=columns, show="headings", height=10
        )
        headings = self._txt(
            ("原子", "δ/ppm", "±ppm", "积分/数目", "裂分/类型", "J/Hz", "环境", "置信度"),
            ("Atoms", "δ/ppm", "±ppm", "Integral/count", "Pattern/type", "J/Hz", "Environment", "Confidence"),
        )
        widths = (70, 68, 55, 70, 78, 75, 180, 58)
        for column, heading, width in zip(columns, headings, widths):
            self.prediction_tree.heading(column, text=heading)
            self.prediction_tree.column(
                column, width=width, minwidth=45, stretch=column == "environment"
            )
        yscroll = ttk.Scrollbar(
            table_frame, orient=tk.VERTICAL, command=self.prediction_tree.yview
        )
        xscroll = ttk.Scrollbar(
            table_frame, orient=tk.HORIZONTAL, command=self.prediction_tree.xview
        )
        self.prediction_tree.configure(
            yscrollcommand=yscroll.set, xscrollcommand=xscroll.set
        )
        self.prediction_tree.grid(row=0, column=0, sticky="nsew")
        yscroll.grid(row=0, column=1, sticky="ns")
        xscroll.grid(row=1, column=0, sticky="ew")
        table_frame.rowconfigure(0, weight=1)
        table_frame.columnconfigure(0, weight=1)
        self.prediction_tree.bind("<<TreeviewSelect>>", self._on_prediction_select)

        warning_frame = ttk.LabelFrame(parent, text=self.tr.t("structure.model_notes"), padding=3)
        warning_frame.pack(fill=tk.X, padx=3, pady=(0, 2))
        self.warning_text = tk.Text(
            warning_frame, height=5, wrap=tk.WORD, relief=tk.FLAT, background="#fffaf0"
        )
        warning_scroll = ttk.Scrollbar(
            warning_frame, orient=tk.VERTICAL, command=self.warning_text.yview
        )
        self.warning_text.configure(yscrollcommand=warning_scroll.set)
        self.warning_text.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        warning_scroll.pack(side=tk.RIGHT, fill=tk.Y)
        self._replace_warning(
            self._txt("先在左侧画板创建结构；预测会在编辑停止约半秒后自动更新。", "Create a structure on the left; prediction refreshes shortly after editing stops.")
        )

    def _bind_shortcuts(self) -> None:
        self.window.bind("<Control-n>", lambda _event: self.new_structure())
        self.window.bind("<Control-o>", lambda _event: self.open_structure())
        self.window.bind("<Control-s>", lambda _event: self.save_structure())
        self.window.bind("<Control-z>", lambda _event: self.undo())
        self.window.bind("<Control-y>", lambda _event: self.redo())
        self.window.bind("<Delete>", lambda _event: self.delete_selected())
        self.window.bind("<Escape>", lambda _event: self._set_tool("select"))
        self.window.bind("1", lambda _event: self._set_tool("bond", order=1.0))
        self.window.bind("2", lambda _event: self._set_tool("bond", order=2.0))
        self.window.bind("3", lambda _event: self._set_tool("bond", order=3.0))
        for key, element in (
            ("c", "C"),
            ("n", "N"),
            ("o", "O"),
            ("f", "F"),
            ("p", "P"),
            ("s", "S"),
            ("h", "H"),
        ):
            self.window.bind(
                key, lambda _event, value=element: self._set_atom_tool(value)
            )

    def _set_tool(self, tool: str, *, order: float | None = None) -> None:
        self.tool = tool
        if order is not None:
            self.bond_order = order
        messages = {
            "select": self._txt(
                "选择/移动：拖动原子；单击化学键可选中。",
                "Select/move: drag atoms; click a bond to select it.",
            ),
            "bond": self._txt(
                f"{self._bond_name(self.bond_order)}工具：从原子拖出新碳，或拖到另一原子成键。",
                f"{self._bond_name(self.bond_order)} tool: drag from an atom to a new carbon or another atom.",
            ),
            "ring_aromatic": self._txt(
                "苯环工具：单击空白放置，或单击已有原子稠接/连接一个芳香六元环。",
                "Benzene tool: click empty space or an existing atom to place an aromatic six-membered ring.",
            ),
            "ring_single": self._txt(
                "六元环工具：单击空白放置，或单击已有原子连接一个饱和六元环。",
                "Six-membered-ring tool: click empty space or an existing atom to place a saturated ring.",
            ),
            "delete": self._txt(
                "橡皮工具：单击原子或化学键删除；也可右键删除。",
                "Eraser: click an atom or bond to remove it; right-click also removes.",
            ),
            "atom": self._txt(
                f"原子工具 {self.element}：单击顶点替换元素，单击空白放置原子。",
                f"{self.element} atom tool: click a vertex to replace it or empty space to add an atom.",
            ),
        }
        self.status_var.set(messages.get(tool, tool))
        self.canvas.configure(cursor="fleur" if tool == "select" else "crosshair")

    def _set_atom_tool(self, element: str) -> None:
        self.element = element
        self._set_tool("atom")

    def _on_canvas_press(self, event: tk.Event) -> None:
        self.canvas.focus_set()
        x, y = float(event.x), float(event.y)
        atom_id = self._hit_atom(x, y)
        bond_id = None if atom_id is not None else self._hit_bond(x, y)
        if self.tool == "delete":
            if atom_id is not None:
                self.graph.remove_atom(atom_id)
                self._clear_selection()
                self._commit(self._txt("已删除原子及其相连化学键。", "Removed the atom and its bonds."))
            elif bond_id is not None:
                self.graph.remove_bond(bond_id)
                self._clear_selection()
                self._commit(self._txt("已删除化学键。", "Removed the bond."))
            return
        if self.tool == "atom":
            if atom_id is None:
                atom_id = self.graph.add_atom(self.element, x, y)
                self.selected_atom_id = atom_id
            else:
                self.graph.set_atom(atom_id, element=self.element, aromatic=False)
                self.selected_atom_id = atom_id
            self.selected_bond_id = None
            self._commit(self._txt(f"已放置/替换为 {self.element}。", f"Placed/replaced with {self.element}."))
            return
        if self.tool in {"ring_aromatic", "ring_single"}:
            self._add_ring(x, y, atom_id, aromatic=self.tool == "ring_aromatic")
            return
        if self.tool == "select":
            self.selected_atom_id, self.selected_bond_id = atom_id, bond_id
            if atom_id is not None:
                atom = self.graph.atom(atom_id)
                self.drag_atom_id = atom_id
                self.drag_origin = (atom.x, atom.y)
                self.drag_moved = False
            self._draw_graph()
            return
        if self.tool == "bond":
            if atom_id is not None:
                self.drag_start_atom_id = atom_id
                self.selected_atom_id, self.selected_bond_id = atom_id, None
                self._draw_graph()
            elif bond_id is not None:
                self.graph.set_bond_order(bond_id, self.bond_order)
                self.selected_atom_id, self.selected_bond_id = None, bond_id
                self._commit(self._txt(f"已改为{self._bond_name(self.bond_order)}。", f"Changed to {self._bond_name(self.bond_order)}."))
            else:
                new_id = self.graph.add_atom("C", x, y)
                self.selected_atom_id, self.selected_bond_id = new_id, None
                self._commit(self._txt("已放置碳原子；从该顶点向外拖动可继续画键。", "Placed a carbon atom; drag from it to extend a bond."))

    def _on_canvas_drag(self, event: tk.Event) -> None:
        x, y = float(event.x), float(event.y)
        if self.tool == "select" and self.drag_atom_id is not None:
            self.graph.move_atom(self.drag_atom_id, x, y)
            self.drag_moved = True
            self._draw_graph()
        elif self.tool == "bond" and self.drag_start_atom_id is not None:
            atom = self.graph.atom(self.drag_start_atom_id)
            if self.preview_item is not None:
                self.canvas.delete(self.preview_item)
            self.preview_item = self.canvas.create_line(
                atom.x,
                atom.y,
                x,
                y,
                fill="#0f766e",
                width=2,
                dash=(5, 3),
                tags=("preview",),
            )

    def _on_canvas_release(self, event: tk.Event) -> None:
        x, y = float(event.x), float(event.y)
        if self.preview_item is not None:
            self.canvas.delete(self.preview_item)
            self.preview_item = None
        if self.tool == "select" and self.drag_atom_id is not None:
            moved = self.drag_moved
            self.drag_atom_id = None
            self.drag_origin = None
            self.drag_moved = False
            if moved:
                self._commit(self._txt("已移动原子。", "Moved the atom."))
            return
        if self.tool != "bond" or self.drag_start_atom_id is None:
            return
        start_id = self.drag_start_atom_id
        self.drag_start_atom_id = None
        start = self.graph.atom(start_id)
        target_id = self._hit_atom(x, y, exclude=start_id)
        distance = math.hypot(x - start.x, y - start.y)
        if target_id is not None:
            self.graph.add_bond(start_id, target_id, self.bond_order)
            self.selected_atom_id, self.selected_bond_id = target_id, None
            self._commit(self._txt(f"已创建/更新{self._bond_name(self.bond_order)}。", f"Created/updated the {self._bond_name(self.bond_order)}."))
        elif distance >= 12.0:
            end_x, end_y = self._snap_endpoint(start.x, start.y, x, y)
            new_id = self.graph.add_atom("C", end_x, end_y)
            self.graph.add_bond(start_id, new_id, self.bond_order)
            self.selected_atom_id, self.selected_bond_id = new_id, None
            self._commit(self._txt(f"已延伸{self._bond_name(self.bond_order)}。", f"Extended the {self._bond_name(self.bond_order)}."))
        else:
            self._draw_graph()

    def _on_right_click(self, event: tk.Event) -> None:
        atom_id = self._hit_atom(float(event.x), float(event.y))
        bond_id = (
            None
            if atom_id is not None
            else self._hit_bond(float(event.x), float(event.y))
        )
        if atom_id is not None:
            self.graph.remove_atom(atom_id)
            self._clear_selection()
            self._commit(self._txt("已删除原子及其相连化学键。", "Removed the atom and its bonds."))
        elif bond_id is not None:
            self.graph.remove_bond(bond_id)
            self._clear_selection()
            self._commit(self._txt("已删除化学键。", "Removed the bond."))

    def _add_ring(
        self, x: float, y: float, anchor_id: int | None, *, aromatic: bool
    ) -> None:
        radius = self.bond_length
        if anchor_id is not None:
            anchor = self.graph.atom(anchor_id)
            center_x, center_y = anchor.x + radius, anchor.y
            points = [
                (
                    center_x + radius * math.cos(math.pi + index * math.pi / 3.0),
                    center_y + radius * math.sin(math.pi + index * math.pi / 3.0),
                )
                for index in range(6)
            ]
            atom_ids = [anchor_id]
            atom_ids.extend(
                self.graph.add_atom("C", px, py, aromatic=aromatic)
                for px, py in points[1:]
            )
            if aromatic:
                self.graph.set_atom(anchor_id, aromatic=True)
        else:
            center_x, center_y = x, y
            points = [
                (
                    center_x + radius * math.cos(math.pi + index * math.pi / 3.0),
                    center_y + radius * math.sin(math.pi + index * math.pi / 3.0),
                )
                for index in range(6)
            ]
            atom_ids = [
                self.graph.add_atom("C", px, py, aromatic=aromatic) for px, py in points
            ]
        order = 1.5 if aromatic else 1.0
        for index in range(6):
            self.graph.add_bond(atom_ids[index], atom_ids[(index + 1) % 6], order)
        self.selected_atom_id, self.selected_bond_id = atom_ids[0], None
        self._commit(
            self._txt(
                "已放置苯环。" if aromatic else "已放置六元环。",
                "Placed a benzene ring." if aromatic else "Placed a six-membered ring.",
            )
        )

    def _snap_endpoint(
        self, start_x: float, start_y: float, x: float, y: float
    ) -> tuple[float, float]:
        angle = math.atan2(y - start_y, x - start_x)
        snapped = round(angle / (math.pi / 6.0)) * math.pi / 6.0
        return start_x + self.bond_length * math.cos(
            snapped
        ), start_y + self.bond_length * math.sin(snapped)

    def _hit_atom(
        self, x: float, y: float, *, exclude: int | None = None
    ) -> int | None:
        candidates = [
            (math.hypot(atom.x - x, atom.y - y), atom.id)
            for atom in self.graph.atoms.values()
            if atom.id != exclude
        ]
        if not candidates:
            return None
        distance, atom_id = min(candidates)
        return atom_id if distance <= self.hit_radius else None

    def _hit_bond(self, x: float, y: float) -> int | None:
        candidates: list[tuple[float, int]] = []
        for bond in self.graph.bonds.values():
            atom1, atom2 = self.graph.atom(bond.atom1), self.graph.atom(bond.atom2)
            distance = _point_segment_distance(x, y, atom1.x, atom1.y, atom2.x, atom2.y)
            candidates.append((distance, bond.id))
        if not candidates:
            return None
        distance, bond_id = min(candidates)
        return bond_id if distance <= 8.0 else None

    def _draw_graph(self) -> None:
        if not hasattr(self, "canvas"):
            return
        self.canvas.delete("all")
        if not self.graph.atoms:
            width = max(self.canvas.winfo_width(), 700)
            height = max(self.canvas.winfo_height(), 500)
            self.canvas.create_text(
                width / 2,
                height / 2 - 15,
                text=self._txt(
                    "在空白处单击放置第一个碳，或从“示例 / SMILES”开始",
                    "Click empty space to add the first carbon, or start from Examples / SMILES",
                ),
                fill="#64748b",
                font=("Microsoft YaHei UI", 13),
            )
            self.canvas.create_text(
                width / 2,
                height / 2 + 18,
                text=self._txt(
                    "从原子向外拖动生成键；选择 N/O/F/P 等后单击顶点即可替换元素",
                    "Drag from an atom to create a bond; choose N/O/F/P etc. and click a vertex to replace it",
                ),
                fill="#94a3b8",
                font=("Microsoft YaHei UI", 10),
            )
            self._update_structure_labels()
            return

        for bond in self.graph.bonds.values():
            self._draw_bond(bond)
        for atom in self.graph.atoms.values():
            self._draw_atom(atom.id)
        self._update_structure_labels()

    def _draw_bond(self, bond: BondEdge) -> None:
        atom1, atom2 = self.graph.atom(bond.atom1), self.graph.atom(bond.atom2)
        dx, dy = atom2.x - atom1.x, atom2.y - atom1.y
        length = max(math.hypot(dx, dy), 1.0)
        px, py = -dy / length, dx / length
        selected = bond.id == self.selected_bond_id
        color = "#c2410c" if selected else "#111827"
        width = 2.6 if selected else 2.0
        offsets: tuple[float, ...]
        if math.isclose(bond.order, 2.0):
            offsets = (-3.2, 3.2)
        elif math.isclose(bond.order, 3.0):
            offsets = (-4.6, 0.0, 4.6)
        elif math.isclose(bond.order, 1.5):
            offsets = (0.0, 4.0)
        else:
            offsets = (0.0,)
        for index, offset in enumerate(offsets):
            kwargs: dict[str, object] = {}
            if math.isclose(bond.order, 1.5) and index == 1:
                kwargs["dash"] = (5, 4)
            self.canvas.create_line(
                atom1.x + px * offset,
                atom1.y + py * offset,
                atom2.x + px * offset,
                atom2.y + py * offset,
                fill=color,
                width=width,
                capstyle=tk.ROUND,
                tags=(f"bond-{bond.id}",),
                **kwargs,
            )

    def _draw_atom(self, atom_id: int) -> None:
        atom = self.graph.atom(atom_id)
        selected = atom_id == self.selected_atom_id
        highlighted = atom_id in self.highlight_atom_ids
        if highlighted or selected:
            radius = 13 if selected else 11
            self.canvas.create_oval(
                atom.x - radius,
                atom.y - radius,
                atom.x + radius,
                atom.y + radius,
                fill="#ffedd5" if selected else "#fef3c7",
                outline="#ea580c" if selected else "#d97706",
                width=2 if selected else 1,
            )
        label = self._atom_label(atom_id)
        if label:
            radius_x = max(10, 5 * len(label) + 3)
            self.canvas.create_oval(
                atom.x - radius_x,
                atom.y - 11,
                atom.x + radius_x,
                atom.y + 11,
                fill="white",
                outline="",
            )
            colors = {
                "O": "#dc2626",
                "N": "#2563eb",
                "S": "#ca8a04",
                "P": "#d97706",
                "F": "#15803d",
                "Cl": "#15803d",
                "Br": "#7f1d1d",
                "I": "#6b21a8",
            }
            self.canvas.create_text(
                atom.x,
                atom.y,
                text=label,
                fill=colors.get(atom.element, "#111827"),
                font=("Arial", 12, "bold"),
            )
        else:
            self.canvas.create_oval(
                atom.x - 2,
                atom.y - 2,
                atom.x + 2,
                atom.y + 2,
                fill="#111827",
                outline="",
            )
        if self.show_ids_var.get():
            self.canvas.create_text(
                atom.x + 11,
                atom.y - 12,
                text=str(atom.id),
                fill="#64748b",
                font=("Arial", 8),
            )

    def _atom_label(self, atom_id: int) -> str:
        atom = self.graph.atom(atom_id)
        if atom.element == "C" and self.graph.degree(atom_id) > 0 and atom.charge == 0:
            return "" if atom_id != self.selected_atom_id else "C"
        label = atom.element
        implicit_h = self.graph.implicit_hydrogens(atom_id)
        if atom.element in {"N", "O", "S", "P"} and implicit_h:
            label += "H" + (str(implicit_h) if implicit_h > 1 else "")
        if atom.charge:
            magnitude = abs(atom.charge)
            label += (str(magnitude) if magnitude > 1 else "") + (
                "+" if atom.charge > 0 else "−"
            )
        return label

    def _update_structure_labels(self) -> None:
        if not self.graph.atoms:
            self.formula_var.set(self._txt("分子式：—", "Formula: —"))
            self.smiles_var.set("SMILES: —")
            return
        self.formula_var.set(
            self._txt(
                f"分子式：{self.graph.formula()}    原子 {len(self.graph.atoms)} / 键 {len(self.graph.bonds)}",
                f"Formula: {self.graph.formula()}    atoms {len(self.graph.atoms)} / bonds {len(self.graph.bonds)}",
            )
        )
        try:
            smiles = self.graph.to_smiles()
            self.smiles_var.set(f"SMILES: {smiles}")
        except StructureError:
            self.smiles_var.set(
                self._txt(
                    "SMILES：RDKit 未安装或当前价态尚未通过清洗",
                    "SMILES: RDKit is unavailable or the current valence is invalid",
                )
            )

    def _commit(self, message: str) -> None:
        snapshot = self.graph.to_dict()
        self.history = self.history[: self.history_index + 1]
        if self.history[-1] != snapshot:
            self.history.append(snapshot)
            self.history_index += 1
        self.current_prediction = None
        self.status_var.set(message)
        self._draw_graph()
        self._schedule_prediction()

    def undo(self) -> None:
        if self.history_index <= 0:
            self.status_var.set(self._txt("没有可撤销的操作。", "There is no operation to undo."))
            return
        self.history_index -= 1
        self.graph = (
            MoleculeGraph.from_dict(self.history[self.history_index])
            if self.history[self.history_index]["atoms"]
            else MoleculeGraph()
        )
        self._clear_selection()
        self._draw_graph()
        self._schedule_prediction()
        self.status_var.set(self._txt("已撤销。", "Undone."))

    def redo(self) -> None:
        if self.history_index >= len(self.history) - 1:
            self.status_var.set(self._txt("没有可重做的操作。", "There is no operation to redo."))
            return
        self.history_index += 1
        self.graph = (
            MoleculeGraph.from_dict(self.history[self.history_index])
            if self.history[self.history_index]["atoms"]
            else MoleculeGraph()
        )
        self._clear_selection()
        self._draw_graph()
        self._schedule_prediction()
        self.status_var.set(self._txt("已重做。", "Redone."))

    def _clear_selection(self) -> None:
        self.selected_atom_id = None
        self.selected_bond_id = None
        self.highlight_atom_ids.clear()

    def delete_selected(self) -> None:
        if (
            self.selected_atom_id is not None
            and self.selected_atom_id in self.graph.atoms
        ):
            self.graph.remove_atom(self.selected_atom_id)
            self._clear_selection()
            self._commit(self._txt("已删除所选原子。", "Removed the selected atom."))
        elif (
            self.selected_bond_id is not None
            and self.selected_bond_id in self.graph.bonds
        ):
            self.graph.remove_bond(self.selected_bond_id)
            self._clear_selection()
            self._commit(self._txt("已删除所选化学键。", "Removed the selected bond."))

    def change_charge(self, amount: int) -> None:
        if self.selected_atom_id is None:
            self.status_var.set(self._txt("请先选择一个原子，再调整形式电荷。", "Select an atom before changing its formal charge."))
            return
        atom = self.graph.atom(self.selected_atom_id)
        self.graph.set_atom(atom.id, charge=atom.charge + int(amount))
        self._commit(self._txt(f"原子 #{atom.id} 形式电荷已设为 {atom.charge:+d}。", f"Formal charge on atom #{atom.id} is now {atom.charge:+d}."))

    def set_charge(self, charge: int) -> None:
        if self.selected_atom_id is None:
            self.status_var.set(self._txt("请先选择一个原子。", "Select an atom first."))
            return
        atom_id = self.selected_atom_id
        self.graph.set_atom(atom_id, charge=charge)
        self._commit(self._txt(f"原子 #{atom_id} 形式电荷已设为 {charge:+d}。", f"Formal charge on atom #{atom_id} is now {charge:+d}."))

    def new_structure(self) -> None:
        if self.graph.atoms and not messagebox.askyesno(
            self._txt("新建结构", "New structure"),
            self._txt("清空当前画板并新建吗？", "Clear the current drawing and start a new structure?"),
            parent=self.window,
        ):
            return
        self._replace_graph(MoleculeGraph(), self._txt("已新建空白结构。", "Started a new empty structure."))
        self.current_path = None

    def clear_structure(self) -> None:
        if self.graph.atoms and messagebox.askyesno(
            self._txt("清空画板", "Clear drawing"),
            self._txt("确定删除画板中的全部原子和化学键吗？", "Remove all atoms and bonds from the drawing?"),
            parent=self.window,
        ):
            self._replace_graph(MoleculeGraph(), self._txt("画板已清空。", "The drawing was cleared."))

    def _replace_graph(
        self, graph: MoleculeGraph, message: str, *, fit: bool = False
    ) -> None:
        self.graph = graph
        if fit and graph.atoms:
            self._fit_graph_to_canvas()
        self.history = [self.graph.to_dict()]
        self.history_index = 0
        self._clear_selection()
        self.current_prediction = None
        self._draw_graph()
        self._schedule_prediction()
        self.status_var.set(message)

    def open_structure(self) -> None:
        path = filedialog.askopenfilename(
            parent=self.window,
            title=self._txt("打开画板结构", "Open structure drawing"),
            filetypes=((self._txt("Open NMR 结构", "Open NMR structure"), "*.onmrstruct *.json"), (self._txt("所有文件", "All files"), "*.*")),
        )
        if not path:
            return
        try:
            graph = MoleculeGraph.load(path)
            self._replace_graph(graph, self._txt(f"已打开：{path}", f"Opened: {path}"))
            self.current_path = Path(path)
        except Exception as exc:
            messagebox.showerror(self._txt("打开失败", "Open failed"), str(exc), parent=self.window)

    def save_structure(self) -> None:
        path = filedialog.asksaveasfilename(
            parent=self.window,
            title=self._txt("保存画板结构", "Save structure drawing"),
            initialfile=self.current_path.name
            if self.current_path
            else "structure.onmrstruct",
            defaultextension=".onmrstruct",
            filetypes=((self._txt("Open NMR 结构", "Open NMR structure"), "*.onmrstruct"), ("JSON", "*.json")),
        )
        if not path:
            return
        try:
            self.graph.save(path)
            self.current_path = Path(path)
            self.status_var.set(self._txt(f"结构已保存：{path}", f"Structure saved: {path}"))
        except Exception as exc:
            messagebox.showerror(self._txt("保存失败", "Save failed"), str(exc), parent=self.window)

    def import_smiles(self) -> None:
        value = simpledialog.askstring(
            self._txt("导入 SMILES", "Import SMILES"),
            self._txt("输入 SMILES（例如乙醇 CCO、氟苯 Fc1ccccc1）：", "Enter SMILES (for example ethanol CCO or fluorobenzene Fc1ccccc1):"),
            parent=self.window,
        )
        if not value:
            return
        try:
            graph = MoleculeGraph.from_smiles(value)
            self._replace_graph(graph, self._txt(f"已导入 SMILES：{value}", f"Imported SMILES: {value}"), fit=True)
            self.current_path = None
        except Exception as exc:
            messagebox.showerror(self._txt("SMILES 导入失败", "SMILES import failed"), str(exc), parent=self.window)

    def import_mol(self) -> None:
        path = filedialog.askopenfilename(
            parent=self.window,
            title=self._txt("导入 MOL/SDF", "Import MOL/SDF"),
            filetypes=(("MDL MOL/SDF", "*.mol *.sdf"), (self._txt("所有文件", "All files"), "*.*")),
        )
        if not path:
            return
        try:
            text = Path(path).read_text(encoding="utf-8", errors="replace")
            if Path(path).suffix.lower() == ".sdf":
                text = text.split("$$$$", 1)[0]
            graph = MoleculeGraph.from_molblock(text)
            self._replace_graph(graph, self._txt(f"已导入：{path}", f"Imported: {path}"), fit=True)
            self.current_path = None
        except Exception as exc:
            messagebox.showerror(self._txt("MOL/SDF 导入失败", "MOL/SDF import failed"), str(exc), parent=self.window)

    def export_mol(self) -> None:
        if not self.graph.atoms:
            messagebox.showinfo(
                self._txt("没有结构", "No structure"),
                self._txt("请先创建结构。", "Create a structure first."),
                parent=self.window,
            )
            return
        path = filedialog.asksaveasfilename(
            parent=self.window,
            title=self._txt("导出 MOL", "Export MOL"),
            defaultextension=".mol",
            filetypes=(("MDL MOL", "*.mol"),),
        )
        if path:
            try:
                Path(path).write_text(self.graph.to_molblock(), encoding="utf-8")
                self.status_var.set(self._txt(f"MOL 已导出：{path}", f"MOL exported: {path}"))
            except Exception as exc:
                messagebox.showerror(self._txt("导出失败", "Export failed"), str(exc), parent=self.window)

    def copy_smiles(self) -> None:
        try:
            smiles = self.graph.to_smiles()
            self.window.clipboard_clear()
            self.window.clipboard_append(smiles)
            self.status_var.set(self._txt(f"已复制 SMILES：{smiles}", f"Copied SMILES: {smiles}"))
        except Exception as exc:
            messagebox.showerror(self._txt("无法生成 SMILES", "Could not generate SMILES"), str(exc), parent=self.window)

    def _fit_graph_to_canvas(self) -> None:
        self.canvas.update_idletasks()
        width = max(600.0, float(self.canvas.winfo_width()))
        height = max(450.0, float(self.canvas.winfo_height()))
        xs = [atom.x for atom in self.graph.atoms.values()]
        ys = [atom.y for atom in self.graph.atoms.values()]
        min_x, max_x = min(xs), max(xs)
        min_y, max_y = min(ys), max(ys)
        span_x, span_y = max(max_x - min_x, 1.0), max(max_y - min_y, 1.0)
        scale = min(72.0, (width - 120.0) / span_x, (height - 120.0) / span_y)
        center_x, center_y = (min_x + max_x) / 2.0, (min_y + max_y) / 2.0
        for atom in self.graph.atoms.values():
            atom.x = (atom.x - center_x) * scale + width / 2.0
            atom.y = (atom.y - center_y) * scale + height / 2.0

    def load_example(self, name: str) -> None:
        graph = MoleculeGraph()
        if name == "ethanol":
            c1 = graph.add_atom("C", 330, 300)
            c2 = graph.add_atom("C", 396, 300)
            oxygen = graph.add_atom("O", 462, 300)
            graph.add_bond(c1, c2)
            graph.add_bond(c2, oxygen)
            nucleus = "1H"
        elif name == "fluorobenzene":
            center_x, center_y, radius = 390.0, 300.0, self.bond_length
            atoms = [
                graph.add_atom(
                    "C",
                    center_x + radius * math.cos(math.pi + index * math.pi / 3),
                    center_y + radius * math.sin(math.pi + index * math.pi / 3),
                    aromatic=True,
                )
                for index in range(6)
            ]
            for index in range(6):
                graph.add_bond(atoms[index], atoms[(index + 1) % 6], 1.5)
            fluorine = graph.add_atom("F", center_x - 2 * radius, center_y)
            graph.add_bond(atoms[0], fluorine)
            nucleus = "19F"
        else:
            phosphorus = graph.add_atom("P", 390, 300)
            double_o = graph.add_atom("O", 390, 225)
            graph.add_bond(phosphorus, double_o, 2.0)
            for angle in (30.0, 150.0, 270.0):
                radians = math.radians(angle)
                oxygen = graph.add_atom(
                    "O", 390 + 67 * math.cos(radians), 300 + 67 * math.sin(radians)
                )
                carbon = graph.add_atom(
                    "C", 390 + 132 * math.cos(radians), 300 + 132 * math.sin(radians)
                )
                graph.add_bond(phosphorus, oxygen)
                graph.add_bond(oxygen, carbon)
            nucleus = "31P"
        self.nucleus_var.set(nucleus)
        self.frequency_var.set({"1H": "400.0", "19F": "376.5", "31P": "161.9"}[nucleus])
        self._replace_graph(graph, self._txt("已载入画板示例；可继续编辑。", "Loaded an editable example structure."))

    def _on_nucleus_change(self, _event: tk.Event | None = None) -> None:
        defaults = {"1H": "400.0", "13C": "100.6", "19F": "376.5", "31P": "161.9"}
        self.frequency_var.set(defaults[self.nucleus_var.get()])
        self._schedule_prediction(immediate=True)

    def _schedule_prediction(self, *, immediate: bool = False) -> None:
        if self._prediction_job is not None:
            try:
                self.window.after_cancel(self._prediction_job)
            except tk.TclError:
                pass
            self._prediction_job = None
        if not self.auto_predict_var.get() and not immediate:
            return
        delay = 50 if immediate else 480
        self._prediction_job = self.window.after(
            delay, lambda: self._run_prediction(show_errors=False)
        )

    def run_prediction(self) -> None:
        self._run_prediction(show_errors=True)

    def _run_prediction(self, *, show_errors: bool) -> None:
        self._prediction_job = None
        try:
            concentration_text = self.concentration_var.get().strip()
            result = predict_nmr(
                self.graph,
                self.nucleus_var.get(),
                solvent=self.solvent_var.get(),
                frequency_mhz=float(self.frequency_var.get()),
                temperature_k=float(self.temperature_var.get()),
                concentration_m=float(concentration_text) if concentration_text else None,
            )
        except Exception as exc:
            self.current_prediction = None
            self._clear_prediction_table()
            self._draw_empty_prediction(str(exc))
            self._replace_warning(str(exc))
            if show_errors:
                messagebox.showerror(self._txt("无法预测", "Prediction failed"), str(exc), parent=self.window)
            return
        self.current_prediction = result
        self._populate_prediction(result)
        self.status_var.set(
            self._txt(
                f"{result.nucleus} 预测完成：{len(result.signals)} 组信号；分子式 {result.formula}。",
                f"{result.nucleus} prediction completed: {len(result.signals)} signals; formula {result.formula}.",
            )
        )

    def compare_with_experiment(self) -> None:
        if self.current_prediction is None:
            self.run_prediction()
        if self.current_prediction is None:
            return
        if self.experimental_report_provider is None:
            messagebox.showinfo(
                self.tr.t("structure.compare"),
                self._txt("主窗口尚未提供实验谱；请先载入并自动分析谱图。", "No experimental spectrum is available from the main window. Load and analyze one first."),
                parent=self.window,
            )
            return
        report = self.experimental_report_provider()
        if report is None:
            messagebox.showinfo(
                self.tr.t("structure.compare"),
                self._txt("请先在主窗口载入并自动分析同核种实验谱。", "Load and automatically analyze an experimental spectrum of the same nucleus first."),
                parent=self.window,
            )
            return
        try:
            result = verify_prediction(self.current_prediction, report)
        except Exception as exc:
            messagebox.showerror(self.tr.t("structure.compare"), str(exc), parent=self.window)
            return
        rmse = "—" if result.shift_rmse is None else f"{result.shift_rmse:.3f} ppm"
        details = self._txt(
            f"结构一致性：{result.score:.1f}/100\n预测信号覆盖：{result.predicted_coverage:.0%}\n实验信号覆盖：{result.observed_coverage:.0%}\n位移 RMSE：{rmse}\n匹配：{len(result.assignments)}；预测缺失：{len(result.missing_predicted)}；未解释实验信号：{len(result.unexplained_observed)}",
            f"Structure consistency: {result.score:.1f}/100\nPredicted-signal coverage: {result.predicted_coverage:.0%}\nExperimental-signal coverage: {result.observed_coverage:.0%}\nShift RMSE: {rmse}\nMatched: {len(result.assignments)}; missing predicted: {len(result.missing_predicted)}; unexplained observed: {len(result.unexplained_observed)}",
        )
        if result.warnings:
            if self.tr.language == "en_US":
                details += (
                    "\n\n• This score verifies a candidate; it is not unique proof of an unknown structure."
                    "\n• Review low-quality, missing, and unexplained signals against impurities, overlap and model error."
                )
            else:
                details += "\n\n" + "\n".join(f"• {warning}" for warning in result.warnings)
        messagebox.showinfo(self.tr.t("structure.compare"), details, parent=self.window)

    def _populate_prediction(self, result: PredictionResult) -> None:
        self._clear_prediction_table()
        for index, signal in enumerate(result.signals, 1):
            iid = f"signal-{index}"
            self._tree_atoms[iid] = signal.atom_ids
            self.prediction_tree.insert(
                "",
                tk.END,
                iid=iid,
                values=(
                    ",".join(f"#{atom_id}" for atom_id in signal.atom_ids),
                    f"{signal.shift_ppm:.3f}",
                    f"{signal.uncertainty_ppm:g}",
                    f"{signal.integral:g}",
                    signal.multiplicity,
                    ", ".join(f"{value:g}" for value in signal.coupling_hz),
                    domain_text(signal.environment, self.tr.language),
                    f"{signal.confidence:.0f}",
                ),
            )
        ppm, intensity = simulate_prediction_spectrum(result)
        self.axes.clear()
        self.axes.plot(ppm, intensity, color="#111827", linewidth=0.85)
        for signal in result.signals:
            self.axes.vlines(
                signal.shift_ppm,
                0.0,
                min(1.08, 0.18 + 0.14 * signal.integral),
                color="#0f766e",
                linewidth=1.0,
                alpha=0.75,
            )
        high, low = spectrum_limits(result.nucleus)
        self.axes.set_xlim(high, low)
        self.axes.set_ylim(-0.04, 1.13)
        self.axes.set_xlabel("δ / ppm")
        self.axes.set_ylabel("模拟强度" if self.plot_language == "zh_CN" else "Simulated intensity")
        self.axes.set_title(
            ("预测 {nucleus} — {formula} — {solvent}" if self.plot_language == "zh_CN" else "Predicted {nucleus} — {formula} — {solvent}").format(
                nucleus=result.nucleus, formula=result.formula, solvent=result.solvent
            ),
            loc="left",
            fontsize=10,
        )
        self.axes.grid(axis="x", color="#e2e8f0", linewidth=0.5)
        self.axes.spines[["top", "right"]].set_visible(False)
        self.figure.tight_layout(pad=1.2)
        self.prediction_canvas.draw_idle()
        details = [
            self._txt(
                f"方法：{result.method}",
                f"Method: {domain_text(result.method, self.tr.language)}",
            )
        ]
        details.extend(f"• {domain_text(warning, self.tr.language)}" for warning in result.warnings)
        self._replace_warning("\n".join(details))

    def _clear_prediction_table(self) -> None:
        if hasattr(self, "prediction_tree"):
            self.prediction_tree.delete(*self.prediction_tree.get_children())
        self._tree_atoms.clear()
        self.highlight_atom_ids.clear()

    def _draw_empty_prediction(self, message: str | None = None) -> None:
        if not hasattr(self, "axes"):
            return
        message = message or self.plot_tr.t("structure.empty_prediction")
        self.axes.clear()
        self.axes.text(
            0.5,
            0.52,
            message,
            transform=self.axes.transAxes,
            ha="center",
            va="center",
            color="#64748b",
            wrap=True,
        )
        self.axes.set_axis_off()
        self.prediction_canvas.draw_idle()

    def _replace_warning(self, text: str) -> None:
        self.warning_text.configure(state=tk.NORMAL)
        self.warning_text.delete("1.0", tk.END)
        self.warning_text.insert(tk.END, text)
        self.warning_text.configure(state=tk.DISABLED)

    def _on_prediction_select(self, _event: tk.Event) -> None:
        selection = self.prediction_tree.selection()
        self.highlight_atom_ids = (
            set(self._tree_atoms.get(selection[0], ())) if selection else set()
        )
        self._draw_graph()

    def export_prediction(self) -> None:
        if self.current_prediction is None:
            self.run_prediction()
        if self.current_prediction is None:
            return
        path = filedialog.asksaveasfilename(
            parent=self.window,
            title=self._txt("导出预测峰表", "Export predicted peak table"),
            defaultextension=".csv",
            filetypes=((self._txt("CSV 峰表", "CSV peak table"), "*.csv"), ("JSON", "*.json")),
        )
        if path:
            try:
                write_prediction(self.current_prediction, path)
                self.status_var.set(self._txt(f"预测峰表已导出：{path}", f"Predicted peak table exported: {path}"))
            except Exception as exc:
                messagebox.showerror(self._txt("导出失败", "Export failed"), str(exc), parent=self.window)

    def show_help(self) -> None:
        messagebox.showinfo(
            self._txt("结构画板与预测边界", "Structure editor and prediction limits"),
            self._txt(
                "画板操作\n"
                "• 单键/双键/三键：从顶点向外拖动生成碳骨架，拖到另一顶点成键。\n"
                "• 原子按钮：单击顶点替换元素，单击空白放置独立原子。\n"
                "• 选择/移动：拖动顶点；Delete 或右键删除。\n"
                "• 苯环/六元环：单击空白或已有顶点放置模板。\n"
                "• 可保存 .onmrstruct，或用 RDKit 导入 SMILES/MOL。\n\n"
                "预测边界\n"
                "当前是离线、可解释的环境增量模型，支持 1H、13C、31P、19F 的快速预览。"
                "它不会取代实验谱、二维 NMR、标准品或高精度量化/机器学习预测；溶剂、温度、浓度、pH、构象、"
                "交换、手性和金属配位都可能造成显著偏差。峰表中的 ±ppm 与置信度用于提醒这些边界。",
                "Drawing controls\n"
                "• Drag from a vertex with the single/double/triple-bond tools to extend or connect a skeleton.\n"
                "• Atom buttons replace a vertex or place a standalone atom in empty space.\n"
                "• Select/move drags vertices; Delete or right-click removes an item.\n"
                "• Benzene and six-membered-ring tools place templates on empty space or an existing vertex.\n"
                "• Save .onmrstruct drawings or use RDKit to import SMILES/MOL.\n\n"
                "Prediction limits\n"
                "The current offline, explainable environment model previews 1H, 13C, 31P and 19F. "
                "It does not replace experimental or 2D NMR, reference standards, or validated quantum/ML prediction. "
                "Solvent, temperature, concentration, pH, conformation, exchange, stereochemistry and metal coordination may cause larger errors. "
                "The ±ppm values and confidence indicate these limits.",
            ),
            parent=self.window,
        )

    def close(self) -> None:
        if self._prediction_job is not None:
            try:
                self.window.after_cancel(self._prediction_job)
            except tk.TclError:
                pass
        self.window.destroy()

    def _bond_name(self, order: float) -> str:
        zh = {1.0: "单键", 1.5: "芳香键", 2.0: "双键", 3.0: "三键"}.get(order, "化学键")
        en = {1.0: "single bond", 1.5: "aromatic bond", 2.0: "double bond", 3.0: "triple bond"}.get(order, "bond")
        return self._txt(zh, en)


def _point_segment_distance(
    px: float, py: float, x1: float, y1: float, x2: float, y2: float
) -> float:
    dx, dy = x2 - x1, y2 - y1
    if dx == 0 and dy == 0:
        return math.hypot(px - x1, py - y1)
    fraction = ((px - x1) * dx + (py - y1) * dy) / (dx * dx + dy * dy)
    fraction = min(1.0, max(0.0, fraction))
    closest_x, closest_y = x1 + fraction * dx, y1 + fraction * dy
    return math.hypot(px - closest_x, py - closest_y)
