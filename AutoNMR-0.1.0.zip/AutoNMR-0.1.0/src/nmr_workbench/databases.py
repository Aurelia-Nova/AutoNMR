"""Database-link profiles with strict URL validation.

This preview intentionally opens searches in the user's browser.  It does not
scrape subscription services or store their credentials.  Future API adapters
can implement the separate connector protocol without changing the UI model.
"""

from __future__ import annotations

import ipaddress
import json
import re
import string
from dataclasses import asdict, dataclass, replace
from importlib.resources import files
from pathlib import Path
from typing import Protocol, runtime_checkable
from urllib.parse import quote, urlsplit

from .app_paths import database_profiles_path


ALLOWED_QUERY_FIELDS = {"query",  "name", "formula", "smiles", "inchi_key", "cas"}
PROFILE_ID_RE = re.compile(r"^[a-z0-9][a-z0-9._-]{1,63}$")


class DatabaseProfileError(ValueError):
    pass


@dataclass(slots=True)
class DatabaseProfile:
    id: str
    name: str
    category: str
    home_url: str
    search_url: str = ""
    enabled: bool = True
    access: str = "public"
    notes: str = ""
    custom: bool = False
    allow_insecure_local: bool = False

    def validated(self) -> "DatabaseProfile":
        profile = replace(
            self,
            id=self.id.strip().casefold(),
            name=self.name.strip(),
            category=self.category.strip() or "custom",
            home_url=self.home_url.strip(),
            search_url=self.search_url.strip(),
            access=self.access.strip() or "custom",
            notes=self.notes.strip(),
        )
        if not PROFILE_ID_RE.fullmatch(profile.id):
            raise DatabaseProfileError("Profile id must contain 2-64 lowercase letters, digits, dots, underscores or hyphens")
        if not profile.name or len(profile.name) > 120:
            raise DatabaseProfileError("Database name is required and must be at most 120 characters")
        _validate_url(profile.home_url, allow_insecure_local=profile.allow_insecure_local)
        if profile.search_url:
            _validate_url(profile.search_url, allow_insecure_local=profile.allow_insecure_local, template=True)
            fields = {field for _, field, _, _ in string.Formatter().parse(profile.search_url) if field}
            unknown = fields - ALLOWED_QUERY_FIELDS
            if unknown:
                raise DatabaseProfileError(f"Unsupported URL-template fields: {', '.join(sorted(unknown))}")
        return profile

    def build_url(self, values: dict[str, str] | str = "") -> str:
        profile = self.validated()
        if not profile.search_url:
            return profile.home_url
        supplied = {"query": values} if isinstance(values, str) else dict(values)
        safe = {key: quote(str(supplied.get(key, "")), safe="") for key in ALLOWED_QUERY_FIELDS}
        try:
            rendered = profile.search_url.format_map(safe)
        except (KeyError, ValueError) as exc:
            raise DatabaseProfileError(f"Invalid search URL template: {exc}") from exc
        _validate_url(rendered, allow_insecure_local=profile.allow_insecure_local)
        return rendered


def _is_local_host(hostname: str | None) -> bool:
    host = (hostname or "").strip("[]").casefold()
    if host in {"localhost", "localhost.localdomain"} or host.endswith(".local"):
        return True
    try:
        return ipaddress.ip_address(host).is_private or ipaddress.ip_address(host).is_loopback
    except ValueError:
        return False


def _validate_url(value: str, *, allow_insecure_local: bool, template: bool = False) -> None:
    if not value or len(value) > 2048:
        raise DatabaseProfileError("URL is required and must be at most 2048 characters")
    probe = value
    if template:
        for field in ALLOWED_QUERY_FIELDS:
            probe = probe.replace("{" + field + "}", "probe")
    parsed = urlsplit(probe)
    if parsed.username or parsed.password:
        raise DatabaseProfileError("Credentials must not be embedded in a database URL")
    if parsed.scheme == "https" and parsed.hostname:
        return
    if parsed.scheme == "http" and parsed.hostname and allow_insecure_local and _is_local_host(parsed.hostname):
        return
    raise DatabaseProfileError("Use HTTPS. Plain HTTP is allowed only for an explicitly approved local/LAN database")


def default_database_profiles() -> list[DatabaseProfile]:
    resource = files("nmr_workbench").joinpath("data", "database_profiles.json")
    payload = json.loads(resource.read_text(encoding="utf-8"))
    return [DatabaseProfile(**item).validated() for item in payload.get("profiles", [])]


class DatabaseProfileStore:
    def __init__(self, path: str | Path | None = None) -> None:
        self.path = Path(path) if path is not None else database_profiles_path()

    def load(self) -> list[DatabaseProfile]:
        if not self.path.exists():
            return default_database_profiles()
        try:
            if self.path.stat().st_size > 1_000_000:
                raise DatabaseProfileError("Database profile file is unexpectedly large")
            payload = json.loads(self.path.read_text(encoding="utf-8"))
            profiles = [DatabaseProfile(**item).validated() for item in payload.get("profiles", [])]
            return profiles or default_database_profiles()
        except (OSError, ValueError, TypeError) as exc:
            raise DatabaseProfileError(f"Could not read database profiles: {exc}") from exc

    def save(self, profiles: list[DatabaseProfile]) -> Path:
        checked = [profile.validated() for profile in profiles]
        ids = [profile.id for profile in checked]
        if len(ids) != len(set(ids)):
            raise DatabaseProfileError("Database profile ids must be unique")
        self.path.parent.mkdir(parents=True, exist_ok=True)
        temp = self.path.with_suffix(self.path.suffix + ".tmp")
        temp.write_text(
            json.dumps({"schema_version": 1, "profiles": [asdict(item) for item in checked]}, ensure_ascii=False, indent=2) + "\n",
            encoding="utf-8",
        )
        temp.replace(self.path)
        return self.path

    def reset(self) -> list[DatabaseProfile]:
        profiles = default_database_profiles()
        self.save(profiles)
        return profiles


@runtime_checkable
class DatabaseConnector(Protocol):
    id: str

    def search(self, query: dict[str, str]) -> list[dict[str, object]]: ...

