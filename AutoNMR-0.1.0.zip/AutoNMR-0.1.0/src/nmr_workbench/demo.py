from __future__ import annotations

import numpy as np

from .models import FID1D, Spectrum1D


_PASCAL = {
    "s": np.array([1.0]),
    "d": np.array([1.0, 1.0]),
    "t": np.array([1.0, 2.0, 1.0]),
    "q": np.array([1.0, 3.0, 3.0, 1.0]),
    "quint": np.array([1.0, 4.0, 6.0, 4.0, 1.0]),
    "sext": np.array([1.0, 5.0, 10.0, 10.0, 5.0, 1.0]),
    "sept": np.array([1.0, 6.0, 15.0, 20.0, 15.0, 6.0, 1.0]),
}


def _line_pattern(center_ppm: float, multiplicity: str, coupling_hz: float, frequency_mhz: float):
    weights = _PASCAL[multiplicity]
    offsets = np.arange(weights.size, dtype=float) - (weights.size - 1) / 2.0
    positions = center_ppm + offsets * coupling_hz / frequency_mhz
    return positions, weights / weights.sum()


def _add_lorentzian_multiplet(
    ppm: np.ndarray,
    output: np.ndarray,
    center: float,
    multiplicity: str,
    coupling_hz: float,
    protons: float,
    frequency_mhz: float,
    linewidth_hz: float = 1.2,
) -> None:
    positions, weights = _line_pattern(center, multiplicity, coupling_hz, frequency_mhz)
    half_width = linewidth_hz / frequency_mhz / 2.0
    for position, weight in zip(positions, weights):
        output += protons * weight * half_width**2 / ((ppm - position) ** 2 + half_width**2)


def generate_demo_spectrum(points: int = 65536, seed: int = 20260812) -> Spectrum1D:
    """Synthetic 400 MHz ethyl-acetate spectrum with residual solvent and water."""
    frequency = 400.0
    ppm = np.linspace(12.0, -1.0, points)
    y = np.zeros(points, dtype=float)
    _add_lorentzian_multiplet(ppm, y, 4.12, "q", 7.1, 2.0, frequency)
    _add_lorentzian_multiplet(ppm, y, 2.05, "s", 0.0, 3.0, frequency)
    _add_lorentzian_multiplet(ppm, y, 1.26, "t", 7.1, 3.0, frequency)
    _add_lorentzian_multiplet(ppm, y, 7.26, "s", 0.0, 0.20, frequency, linewidth_hz=1.0)
    _add_lorentzian_multiplet(ppm, y, 1.56, "s", 0.0, 0.10, frequency, linewidth_hz=3.5)
    baseline = 0.0018 + 0.000035 * (ppm - 5.0) ** 2 + 0.0007 * np.sin(ppm * 0.72)
    rng = np.random.default_rng(seed)
    y += baseline + rng.normal(0.0, 0.0010, points)
    return Spectrum1D(
        ppm=ppm,
        intensity=y,
        spectrometer_mhz=frequency,
        nucleus="1H",
        solvent="CDCl3",
        title="演示: 乙酸乙酯（合成谱）",
        metadata={"format": "synthetic demo", "known_analyte": "乙酸乙酯"},
    )


def generate_demo_fid(
    points: int = 8192,
    spectrometer_mhz: float = 400.0,
    spectral_width_hz: float = 6400.0,
    carrier_ppm: float = 6.0,
    phase0_deg: float = 32.0,
) -> FID1D:
    dwell = 1.0 / spectral_width_hz
    time = np.arange(points, dtype=float) * dwell
    data = np.zeros(points, dtype=np.complex128)
    components = [
        (4.12, "q", 7.1, 2.0, 1.2),
        (2.05, "s", 0.0, 3.0, 1.1),
        (1.26, "t", 7.1, 3.0, 1.2),
        (7.26, "s", 0.0, 0.20, 1.0),
    ]
    phase = np.deg2rad(phase0_deg)
    for center, multiplicity, coupling, protons, linewidth in components:
        positions, weights = _line_pattern(center, multiplicity, coupling, spectrometer_mhz)
        for position, weight in zip(positions, weights):
            frequency_hz = (position - carrier_ppm) * spectrometer_mhz
            data += (
                protons
                * weight
                * np.exp(-np.pi * linewidth * time)
                * np.exp(1j * (2.0 * np.pi * frequency_hz * time + phase))
            )
    rng = np.random.default_rng(20260812)
    data += rng.normal(0.0, 0.0015, points) + 1j * rng.normal(0.0, 0.0015, points)
    return FID1D(
        data=data,
        dwell_time_s=dwell,
        spectrometer_mhz=spectrometer_mhz,
        carrier_ppm=carrier_ppm,
        nucleus="1H",
        solvent="CDCl3",
        title="演示 FID：乙酸乙酯",
        metadata={"format": "synthetic demo FID", "known_phase0_deg": phase0_deg},
    )

