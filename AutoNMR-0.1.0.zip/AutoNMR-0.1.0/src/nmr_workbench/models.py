from __future__ import annotations

from dataclasses import asdict, dataclass, field
from typing import Any

import numpy as np


def _native(value: Any) -> Any:
    """Convert dataclass/numpy values to JSON-safe Python values."""
    if isinstance(value, np.ndarray):
        return value.tolist()
    if isinstance(value, np.generic):
        return value.item()
    if hasattr(value, "to_dict"):
        return value.to_dict()
    if isinstance(value, dict):
        return {str(k): _native(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [_native(v) for v in value]
    return value


@dataclass(slots=True)
class FID1D:
    data: np.ndarray
    dwell_time_s: float
    spectrometer_mhz: float
    carrier_ppm: float
    nucleus: str = "1H"
    solvent: str = "CDCl3"
    title: str = "Untitled FID"
    group_delay_points: float = 0.0
    metadata: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        self.data = np.asarray(self.data, dtype=np.complex128).reshape(-1)
        if self.data.size < 8:
            raise ValueError("FID 至少需要 8 个复数点")
        if not np.isfinite(self.dwell_time_s) or self.dwell_time_s <= 0:
            raise ValueError("dwell_time_s 必须为正数")
        if not np.isfinite(self.spectrometer_mhz) or self.spectrometer_mhz <= 0:
            raise ValueError("spectrometer_mhz 必须为正数")

    @property
    def spectral_width_hz(self) -> float:
        return 1.0 / self.dwell_time_s


@dataclass(slots=True)
class Spectrum1D:
    ppm: np.ndarray
    intensity: np.ndarray
    spectrometer_mhz: float = 400.0
    nucleus: str = "1H"
    solvent: str = "CDCl3"
    title: str = "Untitled spectrum"
    metadata: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        self.ppm = np.asarray(self.ppm, dtype=float).reshape(-1)
        self.intensity = np.asarray(self.intensity, dtype=float).reshape(-1)
        if self.ppm.size != self.intensity.size:
            raise ValueError("ppm 与 intensity 的点数不一致")
        if self.ppm.size < 8:
            raise ValueError("谱图至少需要 8 个点")
        mask = np.isfinite(self.ppm) & np.isfinite(self.intensity)
        if mask.sum() < 8:
            raise ValueError("谱图中有效数据点不足")
        if not np.all(mask):
            self.ppm = self.ppm[mask]
            self.intensity = self.intensity[mask]
        order = np.argsort(self.ppm)[::-1]
        self.ppm = self.ppm[order]
        self.intensity = self.intensity[order]
        if self.spectrometer_mhz <= 0:
            raise ValueError("spectrometer_mhz 必须为正数")

    @property
    def ppm_step(self) -> float:
        return float(np.median(np.abs(np.diff(self.ppm))))

    @property
    def limits(self) -> tuple[float, float]:
        return float(self.ppm.max()), float(self.ppm.min())

    def copy(self, **updates: Any) -> "Spectrum1D":
        values = {
            "ppm": self.ppm.copy(),
            "intensity": self.intensity.copy(),
            "spectrometer_mhz": self.spectrometer_mhz,
            "nucleus": self.nucleus,
            "solvent": self.solvent,
            "title": self.title,
            "metadata": dict(self.metadata),
        }
        values.update(updates)
        return Spectrum1D(**values)


@dataclass(slots=True)
class Peak:
    position_ppm: float
    intensity: float
    prominence: float
    width_hz: float
    snr: float
    index: int
    source: str = "auto"

    def to_dict(self) -> dict[str, Any]:
        return _native(asdict(self))


@dataclass(slots=True)
class ReferenceMatch:
    name: str
    category: str
    matched_shifts: list[float]
    expected_shifts: list[float]
    score: float
    note: str = ""

    def to_dict(self) -> dict[str, Any]:
        return _native(asdict(self))


@dataclass(slots=True)
class Signal:
    center_ppm: float
    start_ppm: float
    end_ppm: float
    peaks: list[Peak]
    area: float
    relative_integral: float
    estimated_protons: float | None
    multiplicity: str
    coupling_hz: list[float]
    region: str
    assignment_hints: list[str] = field(default_factory=list)
    reference_match: ReferenceMatch | None = None
    confidence: float = 0.0
    source: str = "auto"

    def to_dict(self) -> dict[str, Any]:
        return _native(asdict(self))


@dataclass(slots=True)
class FragmentHint:
    label: str
    evidence: str
    signal_indices: list[int]
    confidence: float

    def to_dict(self) -> dict[str, Any]:
        return _native(asdict(self))


@dataclass(slots=True)
class CandidateScore:
    name: str
    score: float
    matched: int
    expected: int
    shift_rmse: float | None
    coverage: float
    formula: str = ""
    smiles: str = ""
    explanation: list[str] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        return _native(asdict(self))


@dataclass(slots=True)
class AnalysisReport:
    title: str
    nucleus: str
    solvent: str
    spectrometer_mhz: float
    noise_sigma: float
    signals: list[Signal]
    fragments: list[FragmentHint] = field(default_factory=list)
    candidates: list[CandidateScore] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)
    parameters: dict[str, Any] = field(default_factory=dict)
    quality_score: float = 0.0
    manual_integrals: list[dict[str, float]] = field(default_factory=list)

    def to_dict(self, include_peak_details: bool = True) -> dict[str, Any]:
        data = _native(asdict(self))
        if not include_peak_details:
            for signal in data["signals"]:
                signal.pop("peaks", None)
        return data

