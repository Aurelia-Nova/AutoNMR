"""Curated deuterated-solvent metadata from the supplied reference PDFs."""

from __future__ import annotations

import json
from dataclasses import dataclass
from functools import lru_cache
from importlib.resources import files


@dataclass(frozen=True, slots=True)
class SolventPeak:
    shift: float
    multiplicity: str = "s"


@dataclass(frozen=True, slots=True)
class DeuteratedSolvent:
    id: str
    name_zh: str
    name_en: str
    formula: str
    aliases: tuple[str, ...]
    source: str
    residual: dict[str, tuple[SolventPeak, ...]]
    water_1h: tuple[SolventPeak, ...]

    def display_name(self, language: str = "zh_CN") -> str:
        name = self.name_en if language == "en_US" else self.name_zh
        return f"{self.id} — {name}"


@lru_cache(maxsize=1)
def load_solvent_payload() -> dict[str, object]:
    resource = files("nmr_workbench").joinpath("data", "deuterated_solvents.json")
    return json.loads(resource.read_text(encoding="utf-8"))


@lru_cache(maxsize=1)
def deuterated_solvents() -> tuple[DeuteratedSolvent, ...]:
    payload = load_solvent_payload()
    result: list[DeuteratedSolvent] = []
    for item in payload.get("solvents", []):
        residual = {
            nucleus: tuple(
                SolventPeak(float(peak["shift"]), str(peak.get("multiplicity", "s")))
                for peak in peaks
            )
            for nucleus, peaks in item.get("residual", {}).items()
        }
        result.append(
            DeuteratedSolvent(
                id=str(item["id"]),
                name_zh=str(item.get("name_zh", item["id"])),
                name_en=str(item.get("name_en", item["id"])),
                formula=str(item.get("formula", "")),
                aliases=tuple(str(value) for value in item.get("aliases", [])),
                source=str(item.get("source", "")),
                residual=residual,
                water_1h=tuple(
                    SolventPeak(float(peak["shift"]), str(peak.get("multiplicity", "br s")))
                    for peak in item.get("water_1h", [])
                ),
            )
        )
    return tuple(result)


@lru_cache(maxsize=1)
def _alias_map() -> dict[str, str]:
    mapping: dict[str, str] = {}
    for solvent in deuterated_solvents():
        for value in (solvent.id, *solvent.aliases):
            mapping[value.strip().casefold()] = solvent.id
    return mapping


def canonical_solvent_id(value: str) -> str:
    stripped = value.strip()
    return _alias_map().get(stripped.casefold(), stripped)


def get_solvent(value: str) -> DeuteratedSolvent | None:
    canonical = canonical_solvent_id(value)
    return next((item for item in deuterated_solvents() if item.id == canonical), None)


def solvent_ids() -> tuple[str, ...]:
    return tuple(item.id for item in deuterated_solvents())


def solvent_display_values(language: str = "zh_CN") -> tuple[str, ...]:
    return tuple(item.display_name(language) for item in deuterated_solvents())


def solvent_id_from_display(value: str) -> str:
    possible = value.split(" — ", 1)[0].strip()
    return canonical_solvent_id(possible)

