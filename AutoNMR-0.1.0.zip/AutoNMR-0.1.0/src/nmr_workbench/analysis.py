from __future__ import annotations

from dataclasses import asdict, dataclass
from typing import Iterable

import numpy as np
from scipy.signal import find_peaks, peak_widths, savgol_filter

from .candidates import Candidate, load_candidate_library, rank_candidates
from .formula import degree_of_unsaturation, hydrogen_count
from .models import AnalysisReport, FragmentHint, Peak, Signal, Spectrum1D
from .references import canonical_solvent, match_references, reference_entries


@dataclass(slots=True)
class AnalysisConfig:
    snr_threshold: float = 6.0
    minimum_peak_distance_ppm: float = 0.0015
    group_gap_hz: float = 28.0
    integration_margin_hz: float = 8.0
    maximum_peaks: int = 500
    molecular_formula: str = ""
    total_protons: float | None = None
    identify_references: bool = True
    candidate_limit: int = 10
    include_demo_candidates: bool = True

    def validate(self) -> None:
        if self.snr_threshold < 2.0:
            raise ValueError("S/N 阈值过低，建议不小于 2")
        if self.group_gap_hz <= 0:
            raise ValueError("信号归组间隔必须为正数")
        if self.maximum_peaks < 1:
            raise ValueError("maximum_peaks 必须为正整数")


def estimate_noise_sigma(values: np.ndarray) -> float:
    """Robustly estimate point noise from the first difference."""
    y = np.asarray(values, dtype=float)
    if y.size < 4:
        return float(np.std(y))
    differences = np.diff(y)
    work = differences[np.isfinite(differences)]
    for _ in range(4):
        if work.size < 10:
            break
        center = np.median(work)
        sigma_difference = 1.4826 * np.median(np.abs(work - center))
        if sigma_difference <= np.finfo(float).eps:
            break
        clipped = work[np.abs(work - center) < 3.5 * sigma_difference]
        if clipped.size == work.size:
            break
        work = clipped
    sigma_difference = 1.4826 * np.median(np.abs(work - np.median(work)))
    sigma = sigma_difference / np.sqrt(2.0)
    if not np.isfinite(sigma) or sigma <= 0:
        sigma = float(np.std(work) / np.sqrt(2.0))
    return max(float(sigma), np.finfo(float).eps)


def _smooth_for_peaks(values: np.ndarray) -> np.ndarray:
    y = np.asarray(values, dtype=float)
    if y.size < 9:
        return y.copy()
    window = 7 if y.size < 100_000 else 9
    return savgol_filter(y, window_length=window, polyorder=2, mode="interp")


def pick_peaks(
    spectrum: Spectrum1D,
    config: AnalysisConfig,
    manual_positions_ppm: Iterable[float] | None = None,
) -> tuple[list[Peak], float]:
    y = spectrum.intensity
    smooth = _smooth_for_peaks(y)
    noise = estimate_noise_sigma(y)
    distance_points = max(1, int(round(config.minimum_peak_distance_ppm / spectrum.ppm_step)))
    indices, properties = find_peaks(
        smooth,
        prominence=config.snr_threshold * noise,
        height=2.0 * noise,
        distance=distance_points,
    )
    prominences = np.asarray(properties.get("prominences", np.zeros(indices.size)))
    if indices.size > config.maximum_peaks:
        keep = np.argsort(prominences)[-config.maximum_peaks :]
        indices = indices[keep]
        prominences = prominences[keep]
    widths_points = peak_widths(smooth, indices, rel_height=0.5)[0] if indices.size else np.empty(0)
    peaks = [
        Peak(
            position_ppm=float(spectrum.ppm[index]),
            intensity=float(y[index]),
            prominence=float(prominence),
            width_hz=float(width * spectrum.ppm_step * spectrum.spectrometer_mhz),
            snr=float(max(y[index], prominence) / noise),
            index=int(index),
        )
        for index, prominence, width in zip(indices, prominences, widths_points)
    ]
    for position in manual_positions_ppm or []:
        index = int(np.argmin(np.abs(spectrum.ppm - float(position))))
        if any(abs(peak.position_ppm - spectrum.ppm[index]) <= spectrum.ppm_step for peak in peaks):
            continue
        peaks.append(
            Peak(
                position_ppm=float(spectrum.ppm[index]),
                intensity=float(y[index]),
                prominence=float(max(y[index], 0.0)),
                width_hz=0.0,
                snr=float(max(y[index], 0.0) / noise),
                index=index,
                source="manual",
            )
        )
    return sorted(peaks, key=lambda peak: peak.position_ppm, reverse=True), noise


def _classify_multiplicity(peaks: list[Peak], spectrometer_mhz: float) -> tuple[str, list[float], float]:
    count = len(peaks)
    if count <= 1:
        return "s", [], 0.90
    positions = np.sort(np.asarray([peak.position_ppm for peak in peaks], dtype=float))
    spacings = np.diff(positions) * spectrometer_mhz
    mean_spacing = float(np.mean(spacings))
    regularity = float(np.std(spacings) / max(mean_spacing, 1e-9))
    regular = regularity <= 0.20
    labels = {2: "d", 3: "t", 4: "q", 5: "quint", 6: "sext", 7: "sept"}
    if count == 4 and not regular:
        # First-order dd line spacings are j_small, j_large-j_small, j_small.
        if abs(spacings[0] - spacings[2]) <= max(0.5, 0.15 * mean_spacing):
            j_small = float((spacings[0] + spacings[2]) / 2.0)
            j_large = float(spacings[1] + j_small)
            return "dd", sorted([j_small, j_large], reverse=True), 0.82
    if regular and count in labels:
        return labels[count], [mean_spacing], float(np.clip(0.95 - regularity, 0.55, 0.95))
    unique: list[float] = []
    for value in sorted(spacings, reverse=True):
        if value < 0.3:
            continue
        if not unique or all(abs(value - old) > max(0.6, 0.15 * old) for old in unique):
            unique.append(float(value))
        if len(unique) == 3:
            break
    return "m", unique, float(np.clip(0.55 - 0.15 * regularity, 0.20, 0.55))


def _region_hint(position: float, nucleus: str) -> tuple[str, list[str]]:
    normalized = nucleus.upper().replace("^", "")
    if "13C" in normalized or normalized == "C13":
        if position >= 160:
            return "羰基碳区", ["醛/酮/羧酸衍生物羰基碳"]
        if position >= 100:
            return "sp² 碳区", ["芳环、烯烃或杂芳环碳"]
        if position >= 50:
            return "杂原子取代 sp³ 碳区", ["C–O/C–N/C–X 或缩醛碳"]
        return "脂肪 sp³ 碳区", ["烷基或羰基 α-碳"]
    if position >= 10.0:
        return "强去屏蔽/可交换氢区", ["羧酸、强氢键酚或其他可交换氢"]
    if position >= 8.7:
        return "醛基/杂芳环区", ["醛氢或强去屏蔽杂芳环氢"]
    if position >= 6.3:
        return "芳香/烯烃区", ["芳环、杂芳环或烯烃氢"]
    if position >= 4.5:
        return "烯烃/缩醛区", ["烯烃氢、缩醛/异头氢或二杂原子取代碳上的氢"]
    if position >= 3.0:
        return "杂原子邻位区", ["O–CH、N–CH 或卤代烷基"]
    if position >= 1.8:
        return "苄位/羰基 α 位区", ["苄位、烯丙位、炔丙位或羰基 α-氢"]
    if position >= 0.5:
        return "脂肪烷基区", ["普通烷基氢"]
    return "高场区", ["高度屏蔽烷基、硅烷/硅氧烷或内标"]


def _group_peaks(peaks: list[Peak], spectrum: Spectrum1D, config: AnalysisConfig) -> list[list[Peak]]:
    if not peaks:
        return []
    gap_ppm = config.group_gap_hz / spectrum.spectrometer_mhz
    groups: list[list[Peak]] = [[peaks[0]]]
    for peak in peaks[1:]:
        previous = groups[-1][-1]
        if abs(previous.position_ppm - peak.position_ppm) <= gap_ppm:
            groups[-1].append(peak)
        else:
            groups.append([peak])
    return groups


def _signal_bounds(groups: list[list[Peak]], spectrum: Spectrum1D, config: AnalysisConfig) -> list[tuple[float, float]]:
    margin = max(config.integration_margin_hz / spectrum.spectrometer_mhz, 3.0 * spectrum.ppm_step)
    bounds: list[list[float]] = []
    for group in groups:
        width_margin = max((peak.width_hz for peak in group), default=0.0) / spectrum.spectrometer_mhz
        local_margin = max(margin, 1.5 * width_margin)
        bounds.append([max(peak.position_ppm for peak in group) + local_margin, min(peak.position_ppm for peak in group) - local_margin])
    for i in range(len(bounds) - 1):
        # ppm decreases left-to-right.  Overlapping integration windows meet at
        # the midpoint, preventing double counting.
        if bounds[i][1] < bounds[i + 1][0]:
            midpoint = (min(peak.position_ppm for peak in groups[i]) + max(peak.position_ppm for peak in groups[i + 1])) / 2.0
            bounds[i][1] = midpoint
            bounds[i + 1][0] = midpoint
    high_limit, low_limit = spectrum.limits
    return [(min(high, high_limit), max(low, low_limit)) for high, low in bounds]


def _integrate(spectrum: Spectrum1D, high_ppm: float, low_ppm: float) -> float:
    mask = (spectrum.ppm <= high_ppm) & (spectrum.ppm >= low_ppm)
    if mask.sum() < 2:
        return 0.0
    return float(abs(np.trapezoid(np.clip(spectrum.intensity[mask], 0.0, None), spectrum.ppm[mask])))


def build_signals(
    spectrum: Spectrum1D,
    peaks: list[Peak],
    config: AnalysisConfig,
) -> list[Signal]:
    groups = _group_peaks(peaks, spectrum, config)
    bounds = _signal_bounds(groups, spectrum, config)
    signals: list[Signal] = []
    for group, (high, low) in zip(groups, bounds):
        weights = np.asarray([max(peak.intensity, 0.0) for peak in group])
        positions = np.asarray([peak.position_ppm for peak in group])
        center = float(np.average(positions, weights=weights)) if weights.sum() > 0 else float(np.mean(positions))
        multiplicity, coupling, mult_confidence = _classify_multiplicity(group, spectrum.spectrometer_mhz)
        region, hints = _region_hint(center, spectrum.nucleus)
        snr_confidence = float(np.clip(np.log10(max(np.mean([p.snr for p in group]), 1.0)) / 2.0, 0.0, 1.0))
        signals.append(
            Signal(
                center_ppm=center,
                start_ppm=high,
                end_ppm=low,
                peaks=group,
                area=_integrate(spectrum, high, low),
                relative_integral=0.0,
                estimated_protons=None,
                multiplicity=multiplicity,
                coupling_hz=coupling,
                region=region,
                assignment_hints=hints,
                confidence=float(100.0 * (0.55 * mult_confidence + 0.45 * snr_confidence)),
                source="manual" if any(peak.source == "manual" for peak in group) else "auto",
            )
        )
    return signals


def _normalize_integrals(signals: list[Signal], config: AnalysisConfig) -> tuple[float | None, list[str]]:
    warnings: list[str] = []
    excluded_categories = {"residual solvent", "water", "reference"}
    usable = [
        signal
        for signal in signals
        if signal.area > 0
        and (signal.reference_match is None or signal.reference_match.category not in excluded_categories)
    ]
    if not usable:
        return None, warnings
    quantum = min(signal.area for signal in usable)
    for signal in signals:
        signal.relative_integral = signal.area / quantum if quantum > 0 else 0.0

    total = config.total_protons
    if total is None and config.molecular_formula.strip():
        try:
            total = float(hydrogen_count(config.molecular_formula) or 0)
        except ValueError as exc:
            warnings.append(str(exc))
    if total is not None and total > 0:
        total_area = sum(signal.area for signal in usable)
        for signal in usable:
            signal.estimated_protons = signal.area / total_area * total
        warnings.append("估算氢数按可积分信号总面积缩放；交换峰、重叠峰或漏峰会造成偏差。")
    return total, warnings


def _integral_value(signal: Signal) -> float:
    return signal.estimated_protons if signal.estimated_protons is not None else signal.relative_integral


def infer_fragments(signals: list[Signal], nucleus: str) -> list[FragmentHint]:
    if "1H" not in nucleus.upper().replace("^", "") and nucleus.upper() != "H1":
        return []
    usable = [
        (i, signal)
        for i, signal in enumerate(signals)
        if signal.reference_match is None
        or signal.reference_match.category not in {"residual solvent", "water", "reference"}
    ]
    hints: list[FragmentHint] = []
    for index, signal in usable:
        if 9.0 <= signal.center_ppm <= 10.5:
            hints.append(FragmentHint("可能存在醛基 –CHO", f"δ {signal.center_ppm:.2f} ppm 的去屏蔽 1H 信号", [index], 78.0))
        if signal.center_ppm >= 10.0:
            hints.append(FragmentHint("可能存在强氢键可交换氢", f"δ {signal.center_ppm:.2f} ppm；需用 D2O 交换验证", [index], 52.0))
        value = _integral_value(signal)
        if signal.multiplicity == "s" and 0.6 <= signal.center_ppm <= 1.5 and 7.0 <= value <= 11.0:
            hints.append(FragmentHint("可能存在叔丁基 C(CH3)3", f"高场单峰积分约 {value:.1f}", [index], 80.0))
        if signal.multiplicity == "s" and 3.15 <= signal.center_ppm <= 4.15 and 2.3 <= value <= 3.7:
            hints.append(
                FragmentHint(
                    "可能存在甲氧基 OCH3",
                    f"δ {signal.center_ppm:.2f} ppm 的约 3H 单峰；需排除甲醇、甲酯或 NCH3 等重叠解释",
                    [index],
                    66.0,
                )
            )
        if signal.multiplicity == "s" and 1.85 <= signal.center_ppm <= 2.75 and 2.3 <= value <= 3.7:
            hints.append(
                FragmentHint(
                    "可能存在羰基/烯基相邻甲基",
                    f"δ {signal.center_ppm:.2f} ppm 的约 3H 单峰，符合 COCH3、ArCH3 或烯丙位 CH3 的部分范围",
                    [index],
                    55.0,
                )
            )
        if 6.3 <= signal.center_ppm <= 8.7 and 0.6 <= value <= 6.5:
            hints.append(
                FragmentHint(
                    "芳香或杂芳香氢证据",
                    f"δ {signal.center_ppm:.2f} ppm，积分约 {value:.1f}；具体取代模式需结合全部芳香峰及二维相关",
                    [index],
                    48.0,
                )
            )

    for left_pos, (left_index, left) in enumerate(usable):
        for right_index, right in usable[left_pos + 1 :]:
            j_left = left.coupling_hz[0] if left.coupling_hz else None
            j_right = right.coupling_hz[0] if right.coupling_hz else None
            j_match = j_left is not None and j_right is not None and abs(j_left - j_right) <= 1.2
            left_int, right_int = _integral_value(left), _integral_value(right)
            ratio = left_int / max(right_int, 1e-9)
            multiplicities = {left.multiplicity, right.multiplicity}
            if multiplicities == {"t", "q"} and j_match:
                expected_ratio = 1.5 if left.multiplicity == "t" else 2.0 / 3.0
                ratio_score = np.exp(-2.0 * abs(np.log(max(ratio, 1e-6) / expected_ratio)))
                confidence = float(68.0 + 24.0 * ratio_score)
                hints.append(
                    FragmentHint(
                        "可能存在乙基 –CH2CH3",
                        f"同一 J≈{(j_left + j_right) / 2:.1f} Hz 的 t/q 成对信号，积分比约 {ratio:.2f}",
                        [left_index, right_index],
                        confidence,
                    )
                )
            if multiplicities == {"d", "sept"} and j_match:
                expected_ratio = 6.0 if left.multiplicity == "d" else 1.0 / 6.0
                ratio_score = np.exp(-1.5 * abs(np.log(max(ratio, 1e-6) / expected_ratio)))
                hints.append(
                    FragmentHint(
                        "可能存在异丙基 –CH(CH3)2",
                        f"同一 J≈{(j_left + j_right) / 2:.1f} Hz 的 d/sept 成对信号",
                        [left_index, right_index],
                        float(66.0 + 25.0 * ratio_score),
                    )
                )
            if (
                left.multiplicity == right.multiplicity == "d"
                and j_match
                and 6.3 <= left.center_ppm <= 8.7
                and 6.3 <= right.center_ppm <= 8.7
                and 0.55 <= ratio <= 1.8
            ):
                hints.append(
                    FragmentHint(
                        "可能存在近似对称的二取代芳环",
                        f"两组芳香区双峰具有相近 J≈{(j_left + j_right) / 2:.1f} Hz，积分比约 {ratio:.2f}；常见于对位取代，但并非唯一解释",
                        [left_index, right_index],
                        70.0,
                    )
                )
            if (
                {left.multiplicity, right.multiplicity} <= {"d", "m", "sept"}
                and j_match
                and ((4.5 <= left.center_ppm <= 6.8 and 6.3 <= right.center_ppm <= 8.5)
                     or (4.5 <= right.center_ppm <= 6.8 and 6.3 <= left.center_ppm <= 8.5))
            ):
                hints.append(
                    FragmentHint(
                        "可能存在相互偶合的烯烃/芳香氢",
                        f"两组去屏蔽信号共享 J≈{(j_left + j_right) / 2:.1f} Hz；需结合 COSY 与取代环境确认",
                        [left_index, right_index],
                        52.0,
                    )
                )
    # Avoid repeated labels from overlapping weak patterns.
    unique: dict[tuple[str, tuple[int, ...]], FragmentHint] = {}
    for hint in hints:
        key = hint.label, tuple(hint.signal_indices)
        if key not in unique or hint.confidence > unique[key].confidence:
            unique[key] = hint
    return sorted(unique.values(), key=lambda item: item.confidence, reverse=True)


def _quality_score(spectrum: Spectrum1D, signals: list[Signal], noise: float) -> tuple[float, list[str]]:
    warnings: list[str] = []
    y = spectrum.intensity
    dynamic_snr = float(np.percentile(y, 99.8) / max(noise, np.finfo(float).eps))
    negative_fraction = float(np.sum(np.abs(y[y < -3 * noise])) / (np.sum(np.abs(y)) + np.finfo(float).eps))
    edge = max(1, y.size // 100)
    edge_ratio = float(max(np.max(np.abs(y[:edge])), np.max(np.abs(y[-edge:]))) / (np.max(np.abs(y)) + np.finfo(float).eps))
    if dynamic_snr < 20:
        warnings.append("谱图整体 S/N 偏低，弱峰和多重性判断可靠性有限。")
    if negative_fraction > 0.12:
        warnings.append("负峰面积偏高，建议复查相位与基线。")
    if edge_ratio > 0.85:
        warnings.append("谱窗边缘存在强信号，可能发生截谱或谱宽设置不足。")
    if len(signals) > 80:
        warnings.append("信号数很多，可能存在混合物、噪声误检或严重重叠。")
    snr_score = np.clip(25.0 * np.log10(max(dynamic_snr, 1.0)), 0.0, 55.0)
    phase_score = 30.0 * np.clip(1.0 - negative_fraction / 0.25, 0.0, 1.0)
    edge_score = 15.0 * np.clip(1.0 - edge_ratio, 0.0, 1.0)
    return float(np.clip(snr_score + phase_score + edge_score, 0.0, 100.0)), warnings


def analyze_spectrum(
    spectrum: Spectrum1D,
    config: AnalysisConfig | None = None,
    candidates: list[Candidate] | None = None,
    manual_peak_positions: Iterable[float] | None = None,
    manual_integrals: list[dict[str, float]] | None = None,
) -> AnalysisReport:
    config = config or AnalysisConfig()
    config.validate()
    peaks, noise = pick_peaks(spectrum, config, manual_peak_positions)
    signals = build_signals(spectrum, peaks, config)
    warnings: list[str] = []

    if config.identify_references:
        if reference_entries(spectrum.solvent, spectrum.nucleus):
            match_references(signals, spectrum.solvent, spectrum.nucleus)
        else:
            warnings.append(f"内置参考库暂不包含溶剂 {spectrum.solvent}，未进行残余溶剂/杂质匹配。")
    total_protons, integral_warnings = _normalize_integrals(signals, config)
    warnings.extend(integral_warnings)
    fragments = infer_fragments(signals, spectrum.nucleus)

    if candidates is None and config.include_demo_candidates:
        candidates = load_candidate_library()
    candidate_scores = rank_candidates(signals, candidates or [], config.molecular_formula)
    candidate_scores = candidate_scores[: config.candidate_limit]

    quality, quality_warnings = _quality_score(spectrum, signals, noise)
    warnings.extend(quality_warnings)
    if "1H" not in spectrum.nucleus.upper().replace("^", "") and spectrum.nucleus.upper() != "H1":
        warnings.append("当前多重性、积分归一和片段规则主要针对 1H；其他核种结果仅作寻峰参考。")
    if config.molecular_formula.strip():
        try:
            dbe = degree_of_unsaturation(config.molecular_formula)
            if dbe is not None and dbe < -0.01:
                warnings.append("输入分子式给出负不饱和度，请检查分子式或电荷。")
        except ValueError as exc:
            warnings.append(str(exc))
    if not signals:
        warnings.append("未检出超过阈值的正峰；请检查相位、谱图极性或降低 S/N 阈值。")

    parameters = asdict(config)
    parameters.update(
        {
            "detected_peaks": len(peaks),
            "grouped_signals": len(signals),
            "canonical_solvent": canonical_solvent(spectrum.solvent),
            "integral_total_protons": total_protons,
        }
    )
    return AnalysisReport(
        title=spectrum.title,
        nucleus=spectrum.nucleus,
        solvent=spectrum.solvent,
        spectrometer_mhz=spectrum.spectrometer_mhz,
        noise_sigma=noise,
        signals=signals,
        fragments=fragments,
        candidates=candidate_scores,
        warnings=warnings,
        parameters=parameters,
        quality_score=quality,
        manual_integrals=list(manual_integrals or []),
    )
