"""Tk dialogs for the local account preview."""

from __future__ import annotations

import tkinter as tk
from tkinter import messagebox, ttk
from typing import Callable

from .auth import AccountStore, AuthError, Session, UserAccount
from .i18n import Translator


class AccountWindow:
    def __init__(
        self,
        parent: tk.Misc,
        translator: Translator,
        store: AccountStore,
        current_user: UserAccount | None,
        on_session: Callable[[Session], None],
        on_password_changed: Callable[[], None] | None = None,
    ) -> None:
        self.tr = translator
        self.store = store
        self.current_user = current_user
        self.on_session = on_session
        self.on_password_changed = on_password_changed
        self.window = tk.Toplevel(parent)
        self.window.title(self.tr.t("account.title"))
        self.window.geometry("520x470")
        self.window.resizable(False, False)
        self.show_password_var = tk.BooleanVar(value=False)
        self.status_var = tk.StringVar(value=self._txt("账号数据仅保存在本机。", "Account data is stored only on this computer."))
        self._entries: list[ttk.Entry] = []
        self._build()

    def _txt(self, zh: str, en: str) -> str:
        return en if self.tr.language == "en_US" else zh

    def _build(self) -> None:
        notebook = ttk.Notebook(self.window)
        notebook.pack(fill=tk.BOTH, expand=True, padx=12, pady=12)
        login = ttk.Frame(notebook, padding=16)
        register = ttk.Frame(notebook, padding=16)
        password = ttk.Frame(notebook, padding=16)
        notebook.add(login, text=self._txt("登录", "Sign in"))
        notebook.add(register, text=self._txt("注册", "Register"))
        notebook.add(password, text=self._txt("密码", "Password"))
        self._build_login(login)
        self._build_register(register)
        self._build_password(password)
        ttk.Checkbutton(self.window, text=self._txt("显示密码", "Show passwords"), variable=self.show_password_var, command=self._toggle_passwords).pack(anchor=tk.W, padx=18)
        ttk.Label(self.window, textvariable=self.status_var, wraplength=480, foreground="#536273", padding=(12, 8)).pack(fill=tk.X)

    def _labeled_entry(self, parent: ttk.Frame, row: int, label: str, variable: tk.StringVar, *, password: bool = False) -> ttk.Entry:
        ttk.Label(parent, text=label).grid(row=row, column=0, sticky=tk.W, padx=4, pady=7)
        entry = ttk.Entry(parent, textvariable=variable, width=38, show="•" if password else "")
        entry.grid(row=row, column=1, sticky=tk.EW, padx=4, pady=7)
        if password:
            self._entries.append(entry)
        parent.columnconfigure(1, weight=1)
        return entry

    def _build_login(self, parent: ttk.Frame) -> None:
        self.login_user = tk.StringVar()
        self.login_password = tk.StringVar()
        first = self._labeled_entry(parent, 0, self._txt("用户名", "Username"), self.login_user)
        password = self._labeled_entry(parent, 1, self._txt("密码", "Password"), self.login_password, password=True)
        ttk.Button(parent, text=self._txt("登录", "Sign in"), command=self.login).grid(row=2, column=0, columnspan=2, sticky=tk.EW, padx=4, pady=12)
        first.focus_set()
        password.bind("<Return>", lambda _event: self.login())

    def _build_register(self, parent: ttk.Frame) -> None:
        self.register_user = tk.StringVar()
        self.register_email = tk.StringVar()
        self.register_password = tk.StringVar()
        self.register_confirm = tk.StringVar()
        self._labeled_entry(parent, 0, self._txt("用户名", "Username"), self.register_user)
        self._labeled_entry(parent, 1, self._txt("邮箱（可空）", "E-mail (optional)"), self.register_email)
        self._labeled_entry(parent, 2, self._txt("密码", "Password"), self.register_password, password=True)
        self._labeled_entry(parent, 3, self._txt("确认密码", "Confirm password"), self.register_confirm, password=True)
        ttk.Button(parent, text=self._txt("创建本地账号", "Create local account"), command=self.register).grid(row=4, column=0, columnspan=2, sticky=tk.EW, padx=4, pady=10)
        ttk.Label(parent, text=self._txt("至少 12 字符；短于 16 字符时需包含三类字符。首个账号为本机管理员。", "At least 12 characters; passwords shorter than 16 characters need three character classes. The first account is the local administrator."), wraplength=430, foreground="#536273").grid(row=5, column=0, columnspan=2, sticky=tk.W, padx=4)

    def _build_password(self, parent: ttk.Frame) -> None:
        if self.current_user is None:
            ttk.Label(parent, text=self._txt("登录后可修改密码。", "Sign in to change the password.")).pack(anchor=tk.W)
            return
        self.current_password = tk.StringVar()
        self.new_password = tk.StringVar()
        self.new_confirm = tk.StringVar()
        self._labeled_entry(parent, 0, self._txt("当前密码", "Current password"), self.current_password, password=True)
        self._labeled_entry(parent, 1, self._txt("新密码", "New password"), self.new_password, password=True)
        self._labeled_entry(parent, 2, self._txt("确认新密码", "Confirm new password"), self.new_confirm, password=True)
        ttk.Button(parent, text=self._txt("修改并注销其它会话", "Change and revoke sessions"), command=self.change_password).grid(row=3, column=0, columnspan=2, sticky=tk.EW, padx=4, pady=12)

    def _toggle_passwords(self) -> None:
        show = "" if self.show_password_var.get() else "•"
        for entry in self._entries:
            entry.configure(show=show)

    def login(self) -> None:
        result = self.store.authenticate(self.login_user.get(), self.login_password.get())
        self.login_password.set("")
        if not result.success or result.user is None:
            suffix = self._txt(f"；约 {result.retry_after_seconds} 秒后可重试", f"; retry in about {result.retry_after_seconds} seconds") if result.retry_after_seconds else ""
            messagebox.showerror(self.tr.t("account.title"), result.message + suffix, parent=self.window)
            return
        session = self.store.create_session(result.user.id)
        self.on_session(session)
        self.window.destroy()

    def register(self) -> None:
        if self.register_password.get() != self.register_confirm.get():
            messagebox.showerror(self.tr.t("account.title"), self._txt("两次密码不一致。", "Passwords do not match."), parent=self.window)
            return
        try:
            user = self.store.register(self.register_user.get(), self.register_password.get(), self.register_email.get())
            result = self.store.authenticate(user.username, self.register_password.get())
            if not result.success or result.user is None:
                raise AuthError(result.message)
            session = self.store.create_session(result.user.id)
        except AuthError as exc:
            messagebox.showerror(self.tr.t("account.title"), str(exc), parent=self.window)
            return
        self.on_session(session)
        self.window.destroy()

    def change_password(self) -> None:
        if self.current_user is None:
            return
        if self.new_password.get() != self.new_confirm.get():
            messagebox.showerror(self.tr.t("account.title"), self._txt("两次新密码不一致。", "New passwords do not match."), parent=self.window)
            return
        try:
            self.store.change_password(self.current_user.id, self.current_password.get(), self.new_password.get())
        except AuthError as exc:
            messagebox.showerror(self.tr.t("account.title"), str(exc), parent=self.window)
            return
        if self.on_password_changed:
            self.on_password_changed()
        messagebox.showinfo(self.tr.t("account.title"), self._txt("密码已修改；已有会话均已撤销，请重新登录。", "Password changed. Existing sessions were revoked; sign in again."), parent=self.window)
        self.window.destroy()

