"""Explainable, offline NMR prediction for the structure editor.

This module intentionally uses broad, auditable environment rules.  It is a
fast first-pass predictor for drawing/assignment workflows, not a substitute
for a trained quantum/ML predictor or an experimental spectrum.
"""

from __future__ import annotations

import csv
import json
import math
from collections.abc import Iterable
from dataclasses import asdict, dataclass
from pathlib import Path

import numpy as np

from .structure import HALOGENS, AtomNode, BondEdge, MoleculeGraph, StructureError

NUCLEI = ("1H", "13C", "31P", "19F")


@dataclass(slots=True)
class PredictionSignal:
    nucleus: str
    atom_ids: tuple[int, ...]
    shift_ppm: float
    integral: float
    multiplicity: str
    coupling_hz: tuple[float, ...]
    environment: str
    confidence: float
    uncertainty_ppm: float


@dataclass(slots=True)
class PredictionResult:
    nucleus: str
    solvent: str
    frequency_mhz: float
    formula: str
    canonical_smiles: str
    method: str
    signals: list[PredictionSignal]
    warnings: list[str]
    temperature_k: float = 298.15
    concentration_m: float | None = None
    model_version: str = "open-rule-v0.3"

    def to_dict(self) -> dict[str, object]:
        return {
            "nucleus": self.nucleus,
            "solvent": self.solvent,
            "frequency_mhz": self.frequency_mhz,
            "formula": self.formula,
            "canonical_smiles": self.canonical_smiles,
            "method": self.method,
            "temperature_k": self.temperature_k,
            "concentration_m": self.concentration_m,
            "model_version": self.model_version,
            "signals": [asdict(signal) for signal in self.signals],
            "warnings": self.warnings,
        }


@dataclass(slots=True)
class _SiteEstimate:
    atom_id: int
    shift: float
    integral: float
    multiplicity: str
    coupling_hz: tuple[float, ...]
    environment: str
    confidence: float
    uncertainty: float


def normalise_nucleus(value: str) -> str:
    text = value.strip().replace("^", "").replace(" ", "").upper()
    aliases = {"H1": "1H", "C13": "13C", "P31": "31P", "F19": "19F"}
    text = aliases.get(text, text)
    if text not in NUCLEI:
        raise ValueError(f"不支持核种 {value!r}；请选择 1H、13C、31P 或 19F。")
    return text


def predict_nmr(
    graph: MoleculeGraph,
    nucleus: str = "1H",
    *,
    solvent: str = "CDCl3",
    frequency_mhz: float = 400.0,
    temperature_k: float = 298.15,
    concentration_m: float | None = None,
) -> PredictionResult:
    """Predict a one-dimensional spectrum from an editable molecular graph."""

    nucleus = normalise_nucleus(nucleus)
    if frequency_mhz <= 0:
        raise ValueError("谱仪频率必须大于 0 MHz。")
    if not 150.0 <= float(temperature_k) <= 450.0:
        raise ValueError("温度需在 150-450 K 范围内。")
    if concentration_m is not None and not 0.0 < float(concentration_m) <= 20.0:
        raise ValueError("浓度需大于 0 且不超过 20 mol/L，或留空。")
    validation = graph.validate()
    if validation.errors:
        raise StructureError("；".join(validation.errors))

    labels = graph.environment_labels(radius=4)
    if nucleus == "1H":
        estimates = _predict_protons(graph, labels, solvent)
    elif nucleus == "13C":
        estimates = _predict_carbons(graph)
    elif nucleus == "19F":
        estimates = _predict_fluorines(graph, labels)
    else:
        estimates = _predict_phosphorus(graph, labels)

    signals = _merge_equivalent_sites(estimates, labels, nucleus)
    signals.sort(key=lambda item: item.shift_ppm, reverse=True)
    # The current rules are trained around ordinary room-temperature spectra.
    # Until a solvent/temperature-specific backend is selected, widen rather
    # than silently overstate the precision outside that region.
    context_penalty = min(abs(float(temperature_k) - 298.15) / 80.0, 1.5)
    if concentration_m is None:
        context_penalty += 0.10
    for signal in signals:
        signal.uncertainty_ppm *= 1.0 + 0.30 * context_penalty
        signal.confidence = float(max(10.0, signal.confidence - 8.0 * context_penalty))
    warnings = list(validation.warnings)
    warnings.append(
        "化学位移来自离线、可解释的环境增量规则；数值用于画板预览和初步指认，不是实验鉴定结论。"
    )
    if abs(float(temperature_k) - 298.15) > 10.0:
        warnings.append("当前规则以约 298 K 数据为中心；已因所填温度扩大不确定度，但未施加经验性全局位移。")
    if concentration_m is None:
        warnings.append("未提供浓度；氢键、聚集和交换相关信号的不确定度已适度放宽。")
    if nucleus == "1H":
        warnings.append(
            "未显式处理构象、氢键、快速交换及非对映异位氢；OH/NH 峰可能移动、展宽或消失。"
        )
        if any(
            graph.attached_hydrogens(atom.id) == 2
            for atom in graph.atoms.values()
            if atom.element == "C"
        ):
            warnings.append(
                "CH2 中的两个 H 默认合并；手性/刚性环境下可能成为 AB 或两组非对映异位信号。"
            )
    elif nucleus == "13C":
        warnings.append(
            "13C 默认按宽带质子去耦谱显示；“CH3/CH2/CH/Cq”是碳类型，不是实测裂分。"
        )
    elif nucleus == "19F":
        warnings.append(
            "19F 位移对取代、溶剂与构象非常敏感；经验范围较宽，尤其是 P–F/S–F 和多氟体系。"
        )
    elif nucleus == "31P":
        warnings.append(
            "31P 位移强烈依赖氧化态、配位、pH 与质子化；金属配合物和超价磷需用专门方法复核。"
        )
    if not signals:
        element = {"1H": "可观测 H", "13C": "C", "19F": "F", "31P": "P"}[nucleus]
        warnings.append(f"当前结构中没有可生成 {nucleus} 信号的 {element} 位点。")

    try:
        smiles = graph.to_smiles()
    except StructureError:
        smiles = ""
    return PredictionResult(
        nucleus=nucleus,
        solvent=solvent.strip() or "unspecified",
        frequency_mhz=float(frequency_mhz),
        formula=graph.formula(),
        canonical_smiles=smiles,
        method="Open NMR Workbench 0.3 可解释环境增量模型",
        signals=signals,
        warnings=_unique(warnings),
        temperature_k=float(temperature_k),
        concentration_m=float(concentration_m) if concentration_m is not None else None,
        model_version="open-rule-v0.3",
    )


def _predict_protons(
    graph: MoleculeGraph, labels: dict[int, str], solvent: str
) -> list[_SiteEstimate]:
    estimates: list[_SiteEstimate] = []
    exchange_solvent = solvent.lower().replace(" ", "") in {
        "d2o",
        "cd3od",
        "meod",
        "methanol-d4",
    }
    for atom in graph.atoms.values():
        if atom.element == "H":
            continue
        count = graph.attached_hydrogens(atom.id)
        if count <= 0:
            continue
        shift, environment, confidence, uncertainty = _proton_shift(graph, atom)
        multiplicity, coupling = _proton_multiplicity(graph, atom.id, labels)
        if atom.element in {"O", "N", "S"}:
            multiplicity = "br s"
            coupling = ()
            if exchange_solvent:
                environment += "；在该溶剂中可能交换消失"
                confidence -= 12
        estimates.append(
            _SiteEstimate(
                atom.id,
                shift,
                float(count),
                multiplicity,
                coupling,
                environment,
                confidence,
                uncertainty,
            )
        )
    return estimates


def _proton_shift(
    graph: MoleculeGraph, atom: AtomNode
) -> tuple[float, str, float, float]:
    element = atom.element
    if element == "O":
        neighbours = _heavy_neighbours(graph, atom.id)
        if any(
            _carbonyl_kind(graph, neighbour.id)
            for neighbour, _ in neighbours
            if neighbour.element == "C"
        ):
            return 11.2, "羧酸/强氢键 O–H", 42.0, 2.0
        if any(_is_aromatic(graph, neighbour.id) for neighbour, _ in neighbours):
            return 5.2, "酚羟基 O–H（交换性）", 38.0, 2.0
        return 2.4, "醇 O–H（交换性）", 35.0, 2.0
    if element == "N":
        attached_to_carbonyl = any(
            neighbour.element == "C" and _carbonyl_kind(graph, neighbour.id)
            for neighbour, _ in _heavy_neighbours(graph, atom.id)
        )
        if attached_to_carbonyl:
            return 7.2, "酰胺 N–H（交换性）", 45.0, 1.5
        if _is_aromatic(graph, atom.id):
            return 8.8, "芳香 N–H（交换性）", 40.0, 2.0
        return 2.8, "胺 N–H（交换性）", 38.0, 1.8
    if element == "S":
        return 1.8, "硫醇 S–H（交换性）", 35.0, 1.5
    if element == "P":
        return 5.0, "P–H", 38.0, 1.5

    # Carbon-bound proton environments.
    carbonyl = _carbonyl_kind(graph, atom.id)
    if carbonyl in {"aldehyde"}:
        return 9.75, "醛基 CHO", 74.0, 0.35
    if _is_aromatic(graph, atom.id):
        shift = 7.15 + _aromatic_substituent_correction(
            graph, atom.id, for_carbon=False
        )
        return _clamp(shift, 5.8, 9.2), "芳香 C–H", 67.0, 0.45
    if _has_order(graph, atom.id, 3.0):
        return 2.45, "端炔 C≡C–H", 62.0, 0.45
    if _has_order(graph, atom.id, 2.0):
        shift = 5.25
        if any(
            neighbour.element in {"O", "N", "S", "F", "Cl", "Br"}
            for neighbour, _ in _heavy_neighbours(graph, atom.id)
        ):
            shift += 0.9
        return shift, "烯烃 C=C–H", 61.0, 0.65

    hydrogens = graph.attached_hydrogens(atom.id)
    shift = {3: 0.90, 2: 1.28, 1: 1.58}.get(hydrogens, 1.1)
    descriptors: list[str] = [{3: "CH3", 2: "CH2", 1: "CH"}.get(hydrogens, "C–H")]
    direct_corrections = {
        "O": 2.45,
        "N": 1.70,
        "S": 1.30,
        "F": 3.55,
        "Cl": 2.45,
        "Br": 2.25,
        "I": 1.75,
        "P": 0.55,
    }
    for neighbour, _ in _heavy_neighbours(graph, atom.id):
        if neighbour.element in direct_corrections:
            shift += direct_corrections[neighbour.element]
            descriptors.append(f"连 {neighbour.element}")
        if neighbour.element == "C":
            kind = _carbonyl_kind(graph, neighbour.id)
            if kind:
                shift += 1.20
                descriptors.append("羰基 α 位")
            elif _is_aromatic(graph, neighbour.id):
                shift += 1.25
                descriptors.append("苄位")
            elif _has_order(graph, neighbour.id, 2.0):
                shift += 0.75
                descriptors.append("烯丙位")
            elif _has_order(graph, neighbour.id, 3.0):
                shift += 1.00
                descriptors.append("炔丙位")
    return _clamp(shift, -0.5, 6.0), "、".join(_unique(descriptors)), 70.0, 0.32


def _proton_multiplicity(
    graph: MoleculeGraph,
    atom_id: int,
    labels: dict[int, str],
) -> tuple[str, tuple[float, ...]]:
    atom = graph.atom(atom_id)
    if atom.element in {"O", "N", "S"}:
        return "br s", ()
    groups: dict[tuple[str, float], int] = {}
    for neighbour, bond in graph.neighbours(atom_id):
        if neighbour.element == "H" or labels.get(neighbour.id) == labels.get(atom_id):
            continue
        count = graph.attached_hydrogens(neighbour.id)
        j_value = _coupling_for_pair(graph, atom_id, neighbour.id, bond)
        if neighbour.element == "F":
            count = 1
            j_value = 47.0
        elif neighbour.element == "P":
            count = 1
            j_value = 10.0
        elif neighbour.element not in {"C", "F", "P"}:
            continue
        if count:
            key = (labels.get(neighbour.id, str(neighbour.id)), j_value)
            groups[key] = groups.get(key, 0) + count
    if not groups:
        return "s", ()
    ordered = sorted(
        ((count, key[1]) for key, count in groups.items()),
        key=lambda item: item[1],
        reverse=True,
    )
    couplings = tuple(round(j, 1) for _, j in ordered)
    if len(ordered) == 1:
        return _n_plus_one(ordered[0][0]), couplings
    if len(ordered) == 2 and all(1 <= count <= 3 for count, _ in ordered):
        code = "".join(_n_plus_one(count) for count, _ in ordered)
        return code if len(code) <= 3 else "m", couplings
    return "m", couplings


def _coupling_for_pair(
    graph: MoleculeGraph, atom1: int, atom2: int, bond: BondEdge
) -> float:
    if math.isclose(bond.order, 2.0):
        return 12.0
    if _is_aromatic(graph, atom1) and _is_aromatic(graph, atom2):
        return 7.8
    if math.isclose(bond.order, 3.0):
        return 2.5
    return 7.0


def _predict_carbons(graph: MoleculeGraph) -> list[_SiteEstimate]:
    estimates: list[_SiteEstimate] = []
    for atom in graph.atoms.values():
        if atom.element != "C":
            continue
        hydrogens = graph.attached_hydrogens(atom.id)
        carbon_type = {3: "CH3", 2: "CH2", 1: "CH", 0: "Cq"}.get(hydrogens, "C")
        kind = _carbonyl_kind(graph, atom.id)
        if kind:
            table = {
                "aldehyde": (200.0, "醛羰基", 8.0),
                "ketone": (205.0, "酮羰基", 10.0),
                "acid": (178.0, "羧酸羰基", 6.0),
                "ester": (172.5, "酯/碳酸酯羰基", 6.0),
                "amide": (169.0, "酰胺/脲羰基", 7.0),
                "acyl_halide": (172.0, "酰卤羰基", 8.0),
                "thioester": (190.0, "硫代羰基相邻环境", 10.0),
            }
            shift, environment, uncertainty = table[kind]
            confidence = 72.0
        elif _is_nitrile_carbon(graph, atom.id):
            shift, environment, uncertainty, confidence = 118.0, "腈 C≡N", 7.0, 65.0
        elif _is_aromatic(graph, atom.id):
            shift = 128.0 + _aromatic_substituent_correction(
                graph, atom.id, for_carbon=True
            )
            shift, environment, uncertainty, confidence = (
                _clamp(shift, 95.0, 170.0),
                f"芳香 {carbon_type}",
                7.0,
                66.0,
            )
        elif _has_order(graph, atom.id, 3.0):
            shift = 75.0 if hydrogens else 84.0
            environment, uncertainty, confidence = f"炔碳 {carbon_type}", 7.0, 63.0
        elif _has_order(graph, atom.id, 2.0):
            heavy_degree = len(_heavy_neighbours(graph, atom.id))
            shift = 112.0 + 7.0 * max(0, heavy_degree - 1)
            if any(
                neighbour.element in {"O", "N", "S", "F", "Cl"}
                for neighbour, _ in _heavy_neighbours(graph, atom.id)
            ):
                shift += 22.0
            shift, environment, uncertainty, confidence = (
                _clamp(shift, 85.0, 170.0),
                f"烯烃 {carbon_type}",
                9.0,
                58.0,
            )
        else:
            shift = {3: 14.0, 2: 25.0, 1: 35.0, 0: 40.0}.get(hydrogens, 25.0)
            descriptors = [f"脂肪族 {carbon_type}"]
            direct = {
                "O": 38.0,
                "N": 24.0,
                "S": 18.0,
                "F": 65.0,
                "Cl": 35.0,
                "Br": 25.0,
                "I": 7.0,
                "P": 10.0,
            }
            for neighbour, _ in _heavy_neighbours(graph, atom.id):
                if neighbour.element in direct:
                    shift += direct[neighbour.element]
                    descriptors.append(f"连 {neighbour.element}")
                elif neighbour.element == "C":
                    if _carbonyl_kind(graph, neighbour.id):
                        shift += 15.0
                        descriptors.append("羰基 α 位")
                    elif _is_aromatic(graph, neighbour.id):
                        shift += 5.0
                        descriptors.append("苄位")
                    elif _has_order(graph, neighbour.id, 2.0):
                        shift += 5.0
                        descriptors.append("烯丙位")
            shift, environment, uncertainty, confidence = (
                _clamp(shift, -10.0, 120.0),
                "、".join(_unique(descriptors)),
                6.0,
                69.0,
            )
        estimates.append(
            _SiteEstimate(
                atom.id,
                shift,
                1.0,
                carbon_type,
                (),
                environment,
                confidence,
                uncertainty,
            )
        )
    return estimates


def _predict_fluorines(
    graph: MoleculeGraph, labels: dict[int, str]
) -> list[_SiteEstimate]:
    estimates: list[_SiteEstimate] = []
    for atom in graph.atoms.values():
        if atom.element != "F":
            continue
        neighbours = _heavy_neighbours(graph, atom.id)
        if not neighbours:
            estimates.append(
                _SiteEstimate(atom.id, -150.0, 1.0, "s", (), "未连接 F", 20.0, 40.0)
            )
            continue
        parent, _ = neighbours[0]
        if parent.element == "C" and _carbonyl_kind(graph, parent.id):
            shift, environment, uncertainty, confidence = 25.0, "酰氟 F", 18.0, 48.0
        elif parent.element == "C" and _is_aromatic(graph, parent.id):
            shift = -113.0 - 3.0 * _aromatic_substituent_correction(
                graph, parent.id, for_carbon=False
            )
            shift, environment, uncertainty, confidence = (
                _clamp(shift, -175.0, -90.0),
                "芳基 F",
                14.0,
                54.0,
            )
        elif parent.element == "C":
            fluorines = sum(
                1
                for neighbour, _ in graph.neighbours(parent.id)
                if neighbour.element == "F"
            )
            if fluorines >= 3:
                shift, environment, uncertainty, confidence = (
                    -72.0,
                    "脂肪族 CF3",
                    12.0,
                    58.0,
                )
            elif fluorines == 2:
                shift, environment, uncertainty, confidence = (
                    -118.0,
                    "脂肪族 CF2",
                    18.0,
                    50.0,
                )
            else:
                shift, environment, uncertainty, confidence = (
                    -190.0,
                    "脂肪族 C–F",
                    25.0,
                    43.0,
                )
        elif parent.element == "P":
            shift, environment, uncertainty, confidence = -70.0, "P–F", 35.0, 30.0
        elif parent.element == "S":
            shift, environment, uncertainty, confidence = 45.0, "S–F", 45.0, 25.0
        else:
            shift, environment, uncertainty, confidence = (
                -150.0,
                f"{parent.element}–F",
                35.0,
                25.0,
            )

        h_count = sum(
            graph.attached_hydrogens(neighbour.id)
            for neighbour, _ in graph.neighbours(parent.id)
            if neighbour.element == "C"
        )
        multiplicity = (
            _n_plus_one(h_count) if 0 < h_count <= 6 else ("m" if h_count else "s")
        )
        coupling = (
            (
                round(
                    8.0
                    if parent.element == "C" and _is_aromatic(graph, parent.id)
                    else 47.0,
                    1,
                ),
            )
            if h_count
            else ()
        )
        estimates.append(
            _SiteEstimate(
                atom.id,
                shift,
                1.0,
                multiplicity,
                coupling,
                environment,
                confidence,
                uncertainty,
            )
        )
    return estimates


def _predict_phosphorus(
    graph: MoleculeGraph, labels: dict[int, str]
) -> list[_SiteEstimate]:
    estimates: list[_SiteEstimate] = []
    for atom in graph.atoms.values():
        if atom.element != "P":
            continue
        neighbours = _heavy_neighbours(graph, atom.id)
        double_o = any(
            neighbour.element == "O" and math.isclose(bond.order, 2.0)
            for neighbour, bond in neighbours
        )
        double_s = any(
            neighbour.element == "S" and math.isclose(bond.order, 2.0)
            for neighbour, bond in neighbours
        )
        single_o = sum(
            1
            for neighbour, bond in neighbours
            if neighbour.element == "O" and math.isclose(bond.order, 1.0)
        )
        carbon = sum(1 for neighbour, _ in neighbours if neighbour.element == "C")
        fluorine = sum(1 for neighbour, _ in neighbours if neighbour.element == "F")
        aromatic_carbon = sum(
            1
            for neighbour, _ in neighbours
            if neighbour.element == "C" and _is_aromatic(graph, neighbour.id)
        )
        if fluorine:
            shift, environment, uncertainty, confidence = (
                -35.0 - 12.0 * fluorine,
                "含 P–F 的磷中心",
                40.0,
                28.0,
            )
        elif double_o:
            if single_o >= 3:
                shift, environment, uncertainty, confidence = (
                    -1.0,
                    "磷酸酯/磷酸盐 P(V)",
                    12.0,
                    55.0,
                )
            elif single_o == 2:
                shift, environment, uncertainty, confidence = (
                    20.0,
                    "膦酸酯 P(V)",
                    14.0,
                    53.0,
                )
            elif single_o == 1:
                shift, environment, uncertainty, confidence = (
                    35.0,
                    "次膦酸酯/膦氧 P(V)",
                    16.0,
                    50.0,
                )
            else:
                shift, environment, uncertainty, confidence = (
                    30.0 + 2.0 * aromatic_carbon,
                    "氧化膦 P(V)",
                    17.0,
                    50.0,
                )
        elif double_s:
            shift, environment, uncertainty, confidence = (
                55.0,
                "硫代磷酰 P(V)",
                25.0,
                38.0,
            )
        elif single_o >= 3:
            shift, environment, uncertainty, confidence = (
                138.0,
                "亚磷酸酯 P(III)",
                18.0,
                48.0,
            )
        elif carbon >= 3:
            shift = -6.0 if aromatic_carbon >= 2 else -30.0
            environment = "芳基膦 P(III)" if aromatic_carbon >= 2 else "烷基膦 P(III)"
            uncertainty, confidence = 20.0, 46.0
        else:
            shift, environment, uncertainty, confidence = (
                20.0,
                "未分类磷中心",
                35.0,
                25.0,
            )

        p_h = graph.attached_hydrogens(atom.id)
        if fluorine:
            multiplicity = _n_plus_one(fluorine)
            coupling = (700.0,)
        elif p_h:
            multiplicity = _n_plus_one(p_h)
            coupling = (500.0,)
        else:
            multiplicity, coupling = "s", ()
        estimates.append(
            _SiteEstimate(
                atom.id,
                shift,
                1.0,
                multiplicity,
                coupling,
                environment,
                confidence,
                uncertainty,
            )
        )
    return estimates


def _merge_equivalent_sites(
    estimates: Iterable[_SiteEstimate],
    labels: dict[int, str],
    nucleus: str,
) -> list[PredictionSignal]:
    grouped: dict[str, list[_SiteEstimate]] = {}
    for estimate in estimates:
        grouped.setdefault(
            labels.get(estimate.atom_id, str(estimate.atom_id)), []
        ).append(estimate)
    results: list[PredictionSignal] = []
    for group in grouped.values():
        total = sum(item.integral for item in group)
        weights = [max(item.integral, 1e-9) for item in group]
        shift = sum(item.shift * weight for item, weight in zip(group, weights)) / sum(
            weights
        )
        representative = group[0]
        environments = _unique(item.environment for item in group)
        results.append(
            PredictionSignal(
                nucleus=nucleus,
                atom_ids=tuple(sorted(item.atom_id for item in group)),
                shift_ppm=round(shift, 3),
                integral=round(total, 3),
                multiplicity=representative.multiplicity,
                coupling_hz=representative.coupling_hz,
                environment=" / ".join(environments),
                confidence=round(min(item.confidence for item in group), 1),
                uncertainty_ppm=round(max(item.uncertainty for item in group), 3),
            )
        )
    return results


def spectrum_limits(nucleus: str) -> tuple[float, float]:
    """Return conventional displayed high-ppm and low-ppm limits."""

    return {
        "1H": (12.5, -1.0),
        "13C": (230.0, -10.0),
        "19F": (50.0, -250.0),
        "31P": (220.0, -250.0),
    }[normalise_nucleus(nucleus)]


def simulate_prediction_spectrum(
    result: PredictionResult,
    *,
    points: int = 8192,
    line_width_ppm: float | None = None,
) -> tuple[np.ndarray, np.ndarray]:
    """Create a display-only Lorentzian trace from predicted signals."""

    high, low = spectrum_limits(result.nucleus)
    ppm = np.linspace(low, high, max(1024, int(points)))
    defaults = {"1H": 0.012, "13C": 0.12, "19F": 0.08, "31P": 0.10}
    width = float(line_width_ppm or defaults[result.nucleus])
    gamma = max(width / 2.0, np.finfo(float).eps)
    intensity = np.zeros_like(ppm)
    for signal in result.signals:
        pattern = _multiplet_pattern(signal.multiplicity, signal.coupling_hz)
        weight_sum = sum(weight for _, weight in pattern) or 1.0
        for offset_hz, weight in pattern:
            center = signal.shift_ppm + offset_hz / result.frequency_mhz
            amplitude = max(signal.integral, 0.2) * weight / weight_sum
            intensity += amplitude * gamma**2 / ((ppm - center) ** 2 + gamma**2)
    if intensity.size and np.max(intensity) > 0:
        intensity /= float(np.max(intensity))
    return ppm, intensity


def write_prediction(result: PredictionResult, path: str | Path) -> Path:
    target = Path(path)
    if target.suffix.lower() == ".csv":
        with target.open("w", encoding="utf-8-sig", newline="") as handle:
            writer = csv.writer(handle)
            writer.writerow(
                (
                    "nucleus",
                    "atom_ids",
                    "shift_ppm",
                    "uncertainty_ppm",
                    "integral",
                    "multiplicity",
                    "coupling_hz",
                    "environment",
                    "confidence",
                )
            )
            for signal in result.signals:
                writer.writerow(
                    (
                        signal.nucleus,
                        ";".join(map(str, signal.atom_ids)),
                        signal.shift_ppm,
                        signal.uncertainty_ppm,
                        signal.integral,
                        signal.multiplicity,
                        ";".join(f"{value:g}" for value in signal.coupling_hz),
                        signal.environment,
                        signal.confidence,
                    )
                )
    else:
        target.write_text(
            json.dumps(result.to_dict(), ensure_ascii=False, indent=2), encoding="utf-8"
        )
    return target


def _multiplet_pattern(
    multiplicity: str, couplings: tuple[float, ...]
) -> list[tuple[float, float]]:
    text = multiplicity.lower().replace("br ", "")
    n_map = {"s": 0, "d": 1, "t": 2, "q": 3, "quint": 4, "sext": 5, "sept": 6}
    if text in n_map:
        n = n_map[text]
        j = couplings[0] if couplings else 7.0
        return _pascal_pattern(n, j)
    if text in {"dd", "dt", "dq", "td", "tt"}:
        first, second = text[0], text[1]
        j1 = couplings[0] if couplings else 7.0
        j2 = couplings[1] if len(couplings) > 1 else max(1.5, j1 / 3.0)
        combined: list[tuple[float, float]] = []
        for offset1, weight1 in _pascal_pattern(n_map[first], j1):
            for offset2, weight2 in _pascal_pattern(n_map[second], j2):
                combined.append((offset1 + offset2, weight1 * weight2))
        return combined
    if text == "m":
        j = couplings[0] if couplings else 7.0
        return [(-j, 0.35), (-j / 2.0, 0.75), (0.0, 1.0), (j / 2.0, 0.75), (j, 0.35)]
    return [(0.0, 1.0)]


def _pascal_pattern(n: int, j: float) -> list[tuple[float, float]]:
    if n <= 0:
        return [(0.0, 1.0)]
    weights = [float(math.comb(n, index)) for index in range(n + 1)]
    center = n / 2.0
    return [((index - center) * j, weight) for index, weight in enumerate(weights)]


def _carbonyl_kind(graph: MoleculeGraph, atom_id: int) -> str | None:
    atom = graph.atom(atom_id)
    if atom.element != "C":
        return None
    double_hetero = [
        neighbour
        for neighbour, bond in graph.neighbours(atom_id)
        if math.isclose(bond.order, 2.0) and neighbour.element in {"O", "S"}
    ]
    if not double_hetero:
        return None
    single = [
        (neighbour, bond)
        for neighbour, bond in graph.neighbours(atom_id)
        if math.isclose(bond.order, 1.0)
    ]
    if any(neighbour.element == "N" for neighbour, _ in single):
        return "amide"
    if any(neighbour.element == "O" for neighbour, _ in single):
        oxygen = next(neighbour for neighbour, _ in single if neighbour.element == "O")
        return "acid" if graph.attached_hydrogens(oxygen.id) else "ester"
    if any(neighbour.element == "S" for neighbour, _ in single):
        return "thioester"
    if any(neighbour.element in HALOGENS for neighbour, _ in single):
        return "acyl_halide"
    return "aldehyde" if graph.attached_hydrogens(atom_id) else "ketone"


def _is_nitrile_carbon(graph: MoleculeGraph, atom_id: int) -> bool:
    return any(
        neighbour.element == "N" and math.isclose(bond.order, 3.0)
        for neighbour, bond in graph.neighbours(atom_id)
    )


def _is_aromatic(graph: MoleculeGraph, atom_id: int) -> bool:
    atom = graph.atom(atom_id)
    return atom.aromatic or any(
        math.isclose(bond.order, 1.5) for _, bond in graph.neighbours(atom_id)
    )


def _has_order(graph: MoleculeGraph, atom_id: int, order: float) -> bool:
    return any(math.isclose(bond.order, order) for _, bond in graph.neighbours(atom_id))


def _heavy_neighbours(
    graph: MoleculeGraph, atom_id: int
) -> list[tuple[AtomNode, BondEdge]]:
    return [
        (atom, bond) for atom, bond in graph.neighbours(atom_id) if atom.element != "H"
    ]


def _aromatic_substituent_correction(
    graph: MoleculeGraph, atom_id: int, *, for_carbon: bool
) -> float:
    correction = 0.0
    table = {
        "O": 27.0 if for_carbon else -0.35,
        "N": 20.0 if for_carbon else -0.20,
        "F": 34.0 if for_carbon else 0.15,
        "Cl": 7.0 if for_carbon else 0.20,
        "Br": 5.0 if for_carbon else 0.20,
        "I": 1.0 if for_carbon else 0.15,
        "S": 10.0 if for_carbon else 0.10,
        "P": 8.0 if for_carbon else 0.15,
    }
    for neighbour, _ in _heavy_neighbours(graph, atom_id):
        if _is_aromatic(graph, neighbour.id) and neighbour.element != "C":
            # Ring heteroatoms dominate alpha positions (e.g. pyridines).
            if for_carbon:
                correction += {"N": 20.0, "O": 12.0, "S": 8.0}.get(
                    neighbour.element, 5.0
                )
            else:
                correction += {"N": 1.05, "O": 0.55, "S": 0.35}.get(
                    neighbour.element, 0.2
                )
        elif not _is_aromatic(graph, neighbour.id):
            correction += table.get(
                neighbour.element,
                10.0 if for_carbon and neighbour.element == "C" else 0.15,
            )
    # Smaller ortho/meta effects from substituents one ring bond away.
    ortho_carbon = {
        "O": -13.0,
        "N": -8.0,
        "F": -13.0,
        "Cl": -3.0,
        "Br": -3.0,
        "I": -1.0,
        "S": -4.0,
        "P": -1.0,
        "C": -2.0,
    }
    ortho_proton = {
        "O": -0.35,
        "N": -0.20,
        "F": -0.12,
        "Cl": 0.10,
        "Br": 0.12,
        "I": 0.15,
        "S": 0.05,
        "P": 0.12,
        "C": 0.05,
    }
    for ring_neighbour, _ in _heavy_neighbours(graph, atom_id):
        if not _is_aromatic(graph, ring_neighbour.id):
            continue
        for substituent, _ in _heavy_neighbours(graph, ring_neighbour.id):
            if substituent.id == atom_id or _is_aromatic(graph, substituent.id):
                continue
            if for_carbon:
                correction += ortho_carbon.get(substituent.element, -1.0)
            else:
                correction += ortho_proton.get(substituent.element, 0.05)
    return correction


def _n_plus_one(neighbour_hydrogens: int) -> str:
    return {0: "s", 1: "d", 2: "t", 3: "q", 4: "quint", 5: "sext", 6: "sept"}.get(
        neighbour_hydrogens, "m"
    )


def _clamp(value: float, minimum: float, maximum: float) -> float:
    return min(maximum, max(minimum, value))


def _unique(values: Iterable[str]) -> list[str]:
    return list(dict.fromkeys(values))
