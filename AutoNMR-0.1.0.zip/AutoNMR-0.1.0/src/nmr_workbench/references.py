from __future__ import annotations

import json
from dataclasses import dataclass
from importlib.resources import files
from typing import Iterable

import numpy as np

from .models import ReferenceMatch, Signal
from .solvents import canonical_solvent_id, get_solvent


@dataclass(slots=True)
class ReferenceEntry:
    name: str
    category: str
    shifts: list[float]
    multiplicities: list[str]
    tolerance: float


def load_reference_data() -> dict:
    resource = files("nmr_workbench").joinpath("data/reference_shifts.json")
    return json.loads(resource.read_text(encoding="utf-8"))


def canonical_solvent(solvent: str, data: dict | None = None) -> str:
    database = data or load_reference_data()
    stripped = canonical_solvent_id(solvent)
    if stripped in database["solvents"]:
        return stripped
    return database.get("aliases", {}).get(stripped.casefold(), stripped)


def reference_entries(solvent: str, nucleus: str = "1H") -> list[ReferenceEntry]:
    data = load_reference_data()
    canonical = canonical_solvent(solvent, data)
    normalized_nucleus = nucleus.strip().replace("^", "").upper()
    normalized_nucleus = {"H1": "1H", "C13": "13C", "P31": "31P", "F19": "19F"}.get(
        normalized_nucleus, normalized_nucleus
    )
    entries: list[ReferenceEntry] = []
    source_items = [
        item
        for item in data["solvents"].get(canonical, [])
        if item.get("nucleus", "1H").replace("^", "").upper() == normalized_nucleus
    ]
    for item in source_items:
        entries.append(
            ReferenceEntry(
                name=item["name"],
                category=item["category"],
                shifts=[float(v) for v in item["shifts"]],
                multiplicities=list(item.get("multiplicities", [])),
                tolerance=float(item.get("tolerance", 0.04)),
            )
        )
    solvent_record = get_solvent(canonical)
    if solvent_record is not None:
        categories = {entry.category for entry in entries}
        residual = solvent_record.residual.get(normalized_nucleus, ())
        # In D2O the observed HOD signal is both the residual-proton signal and
        # the water signal.  Keep one reference entry so the same experimental
        # signal is not reported twice under two labels.
        duplicates_water = (
            normalized_nucleus == "1H"
            and "water" in categories
            and solvent_record.water_1h
            and all(
                any(abs(item.shift - water.shift) <= 0.01 for water in solvent_record.water_1h)
                for item in residual
            )
        )
        if residual and "residual solvent" not in categories and not duplicates_water:
            entries.insert(
                0,
                ReferenceEntry(
                    name=f"{solvent_record.id} residual",
                    category="residual solvent",
                    shifts=[item.shift for item in residual],
                    multiplicities=[item.multiplicity for item in residual],
                    tolerance=0.035 if normalized_nucleus == "1H" else 0.12,
                ),
            )
        if normalized_nucleus == "1H" and solvent_record.water_1h and "water" not in categories:
            entries.append(
                ReferenceEntry(
                    name="water / HOD",
                    category="water",
                    shifts=[item.shift for item in solvent_record.water_1h],
                    multiplicities=[item.multiplicity for item in solvent_record.water_1h],
                    tolerance=0.22,
                )
            )
    return entries


def _observed_positions(signals: Iterable[Signal]) -> tuple[np.ndarray, list[int]]:
    positions: list[float] = []
    owners: list[int] = []
    for signal_index, signal in enumerate(signals):
        positions.append(signal.center_ppm)
        owners.append(signal_index)
        for peak in signal.peaks:
            positions.append(peak.position_ppm)
            owners.append(signal_index)
    return np.asarray(positions, dtype=float), owners


def match_references(
    signals: list[Signal],
    solvent: str,
    nucleus: str = "1H",
    minimum_fraction: float = 0.60,
) -> list[ReferenceMatch]:
    positions, owners = _observed_positions(signals)
    if positions.size == 0:
        return []
    results: list[ReferenceMatch] = []
    for entry in reference_entries(solvent, nucleus):
        matched: list[float] = []
        matched_owners: list[int] = []
        errors: list[float] = []
        used: set[int] = set()
        for expected in entry.shifts:
            distances = np.abs(positions - expected)
            for idx in np.argsort(distances):
                owner = owners[int(idx)]
                if owner in used:
                    continue
                if distances[int(idx)] <= entry.tolerance:
                    matched.append(float(positions[int(idx)]))
                    matched_owners.append(owner)
                    errors.append(float(distances[int(idx)]))
                    used.add(owner)
                break
        fraction = len(matched) / max(len(entry.shifts), 1)
        required_fraction = 1.0 if len(entry.shifts) <= 2 else minimum_fraction
        if fraction < required_fraction:
            continue
        closeness = 1.0 - np.mean(errors) / max(entry.tolerance, 1e-9)
        score = float(np.clip(100.0 * (0.65 * fraction + 0.35 * closeness), 0.0, 100.0))
        result = ReferenceMatch(
            name=entry.name,
            category=entry.category,
            matched_shifts=matched,
            expected_shifts=entry.shifts,
            score=score,
            note="筛查匹配；位移随温度、浓度和含水量变化",
        )
        results.append(result)
        for owner in matched_owners:
            current = signals[owner].reference_match
            if current is None or result.score > current.score:
                signals[owner].reference_match = result
    return sorted(results, key=lambda item: item.score, reverse=True)
