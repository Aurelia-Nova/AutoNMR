"""Open NMR Workbench.

The public API intentionally stays small.  The desktop UI, command-line
interface and tests all use the same processing and interpretation kernel.
"""

__version__ = "0.1.0"

from .analysis import AnalysisConfig, analyze_spectrum
from .models import FID1D, AnalysisReport, Peak, Signal, Spectrum1D
from .prediction import PredictionResult, PredictionSignal, predict_nmr
from .processing import ProcessingConfig, process_fid
from .structure import AtomNode, BondEdge, MoleculeGraph, StructureError

__all__ = [
    "AnalysisConfig",
    "AnalysisReport",
    "AtomNode",
    "BondEdge",
    "FID1D",
    "MoleculeGraph",
    "Peak",
    "PredictionResult",
    "PredictionSignal",
    "ProcessingConfig",
    "Signal",
    "Spectrum1D",
    "StructureError",
    "analyze_spectrum",
    "predict_nmr",
    "process_fid",
]
