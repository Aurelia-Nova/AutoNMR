"""Per-user storage locations used by the desktop application.

Keeping mutable state outside the installation directory makes editable installs,
frozen builds, and a later client/server edition share the same application core.
"""

from __future__ import annotations

import os
import sys
from pathlib import Path


APP_DIRECTORY = "OpenNMRWorkbench"


def user_data_dir(*, create: bool = True) -> Path:
    override = os.environ.get("OPEN_NMR_WORKBENCH_DATA_DIR", "").strip()
    if override:
        target = Path(override).expanduser()
    elif sys.platform == "win32":
        base = os.environ.get("LOCALAPPDATA") or os.environ.get("APPDATA")
        target = Path(base) / APP_DIRECTORY if base else Path.home() / APP_DIRECTORY
    elif sys.platform == "darwin":
        target = Path.home() / "Library" / "Application Support" / APP_DIRECTORY
    else:
        base = os.environ.get("XDG_DATA_HOME", "").strip()
        target = (Path(base) if base else Path.home() / ".local" / "share") / "open-nmr-workbench"
    if create:
        target.mkdir(parents=True, exist_ok=True)
        try:
            target.chmod(0o700)
        except OSError:
            pass
    return target


def settings_path() -> Path:
    return user_data_dir() / "settings.json"


def accounts_path() -> Path:
    return user_data_dir() / "accounts.sqlite3"


def database_profiles_path() -> Path:
    return user_data_dir() / "database_profiles.json"

