"""Small, serialisable molecular graph used by the structure editor.

The editor deliberately owns a lightweight graph rather than exposing RDKit
objects to Tkinter.  This keeps undo/redo and project files stable, while RDKit
is used at the boundary for SMILES/MOL conversion and sanitisation.
"""

from __future__ import annotations

import hashlib
import json
import math
from collections import Counter, deque
from collections.abc import Iterable
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any

SUPPORTED_ELEMENTS = ("H", "C", "N", "O", "F", "P", "S", "Cl", "Br", "I")
HALOGENS = frozenset(("F", "Cl", "Br", "I"))


class StructureError(ValueError):
    """Raised when a molecular graph cannot be interpreted safely."""


@dataclass(slots=True)
class AtomNode:
    id: int
    element: str
    x: float
    y: float
    charge: int = 0
    aromatic: bool = False


@dataclass(slots=True)
class BondEdge:
    id: int
    atom1: int
    atom2: int
    order: float = 1.0


@dataclass(slots=True)
class ValidationResult:
    errors: list[str]
    warnings: list[str]

    @property
    def valid(self) -> bool:
        return not self.errors


class MoleculeGraph:
    """Editable molecular graph with conservative implicit-H handling."""

    format_name = "open-nmr-structure"
    format_version = 1

    def __init__(
        self, atoms: Iterable[AtomNode] = (), bonds: Iterable[BondEdge] = ()
    ) -> None:
        self.atoms: dict[int, AtomNode] = {atom.id: atom for atom in atoms}
        self.bonds: dict[int, BondEdge] = {bond.id: bond for bond in bonds}
        self._next_atom_id = max(self.atoms, default=0) + 1
        self._next_bond_id = max(self.bonds, default=0) + 1

    def copy(self) -> MoleculeGraph:
        return MoleculeGraph.from_dict(self.to_dict())

    def add_atom(
        self,
        element: str,
        x: float,
        y: float,
        *,
        charge: int = 0,
        aromatic: bool = False,
    ) -> int:
        element = _normalise_element(element)
        atom_id = self._next_atom_id
        self._next_atom_id += 1
        self.atoms[atom_id] = AtomNode(
            atom_id, element, float(x), float(y), int(charge), bool(aromatic)
        )
        return atom_id

    def set_atom(
        self,
        atom_id: int,
        *,
        element: str | None = None,
        charge: int | None = None,
        aromatic: bool | None = None,
    ) -> None:
        atom = self.atom(atom_id)
        if element is not None:
            atom.element = _normalise_element(element)
        if charge is not None:
            atom.charge = int(charge)
        if aromatic is not None:
            atom.aromatic = bool(aromatic)

    def move_atom(self, atom_id: int, x: float, y: float) -> None:
        atom = self.atom(atom_id)
        atom.x, atom.y = float(x), float(y)

    def remove_atom(self, atom_id: int) -> None:
        self.atom(atom_id)
        for bond_id in [
            bond.id
            for bond in self.bonds.values()
            if atom_id in (bond.atom1, bond.atom2)
        ]:
            del self.bonds[bond_id]
        del self.atoms[atom_id]

    def add_bond(self, atom1: int, atom2: int, order: float = 1.0) -> int:
        self.atom(atom1)
        self.atom(atom2)
        if atom1 == atom2:
            raise StructureError("不能创建原子自身成键。")
        order = _normalise_bond_order(order)
        existing = self.bond_between(atom1, atom2)
        if existing is not None:
            existing.order = order
            self._sync_aromatic_flags(existing)
            return existing.id
        bond_id = self._next_bond_id
        self._next_bond_id += 1
        edge = BondEdge(bond_id, atom1, atom2, order)
        self.bonds[bond_id] = edge
        self._sync_aromatic_flags(edge)
        return bond_id

    def set_bond_order(self, bond_id: int, order: float) -> None:
        bond = self.bond(bond_id)
        bond.order = _normalise_bond_order(order)
        self._sync_aromatic_flags(bond)

    def remove_bond(self, bond_id: int) -> None:
        self.bond(bond_id)
        del self.bonds[bond_id]

    def atom(self, atom_id: int) -> AtomNode:
        try:
            return self.atoms[atom_id]
        except KeyError as exc:
            raise StructureError(f"不存在原子 #{atom_id}。") from exc

    def bond(self, bond_id: int) -> BondEdge:
        try:
            return self.bonds[bond_id]
        except KeyError as exc:
            raise StructureError(f"不存在化学键 #{bond_id}。") from exc

    def bond_between(self, atom1: int, atom2: int) -> BondEdge | None:
        target = frozenset((atom1, atom2))
        for bond in self.bonds.values():
            if frozenset((bond.atom1, bond.atom2)) == target:
                return bond
        return None

    def incident_bonds(self, atom_id: int) -> list[BondEdge]:
        self.atom(atom_id)
        return [
            bond for bond in self.bonds.values() if atom_id in (bond.atom1, bond.atom2)
        ]

    def neighbours(self, atom_id: int) -> list[tuple[AtomNode, BondEdge]]:
        neighbours: list[tuple[AtomNode, BondEdge]] = []
        for bond in self.incident_bonds(atom_id):
            other_id = bond.atom2 if bond.atom1 == atom_id else bond.atom1
            neighbours.append((self.atoms[other_id], bond))
        return neighbours

    def degree(self, atom_id: int, *, include_hydrogen: bool = True) -> int:
        return sum(
            1
            for atom, _ in self.neighbours(atom_id)
            if include_hydrogen or atom.element != "H"
        )

    def bond_order_sum(self, atom_id: int) -> float:
        return sum(bond.order for _, bond in self.neighbours(atom_id))

    def implicit_hydrogens(self, atom_id: int) -> int:
        """Return conservative implicit H count for common organic valences."""

        atom = self.atom(atom_id)
        if atom.element == "H":
            return 0
        bond_sum = self.bond_order_sum(atom_id)
        explicit_h = sum(
            1 for neighbour, _ in self.neighbours(atom_id) if neighbour.element == "H"
        )
        # Explicit H already contributes one to bond_sum; this variable is kept
        # only to make the intent clear and to guard malformed H double bonds.
        if explicit_h and any(
            bond.order != 1.0
            for neighbour, bond in self.neighbours(atom_id)
            if neighbour.element == "H"
        ):
            return 0

        if atom.element == "C":
            target = 4.0
        elif atom.element == "N":
            target = 4.0 if atom.charge > 0 else 3.0
        elif atom.element == "O":
            target = 1.0 if atom.charge < 0 else (3.0 if atom.charge > 0 else 2.0)
        elif atom.element in HALOGENS:
            target = 1.0
        elif atom.element == "S":
            target = 2.0 if bond_sum <= 2.0 + 1e-6 else bond_sum
        elif atom.element == "P":
            target = 3.0 if bond_sum <= 3.0 + 1e-6 else 5.0
        else:  # guarded by add_atom/from_dict
            return 0
        missing = target - bond_sum
        if missing < 0.75:
            return 0
        rounded = round(missing)
        return rounded if math.isclose(missing, rounded, abs_tol=0.12) else 0

    def attached_hydrogens(self, atom_id: int) -> int:
        explicit = sum(
            1
            for atom, bond in self.neighbours(atom_id)
            if atom.element == "H" and bond.order == 1.0
        )
        return explicit + self.implicit_hydrogens(atom_id)

    def formula_counts(self) -> dict[str, int]:
        counts = Counter(atom.element for atom in self.atoms.values())
        counts["H"] += sum(
            self.implicit_hydrogens(atom.id) for atom in self.atoms.values()
        )
        return {element: count for element, count in counts.items() if count}

    def formula(self) -> str:
        counts = self.formula_counts()
        order: list[str] = []
        if "C" in counts:
            order.append("C")
            if "H" in counts:
                order.append("H")
        order.extend(sorted(element for element in counts if element not in order))
        return "".join(
            element + (str(counts[element]) if counts[element] != 1 else "")
            for element in order
        )

    def connected_components(self) -> list[set[int]]:
        unseen = set(self.atoms)
        components: list[set[int]] = []
        while unseen:
            root = min(unseen)
            component = {root}
            queue = deque((root,))
            unseen.remove(root)
            while queue:
                current = queue.popleft()
                for neighbour, _ in self.neighbours(current):
                    if neighbour.id in unseen:
                        unseen.remove(neighbour.id)
                        component.add(neighbour.id)
                        queue.append(neighbour.id)
            components.append(component)
        return components

    def validate(self) -> ValidationResult:
        errors: list[str] = []
        warnings: list[str] = []
        if not self.atoms:
            errors.append("画板中还没有结构。")
            return ValidationResult(errors, warnings)

        seen_pairs: set[frozenset[int]] = set()
        for bond in self.bonds.values():
            if bond.atom1 not in self.atoms or bond.atom2 not in self.atoms:
                errors.append(f"化学键 #{bond.id} 指向不存在的原子。")
            pair = frozenset((bond.atom1, bond.atom2))
            if len(pair) != 2:
                errors.append(f"化学键 #{bond.id} 是自连接。")
            elif pair in seen_pairs:
                errors.append(f"原子 #{bond.atom1} 与 #{bond.atom2} 之间存在重复键。")
            seen_pairs.add(pair)
            if bond.order not in (1.0, 1.5, 2.0, 3.0):
                errors.append(f"化学键 #{bond.id} 的键级 {bond.order:g} 不受支持。")

        for atom in self.atoms.values():
            bond_sum = self.bond_order_sum(atom.id)
            maximum = {
                "H": 1,
                "C": 4,
                "N": 4,
                "O": 3,
                "F": 1,
                "Cl": 1,
                "Br": 1,
                "I": 1,
                "P": 5,
                "S": 6,
            }[atom.element]
            if bond_sum > maximum + 1e-6:
                errors.append(
                    f"{atom.element} 原子 #{atom.id} 的键级和为 {bond_sum:g}，超过常见上限 {maximum}。"
                )
            if atom.element == "N" and atom.charge == 0 and bond_sum > 3.0 + 1e-6:
                warnings.append(
                    f"N 原子 #{atom.id} 为四配位但未标正电荷，请检查形式电荷。"
                )
            if atom.element == "O" and atom.charge == 0 and bond_sum > 2.0 + 1e-6:
                warnings.append(f"O 原子 #{atom.id} 超过常见中性价态，请检查形式电荷。")
            if atom.aromatic and not any(
                math.isclose(bond.order, 1.5) for _, bond in self.neighbours(atom.id)
            ):
                warnings.append(f"原子 #{atom.id} 标为芳香，但没有芳香键。")

        components = self.connected_components()
        if len(components) > 1:
            warnings.append(
                f"结构含 {len(components)} 个不相连片段；当前会作为一个体系一起预测。"
            )
        if any(
            atom.element == "H" and self.degree(atom.id) != 1
            for atom in self.atoms.values()
        ):
            errors.append("显式 H 必须且只能连接一个原子。")
        return ValidationResult(_unique(errors), _unique(warnings))

    def environment_labels(self, radius: int = 4) -> dict[int, str]:
        """Weisfeiler-Lehman labels used for exact topological equivalence."""

        labels = {
            atom.id: (
                f"{atom.element}:{atom.charge}:{int(atom.aromatic)}:"
                f"H{self.attached_hydrogens(atom.id)}:D{self.degree(atom.id)}"
            )
            for atom in self.atoms.values()
        }
        for _ in range(max(0, radius)):
            updated: dict[int, str] = {}
            for atom in self.atoms.values():
                canonical = (
                    labels[atom.id]
                    + "["
                    + "|".join(
                        sorted(
                            f"{bond.order:g}>{labels[neighbour.id]}"
                            for neighbour, bond in self.neighbours(atom.id)
                        )
                    )
                    + "]"
                )
                updated[atom.id] = hashlib.sha1(canonical.encode("utf-8")).hexdigest()
            labels = updated
        return labels

    def to_dict(self) -> dict[str, Any]:
        return {
            "format": self.format_name,
            "version": self.format_version,
            "atoms": [asdict(self.atoms[key]) for key in sorted(self.atoms)],
            "bonds": [asdict(self.bonds[key]) for key in sorted(self.bonds)],
        }

    @classmethod
    def from_dict(cls, payload: dict[str, Any]) -> MoleculeGraph:
        if payload.get("format", cls.format_name) != cls.format_name:
            raise StructureError("不是 Open NMR Workbench 结构文件。")
        atoms = []
        for item in payload.get("atoms", []):
            atoms.append(
                AtomNode(
                    id=int(item["id"]),
                    element=_normalise_element(str(item["element"])),
                    x=float(item["x"]),
                    y=float(item["y"]),
                    charge=int(item.get("charge", 0)),
                    aromatic=bool(item.get("aromatic", False)),
                )
            )
        bonds = [
            BondEdge(
                id=int(item["id"]),
                atom1=int(item["atom1"]),
                atom2=int(item["atom2"]),
                order=_normalise_bond_order(float(item.get("order", 1.0))),
            )
            for item in payload.get("bonds", [])
        ]
        graph = cls(atoms, bonds)
        result = graph.validate()
        errors = [error for error in result.errors if error != "画板中还没有结构。"]
        if errors:
            raise StructureError("；".join(errors))
        return graph

    def save(self, path: str | Path) -> Path:
        target = Path(path)
        target.write_text(
            json.dumps(self.to_dict(), ensure_ascii=False, indent=2), encoding="utf-8"
        )
        return target

    @classmethod
    def load(cls, path: str | Path) -> MoleculeGraph:
        try:
            payload = json.loads(Path(path).read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError) as exc:
            raise StructureError(f"无法读取结构文件：{exc}") from exc
        if not isinstance(payload, dict):
            raise StructureError("结构文件顶层必须是 JSON 对象。")
        return cls.from_dict(payload)

    @classmethod
    def from_smiles(cls, smiles: str) -> MoleculeGraph:
        Chem, AllChem = _load_rdkit()
        molecule = Chem.MolFromSmiles(smiles.strip())
        if molecule is None:
            raise StructureError(
                "SMILES 无法解析，请检查括号、环编号、键级和形式电荷。"
            )
        molecule = Chem.RemoveHs(molecule)
        AllChem.Compute2DCoords(molecule)
        return cls.from_rdkit(molecule)

    @classmethod
    def from_molblock(cls, molblock: str) -> MoleculeGraph:
        Chem, AllChem = _load_rdkit()
        molecule = Chem.MolFromMolBlock(molblock, sanitize=True, removeHs=True)
        if molecule is None:
            raise StructureError("MOL/SDF 结构无法解析或价态清洗失败。")
        if molecule.GetNumConformers() == 0:
            AllChem.Compute2DCoords(molecule)
        return cls.from_rdkit(molecule)

    @classmethod
    def from_rdkit(cls, molecule: Any) -> MoleculeGraph:
        Chem, AllChem = _load_rdkit()
        molecule = Chem.RemoveHs(molecule)
        if molecule.GetNumConformers() == 0:
            AllChem.Compute2DCoords(molecule)
        conformer = molecule.GetConformer()
        graph = cls()
        id_map: dict[int, int] = {}
        for atom in molecule.GetAtoms():
            position = conformer.GetAtomPosition(atom.GetIdx())
            id_map[atom.GetIdx()] = graph.add_atom(
                atom.GetSymbol(),
                float(position.x),
                float(-position.y),
                charge=atom.GetFormalCharge(),
                aromatic=atom.GetIsAromatic(),
            )
        for bond in molecule.GetBonds():
            if bond.GetIsAromatic():
                order = 1.5
            else:
                order = float(bond.GetBondTypeAsDouble())
            graph.add_bond(
                id_map[bond.GetBeginAtomIdx()], id_map[bond.GetEndAtomIdx()], order
            )
        return graph

    def to_rdkit(self) -> Any:
        Chem, _ = _load_rdkit()
        editable = Chem.RWMol()
        id_map: dict[int, int] = {}
        for atom_id in sorted(self.atoms):
            node = self.atoms[atom_id]
            rd_atom = Chem.Atom(node.element)
            rd_atom.SetFormalCharge(node.charge)
            rd_atom.SetIsAromatic(node.aromatic)
            id_map[atom_id] = editable.AddAtom(rd_atom)
        bond_types = {
            1.0: Chem.BondType.SINGLE,
            1.5: Chem.BondType.AROMATIC,
            2.0: Chem.BondType.DOUBLE,
            3.0: Chem.BondType.TRIPLE,
        }
        for bond in self.bonds.values():
            editable.AddBond(
                id_map[bond.atom1], id_map[bond.atom2], bond_types[bond.order]
            )
            if bond.order == 1.5:
                editable.GetBondBetweenAtoms(
                    id_map[bond.atom1], id_map[bond.atom2]
                ).SetIsAromatic(True)
        molecule = editable.GetMol()
        try:
            Chem.SanitizeMol(molecule)
        except Exception as exc:
            raise StructureError(f"RDKit 价态/芳香性清洗失败：{exc}") from exc
        conformer = Chem.Conformer(molecule.GetNumAtoms())
        for atom_id, rd_index in id_map.items():
            atom = self.atoms[atom_id]
            conformer.SetAtomPosition(rd_index, (float(atom.x), float(-atom.y), 0.0))
        molecule.RemoveAllConformers()
        molecule.AddConformer(conformer, assignId=True)
        return molecule

    def to_smiles(self) -> str:
        Chem, _ = _load_rdkit()
        return str(Chem.MolToSmiles(self.to_rdkit(), canonical=True))

    def to_molblock(self) -> str:
        Chem, _ = _load_rdkit()
        return str(Chem.MolToMolBlock(self.to_rdkit()))

    def _sync_aromatic_flags(self, bond: BondEdge) -> None:
        if math.isclose(bond.order, 1.5):
            self.atoms[bond.atom1].aromatic = True
            self.atoms[bond.atom2].aromatic = True


def _normalise_element(element: str) -> str:
    value = element.strip()
    if not value:
        raise StructureError("元素符号不能为空。")
    value = value[0].upper() + value[1:].lower()
    if value not in SUPPORTED_ELEMENTS:
        raise StructureError(
            f"暂不支持元素 {value}；画板支持 {', '.join(SUPPORTED_ELEMENTS)}。"
        )
    return value


def _normalise_bond_order(order: float) -> float:
    value = float(order)
    for allowed in (1.0, 1.5, 2.0, 3.0):
        if math.isclose(value, allowed, abs_tol=1e-6):
            return allowed
    raise StructureError(f"不支持键级 {order}；可用单、芳香、双或三键。")


def _load_rdkit() -> tuple[Any, Any]:
    try:
        from rdkit import Chem
        from rdkit.Chem import AllChem
    except ModuleNotFoundError as exc:
        raise StructureError(
            "此操作需要 RDKit。请重新运行 install_windows.bat，或执行 python -m pip install rdkit。"
        ) from exc
    return Chem, AllChem


def _unique(values: Iterable[str]) -> list[str]:
    return list(dict.fromkeys(values))
