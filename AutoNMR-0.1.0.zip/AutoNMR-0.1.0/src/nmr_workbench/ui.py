from __future__ import annotations

import copy
import traceback
import webbrowser
from dataclasses import dataclass
from pathlib import Path
from typing import Callable

import numpy as np

from . import __version__
import tkinter as tk
from tkinter import filedialog, messagebox, ttk

from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg, NavigationToolbar2Tk
from matplotlib.figure import Figure
from matplotlib.widgets import SpanSelector

from .auth import AccountStore, Session, UserAccount
from .edition import bundled_edition_policy
from .history import OperationHistory
from .i18n import (
    SUPPORTED_LANGUAGES,
    Translator,
    configure_matplotlib_fonts,
    matplotlib_font_supports_cjk,
    preferred_ui_font,
)
from .analysis import AnalysisConfig, analyze_spectrum
from .candidates import Candidate, load_candidate_library
from .demo import generate_demo_spectrum
from .domain_i18n import domain_text
from .io import load_nmr_data, save_spectrum_csv
from .models import AnalysisReport, FID1D, Spectrum1D
from .processing import ProcessingConfig, correct_baseline, process_fid, reference_spectrum
from .report import write_report
from .settings import AppSettings, load_settings, save_settings
from .solvents import solvent_ids


@dataclass(slots=True)
class _WorkbenchState:
    raw_fid: FID1D | None
    source_spectrum: Spectrum1D | None
    spectrum: Spectrum1D | None
    report: AnalysisReport | None
    manual_peak_positions: list[float]
    manual_integrals: list[dict[str, float]]
    dataset_text: str
    parameters: dict[str, str | bool]


class NMRWorkbenchApp:
    def __init__(self, root: tk.Tk) -> None:
        self.root = root
        self.settings: AppSettings = load_settings()
        self.tr = Translator(self.settings.language)
        self.edition = bundled_edition_policy()
        plot_font = configure_matplotlib_fonts(self.settings.language)
        self.plot_language = (
            "en_US"
            if self.settings.language == "zh_CN" and not matplotlib_font_supports_cjk(plot_font)
            else self.settings.language
        )
        self.plot_tr = Translator(self.plot_language)
        self.root.option_add("*Font", (preferred_ui_font(), 10))
        self.root.title(self.tr.t("app.title"))
        self.root.geometry("1460x900")
        self.root.minsize(1100, 700)

        self.raw_fid: FID1D | None = None
        self.source_spectrum: Spectrum1D | None = None
        self.spectrum: Spectrum1D | None = None
        self.report: AnalysisReport | None = None
        self.candidates: list[Candidate] | None = None
        self.candidate_path: Path | None = None
        self.manual_peak_positions: list[float] = []
        self.manual_integrals: list[dict[str, float]] = []
        self.click_mode: str | None = None
        self.structure_editor = None
        self.database_window = None
        self.account_window = None
        self.account_store: AccountStore | None = None
        self.current_user: UserAccount | None = None
        self.current_session: Session | None = None
        self.history: OperationHistory[_WorkbenchState] = OperationHistory()
        self._busy = False

        self._make_variables()
        self._configure_style()
        self._build_menu()
        self._build_layout()
        self._set_status(self.tr.t("app.ready"))
        self._draw_empty()
        self.root.protocol("WM_DELETE_WINDOW", self.close_app)

    def _make_variables(self) -> None:
        self.status_var = tk.StringVar()
        self.dataset_var = tk.StringVar(value=self.tr.t("app.no_data"))
        self.lb_var = tk.StringVar(value="0.3")
        self.zf_var = tk.StringVar(value="2")
        self.apodization_var = tk.StringVar(value="exponential")
        self.auto_phase_var = tk.BooleanVar(value=True)
        self.ph0_var = tk.StringVar(value="0.0")
        self.ph1_var = tk.StringVar(value="0.0")
        self.baseline_var = tk.StringVar(value="asls")
        self.solvent_var = tk.StringVar(value="CDCl3")
        self.nucleus_var = tk.StringVar(value="1H")
        self.frequency_var = tk.StringVar(value="400.0")
        self.formula_var = tk.StringVar(value="")
        self.snr_var = tk.StringVar(value="6.0")
        self.group_gap_var = tk.StringVar(value="28.0")
        self.reference_observed_var = tk.StringVar(value="7.26")
        self.reference_target_var = tk.StringVar(value="7.26")
        self.integral_mode_var = tk.BooleanVar(value=False)
        self.language_var = tk.StringVar(value=self.settings.language)
        self.account_label_var = tk.StringVar(value=self.tr.t("account.guest"))

    def _configure_style(self) -> None:
        style = ttk.Style(self.root)
        try:
            style.theme_use("clam")
        except tk.TclError:
            pass
        background = "#f4f6f9"
        card = "#ffffff"
        accent = "#0f6b78"
        self.root.configure(background=background)
        style.configure("TFrame", background=background)
        style.configure("Toolbar.TFrame", background="#eaf0f3")
        style.configure("Sidebar.TFrame", background="#eef2f5")
        style.configure("TLabel", background=background, foreground="#23323f")
        style.configure("Toolbar.TLabel", background="#eaf0f3", foreground="#334155")
        style.configure("TButton", padding=(8, 5))
        style.configure("Accent.TButton", padding=(9, 5), background=accent, foreground="#ffffff")
        style.map("Accent.TButton", background=[("active", "#0b5964"), ("pressed", "#08434b")])
        style.configure("Section.TLabelframe", background=card, bordercolor="#d8e0e7", relief="solid")
        style.configure("Section.TLabelframe.Label", background=card, foreground="#183b44", font=(preferred_ui_font(), 10, "bold"))
        style.configure("Treeview", rowheight=26, background="#ffffff", fieldbackground="#ffffff", bordercolor="#d9e1e7")
        style.configure("Treeview.Heading", padding=(6, 5), font=(preferred_ui_font(), 9, "bold"))
        style.configure("TNotebook", background=background, borderwidth=0)
        style.configure("TNotebook.Tab", padding=(10, 5))

    def _build_menu(self) -> None:
        menu = tk.Menu(self.root)
        file_menu = tk.Menu(menu, tearoff=False)
        file_menu.add_command(label=self.tr.t("action.open_file"), command=self.open_file, accelerator="Ctrl+O")
        file_menu.add_command(label=self.tr.t("action.open_bruker"), command=self.open_folder)
        file_menu.add_command(label=self.tr.t("action.demo"), command=self.load_demo, accelerator="Ctrl+D")
        file_menu.add_separator()
        file_menu.add_command(label=self.tr.t("action.save_csv"), command=self.save_processed_csv)
        file_menu.add_command(label=self.tr.t("action.export_report"), command=self.export_report, accelerator="Ctrl+S")
        file_menu.add_separator()
        file_menu.add_command(label=self.tr.t("action.exit"), command=self.close_app)
        menu.add_cascade(label=self.tr.t("menu.file"), menu=file_menu)

        self.edit_menu = tk.Menu(menu, tearoff=False)
        self.edit_menu.add_command(label=self.tr.t("action.undo"), command=self.undo, accelerator="Ctrl+Z")
        self.edit_menu.add_command(label=self.tr.t("action.redo"), command=self.redo, accelerator="Ctrl+Y")
        self.edit_menu.add_separator()
        self.edit_menu.add_command(label=self.tr.t("action.cancel_tool"), command=self.cancel_current_tool, accelerator="Esc")
        self.edit_menu.add_command(label=self.tr.t("action.clear_annotations"), command=self.clear_manual_annotations)
        menu.add_cascade(label=self.tr.t("menu.edit"), menu=self.edit_menu)

        process_menu = tk.Menu(menu, tearoff=False)
        process_menu.add_command(label=self.tr.t("action.reprocess"), command=self.process_current, accelerator="F5")
        process_menu.add_command(label=self.tr.t("action.apply_reference"), command=self.apply_reference)
        process_menu.add_separator()
        process_menu.add_command(label=self.tr.t("action.add_peak"), command=lambda: self.set_click_mode("add"))
        process_menu.add_command(label=self.tr.t("action.remove_peak"), command=lambda: self.set_click_mode("remove"))
        process_menu.add_command(label=self.tr.t("action.integration"), command=self.activate_integral_mode)
        menu.add_cascade(label=self.tr.t("menu.process"), menu=process_menu)

        analysis_menu = tk.Menu(menu, tearoff=False)
        analysis_menu.add_command(label=self.tr.t("action.auto_analysis"), command=self.run_analysis, accelerator="F9")
        analysis_menu.add_command(label=self.tr.t("action.load_candidates"), command=self.load_candidates)
        analysis_menu.add_separator()
        analysis_menu.add_command(
            label=self.tr.t("action.structure_prediction"),
            command=self.open_structure_editor,
            accelerator="Ctrl+Shift+P",
        )
        menu.add_cascade(label=self.tr.t("menu.analysis"), menu=analysis_menu)

        database_menu = tk.Menu(menu, tearoff=False)
        database_menu.add_command(label=self.tr.t("action.databases"), command=self.open_database_window, accelerator="Ctrl+Shift+D")
        menu.add_cascade(label=self.tr.t("menu.database"), menu=database_menu)

        account_menu = tk.Menu(menu, tearoff=False)
        account_menu.add_command(label=self.tr.t("action.account"), command=self.open_account_window)
        account_menu.add_command(label=self.tr.t("action.change_password"), command=self.open_account_window)
        account_menu.add_separator()
        account_menu.add_command(label=self.tr.t("action.logout"), command=self.logout)
        menu.add_cascade(label=self.tr.t("menu.account"), menu=account_menu)

        language_menu = tk.Menu(menu, tearoff=False)
        language_menu.add_radiobutton(label=self.tr.t("language.zh"), value="zh_CN", variable=self.language_var, command=lambda: self.set_language("zh_CN"))
        language_menu.add_radiobutton(label=self.tr.t("language.en"), value="en_US", variable=self.language_var, command=lambda: self.set_language("en_US"))
        menu.add_cascade(label=self.tr.t("menu.language"), menu=language_menu)

        help_menu = tk.Menu(menu, tearoff=False)
        help_menu.add_command(label=self.tr.t("action.about"), command=self.show_about)
        menu.add_cascade(label=self.tr.t("menu.help"), menu=help_menu)
        self.root.config(menu=menu)
        self.root.bind("<Control-o>", lambda _: self.open_file())
        self.root.bind("<Control-d>", lambda _: self.load_demo())
        self.root.bind("<Control-s>", lambda _: self.export_report())
        self.root.bind("<F5>", lambda _: self.process_current())
        self.root.bind("<F9>", lambda _: self.run_analysis())
        self.root.bind("<Control-Shift-P>", lambda _: self.open_structure_editor())
        self.root.bind("<Control-Shift-D>", lambda _: self.open_database_window())
        self.root.bind("<Control-z>", lambda _: self.undo())
        self.root.bind("<Control-y>", lambda _: self.redo())
        self.root.bind("<Escape>", lambda _: self.cancel_current_tool())
        self._update_history_controls()

    def _build_layout(self) -> None:
        toolbar = ttk.Frame(self.root, padding=(10, 8), style="Toolbar.TFrame")
        toolbar.pack(fill=tk.X)
        ttk.Label(toolbar, textvariable=self.account_label_var, style="Toolbar.TLabel").pack(side=tk.RIGHT, padx=(10, 3))
        for label, command, accent in (
            (self.tr.t("toolbar.open"), self.open_file, True),
            (self.tr.t("toolbar.bruker"), self.open_folder, False),
            (self.tr.t("toolbar.demo"), self.load_demo, False),
            (self.tr.t("toolbar.process"), self.process_current, False),
            (self.tr.t("toolbar.analyze"), self.run_analysis, True),
            (self.tr.t("toolbar.predict"), self.open_structure_editor, False),
            (self.tr.t("toolbar.database"), self.open_database_window, False),
            (self.tr.t("toolbar.report"), self.export_report, False),
        ):
            ttk.Button(toolbar, text=label, command=command, style="Accent.TButton" if accent else "TButton").pack(side=tk.LEFT, padx=2)
        ttk.Separator(toolbar, orient=tk.VERTICAL).pack(side=tk.LEFT, fill=tk.Y, padx=8)
        self.undo_button = ttk.Button(toolbar, text="↶", width=3, command=self.undo)
        self.undo_button.pack(side=tk.LEFT, padx=1)
        self.redo_button = ttk.Button(toolbar, text="↷", width=3, command=self.redo)
        self.redo_button.pack(side=tk.LEFT, padx=1)
        ttk.Button(toolbar, text=self.tr.t("toolbar.add_peak"), command=lambda: self.set_click_mode("add")).pack(side=tk.LEFT, padx=2)
        ttk.Button(toolbar, text=self.tr.t("toolbar.remove_peak"), command=lambda: self.set_click_mode("remove")).pack(side=tk.LEFT, padx=2)
        ttk.Checkbutton(
            toolbar,
            text=self.tr.t("toolbar.integrate"),
            variable=self.integral_mode_var,
            command=self.toggle_integral_mode,
        ).pack(side=tk.LEFT, padx=3)
        ttk.Button(toolbar, text=self.tr.t("toolbar.cancel"), command=self.cancel_current_tool).pack(side=tk.LEFT, padx=2)

        paned = ttk.Panedwindow(self.root, orient=tk.HORIZONTAL)
        paned.pack(fill=tk.BOTH, expand=True)
        sidebar_outer = ttk.Frame(paned, width=322, style="Sidebar.TFrame")
        workspace = ttk.Frame(paned)
        paned.add(sidebar_outer, weight=0)
        paned.add(workspace, weight=1)

        sidebar_canvas = tk.Canvas(sidebar_outer, highlightthickness=0, width=322, background="#eef2f5")
        sidebar_scroll = ttk.Scrollbar(sidebar_outer, orient=tk.VERTICAL, command=sidebar_canvas.yview)
        sidebar = ttk.Frame(sidebar_canvas, padding=(10, 7), style="Sidebar.TFrame")
        sidebar.bind("<Configure>", lambda e: sidebar_canvas.configure(scrollregion=sidebar_canvas.bbox("all")))
        sidebar_canvas.create_window((0, 0), window=sidebar, anchor="nw", width=304)
        sidebar_canvas.configure(yscrollcommand=sidebar_scroll.set)
        sidebar_canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        sidebar_scroll.pack(side=tk.RIGHT, fill=tk.Y)

        ttk.Label(sidebar, textvariable=self.dataset_var, wraplength=270, foreground="#244f5a").pack(fill=tk.X, pady=(2, 8))
        self._build_processing_panel(sidebar)
        self._build_reference_panel(sidebar)
        self._build_analysis_panel(sidebar)

        plot_frame = ttk.Frame(workspace)
        plot_frame.pack(fill=tk.BOTH, expand=True)
        self.figure = Figure(figsize=(10, 5), dpi=100, facecolor="white")
        self.axes = self.figure.add_subplot(111)
        self.canvas = FigureCanvasTkAgg(self.figure, master=plot_frame)
        self.canvas.draw()
        navigation = NavigationToolbar2Tk(self.canvas, plot_frame, pack_toolbar=False)
        navigation.update()
        navigation.pack(fill=tk.X)
        self.canvas.get_tk_widget().pack(fill=tk.BOTH, expand=True)
        self.canvas.mpl_connect("button_press_event", self._on_plot_click)
        self.span_selector = SpanSelector(
            self.axes,
            self._on_integral_span,
            "horizontal",
            useblit=True,
            props=dict(alpha=0.22, facecolor="#d97706"),
            interactive=False,
            drag_from_anywhere=False,
        )
        self.span_selector.set_active(False)

        notebook = ttk.Notebook(workspace, height=235)
        notebook.pack(fill=tk.X, padx=4, pady=(2, 5))
        self.signal_tab = ttk.Frame(notebook)
        self.fragment_tab = ttk.Frame(notebook)
        self.candidate_tab = ttk.Frame(notebook)
        self.integral_tab = ttk.Frame(notebook)
        self.log_tab = ttk.Frame(notebook)
        notebook.add(self.signal_tab, text=self.tr.t("tab.signals"))
        notebook.add(self.fragment_tab, text=self.tr.t("tab.fragments"))
        notebook.add(self.candidate_tab, text=self.tr.t("tab.candidates"))
        notebook.add(self.integral_tab, text=self.tr.t("tab.integrals"))
        notebook.add(self.log_tab, text=self.tr.t("tab.quality"))
        self._build_result_tables()

        status = ttk.Label(self.root, textvariable=self.status_var, anchor=tk.W, padding=(8, 4), relief=tk.SUNKEN)
        status.pack(fill=tk.X)

    def _labeled_entry(self, parent: ttk.Frame, label: str, variable: tk.Variable, row: int, width: int = 10) -> None:
        ttk.Label(parent, text=label).grid(row=row, column=0, sticky=tk.W, padx=3, pady=3)
        ttk.Entry(parent, textvariable=variable, width=width).grid(row=row, column=1, sticky=tk.EW, padx=3, pady=3)

    def _build_processing_panel(self, parent: ttk.Frame) -> None:
        frame = ttk.LabelFrame(parent, text=self.tr.t("panel.processing"), style="Section.TLabelframe", padding=9)
        frame.pack(fill=tk.X, pady=5)
        frame.columnconfigure(1, weight=1)
        ttk.Label(frame, text=self.tr.t("field.window")).grid(row=0, column=0, sticky=tk.W, padx=3, pady=3)
        ttk.Combobox(
            frame,
            textvariable=self.apodization_var,
            values=("exponential", "gaussian", "sinebell", "none"),
            state="readonly",
            width=13,
        ).grid(row=0, column=1, sticky=tk.EW, padx=3, pady=3)
        self._labeled_entry(frame, self.tr.t("field.line_broadening"), self.lb_var, 1)
        ttk.Label(frame, text=self.tr.t("field.zero_fill")).grid(row=2, column=0, sticky=tk.W, padx=3, pady=3)
        ttk.Combobox(frame, textvariable=self.zf_var, values=("1", "2", "4", "8"), state="readonly", width=8).grid(
            row=2, column=1, sticky=tk.EW, padx=3, pady=3
        )
        ttk.Checkbutton(frame, text=self.tr.t("field.auto_phase"), variable=self.auto_phase_var).grid(
            row=3, column=0, columnspan=2, sticky=tk.W, padx=3, pady=3
        )
        self._labeled_entry(frame, "P0 / °", self.ph0_var, 4)
        self._labeled_entry(frame, "P1 / °", self.ph1_var, 5)
        ttk.Label(frame, text=self.tr.t("field.baseline")).grid(row=6, column=0, sticky=tk.W, padx=3, pady=3)
        ttk.Combobox(
            frame,
            textvariable=self.baseline_var,
            values=("asls", "polynomial", "none"),
            state="readonly",
            width=13,
        ).grid(row=6, column=1, sticky=tk.EW, padx=3, pady=3)
        ttk.Button(frame, text=self.tr.t("action.reprocess"), command=self.process_current).grid(row=7, column=0, columnspan=2, sticky=tk.EW, padx=3, pady=(7, 3))

    def _build_reference_panel(self, parent: ttk.Frame) -> None:
        frame = ttk.LabelFrame(parent, text=self.tr.t("panel.reference"), style="Section.TLabelframe", padding=9)
        frame.pack(fill=tk.X, pady=5)
        frame.columnconfigure(1, weight=1)
        self._labeled_entry(frame, self.tr.t("field.observed_shift"), self.reference_observed_var, 0)
        self._labeled_entry(frame, self.tr.t("field.target_shift"), self.reference_target_var, 1)
        ttk.Button(frame, text=self.tr.t("action.apply_reference"), command=self.apply_reference).grid(row=2, column=0, columnspan=2, sticky=tk.EW, padx=3, pady=3)

    def _build_analysis_panel(self, parent: ttk.Frame) -> None:
        frame = ttk.LabelFrame(parent, text=self.tr.t("panel.analysis"), style="Section.TLabelframe", padding=9)
        frame.pack(fill=tk.X, pady=5)
        frame.columnconfigure(1, weight=1)
        ttk.Label(frame, text=self.tr.t("field.nucleus")).grid(row=0, column=0, sticky=tk.W, padx=3, pady=3)
        ttk.Combobox(frame, textvariable=self.nucleus_var, values=("1H", "13C", "19F", "31P"), width=10).grid(
            row=0, column=1, sticky=tk.EW, padx=3, pady=3
        )
        ttk.Label(frame, text=self.tr.t("field.solvent")).grid(row=1, column=0, sticky=tk.W, padx=3, pady=3)
        ttk.Combobox(
            frame,
            textvariable=self.solvent_var,
            values=solvent_ids(),
            width=12,
        ).grid(row=1, column=1, sticky=tk.EW, padx=3, pady=3)
        self._labeled_entry(frame, self.tr.t("field.frequency"), self.frequency_var, 2)
        self._labeled_entry(frame, self.tr.t("field.formula"), self.formula_var, 3)
        self._labeled_entry(frame, self.tr.t("field.snr"), self.snr_var, 4)
        self._labeled_entry(frame, self.tr.t("field.group_gap"), self.group_gap_var, 5)
        ttk.Button(frame, text=self.tr.t("action.load_candidates"), command=self.load_candidates).grid(row=6, column=0, sticky=tk.EW, padx=3, pady=4)
        self.candidate_label = ttk.Label(frame, text=self.tr.t("field.candidate_builtin"), foreground="#526174", wraplength=125)
        self.candidate_label.grid(row=6, column=1, sticky=tk.W, padx=3, pady=4)
        ttk.Button(frame, text=self.tr.t("action.auto_analysis"), command=self.run_analysis, style="Accent.TButton").grid(
            row=7, column=0, columnspan=2, sticky=tk.EW, padx=3, pady=(8, 3)
        )

    def _tree_with_scroll(self, parent: ttk.Frame, columns: tuple[str, ...], headings: tuple[str, ...]) -> ttk.Treeview:
        tree = ttk.Treeview(parent, columns=columns, show="headings")
        scrollbar = ttk.Scrollbar(parent, orient=tk.VERTICAL, command=tree.yview)
        tree.configure(yscrollcommand=scrollbar.set)
        tree.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        for column, heading in zip(columns, headings):
            tree.heading(column, text=heading)
            tree.column(column, width=90, minwidth=55, stretch=True)
        return tree

    def _build_result_tables(self) -> None:
        self.signal_tree = self._tree_with_scroll(
            self.signal_tab,
            ("index", "shift", "mult", "integral", "h", "j", "region", "reference", "confidence"),
            (self.tr.t("heading.index"), self.tr.t("heading.shift"), self.tr.t("heading.multiplicity"), self.tr.t("heading.relative_integral"), self.tr.t("heading.estimated_h"), self.tr.t("heading.j"), self.tr.t("heading.region"), self.tr.t("heading.reference"), self.tr.t("heading.confidence")),
        )
        self.signal_tree.column("index", width=35, stretch=False)
        self.signal_tree.column("shift", width=75, stretch=False)
        self.signal_tree.column("mult", width=60, stretch=False)
        self.signal_tree.column("integral", width=75, stretch=False)
        self.signal_tree.column("h", width=65, stretch=False)
        self.signal_tree.column("confidence", width=65, stretch=False)
        self.fragment_tree = self._tree_with_scroll(
            self.fragment_tab,
            ("hint", "evidence", "signals", "confidence"),
            (self.tr.t("heading.fragment"), self.tr.t("heading.evidence"), self.tr.t("heading.signal_index"), self.tr.t("heading.confidence")),
        )
        self.fragment_tree.column("hint", width=220)
        self.fragment_tree.column("evidence", width=500)
        self.candidate_tree = self._tree_with_scroll(
            self.candidate_tab,
            ("rank", "name", "score", "matched", "rmse", "formula", "smiles"),
            (self.tr.t("heading.index"), self.tr.t("heading.candidate"), self.tr.t("heading.score"), self.tr.t("heading.matched"), self.tr.t("heading.rmse"), self.tr.t("heading.formula"), self.tr.t("heading.smiles")),
        )
        self.candidate_tree.column("rank", width=35, stretch=False)
        self.candidate_tree.column("score", width=60, stretch=False)
        self.integral_tree = self._tree_with_scroll(
            self.integral_tab,
            ("index", "high", "low", "area", "relative"),
            (self.tr.t("heading.index"), self.tr.t("heading.high"), self.tr.t("heading.low"), self.tr.t("heading.area"), self.tr.t("heading.relative_integral")),
        )
        integral_buttons = ttk.Frame(self.integral_tab)
        integral_buttons.pack(side=tk.BOTTOM, fill=tk.X)
        ttk.Button(integral_buttons, text=self.tr.t("action.clear_integrals"), command=self.clear_manual_integrals).pack(side=tk.RIGHT, padx=4, pady=3)
        self.log_text = tk.Text(self.log_tab, height=8, wrap=tk.WORD, state=tk.DISABLED, relief=tk.FLAT)
        log_scroll = ttk.Scrollbar(self.log_tab, orient=tk.VERTICAL, command=self.log_text.yview)
        self.log_text.configure(yscrollcommand=log_scroll.set)
        self.log_text.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        log_scroll.pack(side=tk.RIGHT, fill=tk.Y)

    def _set_status(self, text: str) -> None:
        self.status_var.set(text)
        self.root.update_idletasks()

    def _txt(self, zh, en):
        return en if self.tr.language == "en_US" else zh

    def _snapshot_state(self) -> _WorkbenchState:
        parameters: dict[str, str | bool] = {
            "lb": self.lb_var.get(),
            "zf": self.zf_var.get(),
            "apodization": self.apodization_var.get(),
            "auto_phase": bool(self.auto_phase_var.get()),
            "ph0": self.ph0_var.get(),
            "ph1": self.ph1_var.get(),
            "baseline": self.baseline_var.get(),
            "solvent": self.solvent_var.get(),
            "nucleus": self.nucleus_var.get(),
            "frequency": self.frequency_var.get(),
            "formula": self.formula_var.get(),
            "snr": self.snr_var.get(),
            "group_gap": self.group_gap_var.get(),
            "reference_observed": self.reference_observed_var.get(),
            "reference_target": self.reference_target_var.get(),
        }
        return _WorkbenchState(
            raw_fid=self.raw_fid,
            source_spectrum=self.source_spectrum.copy() if self.source_spectrum is not None else None,
            spectrum=self.spectrum.copy() if self.spectrum is not None else None,
            report=copy.deepcopy(self.report),
            manual_peak_positions=list(self.manual_peak_positions),
            manual_integrals=[dict(item) for item in self.manual_integrals],
            dataset_text=self.dataset_var.get(),
            parameters=parameters,
        )

    @staticmethod
    def _state_bytes(state: _WorkbenchState) -> int:
        total = 0
        for spectrum in (state.source_spectrum, state.spectrum):
            if spectrum is not None:
                total += int(spectrum.ppm.nbytes + spectrum.intensity.nbytes)
        return total

    def _record_operation(self, label: str) -> None:
        state = self._snapshot_state()
        self.history.record(label, state, approximate_bytes=self._state_bytes(state))
        self._update_history_controls()

    def _restore_state(self, state: _WorkbenchState) -> None:
        self.raw_fid = state.raw_fid
        self.source_spectrum = state.source_spectrum.copy() if state.source_spectrum is not None else None
        self.spectrum = state.spectrum.copy() if state.spectrum is not None else None
        self.report = copy.deepcopy(state.report)
        self.manual_peak_positions = list(state.manual_peak_positions)
        self.manual_integrals = [dict(item) for item in state.manual_integrals]
        self.dataset_var.set(state.dataset_text)
        mapping = {
            "lb": self.lb_var,
            "zf": self.zf_var,
            "apodization": self.apodization_var,
            "auto_phase": self.auto_phase_var,
            "ph0": self.ph0_var,
            "ph1": self.ph1_var,
            "baseline": self.baseline_var,
            "solvent": self.solvent_var,
            "nucleus": self.nucleus_var,
            "frequency": self.frequency_var,
            "formula": self.formula_var,
            "snr": self.snr_var,
            "group_gap": self.group_gap_var,
            "reference_observed": self.reference_observed_var,
            "reference_target": self.reference_target_var,
        }
        for key, variable in mapping.items():
            variable.set(state.parameters[key])
        self.cancel_current_tool(quiet=True)
        if self.spectrum is None:
            self._draw_empty()
            self._clear_results()
        else:
            self._plot_spectrum()
            if self.report is not None:
                self._populate_results()
            else:
                self._clear_results()
        self._update_integral_table()

    def undo(self) -> None:
        current = self._snapshot_state()
        entry = self.history.undo(current, approximate_bytes=self._state_bytes(current))
        if entry is None:
            self._set_status(self.tr.t("status.no_undo"))
            return
        self._restore_state(entry.state)
        self._set_status(self.tr.t("status.undone", label=entry.label))
        self._update_history_controls()

    def redo(self) -> None:
        current = self._snapshot_state()
        entry = self.history.redo(current, approximate_bytes=self._state_bytes(current))
        if entry is None:
            self._set_status(self.tr.t("status.no_redo"))
            return
        self._restore_state(entry.state)
        self._set_status(self.tr.t("status.redone", label=entry.label))
        self._update_history_controls()

    def _update_history_controls(self) -> None:
        try:
            if hasattr(self, "undo_button") and self.undo_button.winfo_exists():
                self.undo_button.configure(state=tk.NORMAL if self.history.can_undo else tk.DISABLED)
            if hasattr(self, "redo_button") and self.redo_button.winfo_exists():
                self.redo_button.configure(state=tk.NORMAL if self.history.can_redo else tk.DISABLED)
            if hasattr(self, "edit_menu"):
                self.edit_menu.entryconfigure(0, state=tk.NORMAL if self.history.can_undo else tk.DISABLED)
                self.edit_menu.entryconfigure(1, state=tk.NORMAL if self.history.can_redo else tk.DISABLED)
        except tk.TclError:
            pass

    def cancel_current_tool(self, *, quiet: bool = False) -> None:
        self.click_mode = None
        self.integral_mode_var.set(False)
        if hasattr(self, "span_selector"):
            self.span_selector.set_active(False)
        if not quiet:
            self._set_status(self.tr.t("status.tool_cancelled"))

    def _guard(self, action: Callable[[], None], label: str) -> None:
        if self._busy:
            return
        self._busy = True
        try:
            self._set_status(label)
            action()
        except Exception as exc:
            self._append_log(self._txt(f"错误：{exc}\n", f"Error: {exc}\n") + traceback.format_exc(limit=5))
            messagebox.showerror(self.tr.t("dialog.operation_failed"), str(exc), parent=self.root)
            self._set_status(self._txt(f"失败：{exc}", f"Failed: {exc}"))
        finally:
            self._busy = False

    def open_file(self) -> None:
        path = filedialog.askopenfilename(
            parent=self.root,
            title=self._txt("打开 NMR 数据", "Open NMR data"),
            filetypes=(
                (self._txt("支持的 NMR 数据", "Supported NMR data"), "fid 1r *.csv *.tsv *.txt *.dx *.jdx *.jcamp"),
                (self._txt("所有文件", "All files"), "*.*"),
            ),
        )
        if path:
            self._load_path(Path(path))

    def open_folder(self) -> None:
        path = filedialog.askdirectory(parent=self.root, title=self._txt("选择 Bruker 实验目录（包含 fid 或 pdata）", "Choose a Bruker experiment directory containing fid or pdata"))
        if path:
            self._load_path(Path(path))

    def _load_path(self, path: Path) -> None:
        def action() -> None:
            data = load_nmr_data(path)
            self._accept_data(data)
            self._set_status(self._txt(f"已载入：{path}", f"Loaded: {path}"))

        self._guard(action, self._txt(f"正在读取 {path.name}…", f"Reading {path.name}…"))

    def _accept_data(self, data: FID1D | Spectrum1D) -> None:
        self._record_operation(self._txt("载入数据", "Load data"))
        self.report = None
        self.manual_peak_positions.clear()
        self.manual_integrals.clear()
        if isinstance(data, FID1D):
            self.raw_fid = data
            self.source_spectrum = None
            self._sync_metadata(data.nucleus, data.solvent, data.spectrometer_mhz)
            self.spectrum = process_fid(data, self._processing_config())
            self.ph0_var.set(f"{self.spectrum.metadata.get('ph0_deg', 0.0):.2f}")
            self.ph1_var.set(f"{self.spectrum.metadata.get('ph1_deg', 0.0):.2f}")
            self.dataset_var.set(
                f"{self.spectrum.title}\n{self.spectrum.nucleus}, {self.spectrum.spectrometer_mhz:.2f} MHz, {self.spectrum.solvent}\n{self.spectrum.metadata.get('format', '')}"
            )
            self._plot_spectrum()
            self._clear_results()
            return
        self.raw_fid = None
        self.source_spectrum = data.copy()
        self.spectrum = data.copy()
        self._sync_metadata(data.nucleus, data.solvent, data.spectrometer_mhz)
        self.dataset_var.set(f"{data.title}\n{data.nucleus}, {data.spectrometer_mhz:.2f} MHz, {data.solvent}\n{data.metadata.get('format', '')}")
        self._plot_spectrum()
        self._clear_results()

    def _sync_metadata(self, nucleus: str, solvent: str, frequency: float) -> None:
        self.nucleus_var.set(nucleus or "1H")
        self.solvent_var.set(solvent or "CDCl3")
        self.frequency_var.set(f"{frequency:.4f}")

    def load_demo(self) -> None:
        self._accept_data(generate_demo_spectrum())
        self.formula_var.set("C4H8O2")
        self.run_analysis()
        self._set_status(self._txt("已载入并分析乙酸乙酯合成演示谱。", "Loaded and interpreted the synthetic ethyl acetate demo spectrum."))

    def _processing_config(self) -> ProcessingConfig:
        return ProcessingConfig(
            apodization=self.apodization_var.get(),
            line_broadening_hz=float(self.lb_var.get()),
            gaussian_broadening_hz=float(self.lb_var.get()),
            zero_fill_factor=int(self.zf_var.get()),
            auto_phase=bool(self.auto_phase_var.get()),
            ph0_deg=float(self.ph0_var.get()),
            ph1_deg=float(self.ph1_var.get()),
            baseline_method=self.baseline_var.get(),
        )

    def process_current(self) -> None:
        if self.raw_fid is None and self.source_spectrum is None:
            messagebox.showinfo(self.tr.t("dialog.no_data_title"), self.tr.t("dialog.no_data_text"), parent=self.root)
            return

        def action() -> None:
            config = self._processing_config()
            self._record_operation(self._txt("谱图处理", "Process spectrum"))
            if self.raw_fid is not None:
                self.spectrum = process_fid(self.raw_fid, config)
                self.source_spectrum = None
                self.ph0_var.set(f"{self.spectrum.metadata.get('ph0_deg', 0.0):.2f}")
                self.ph1_var.set(f"{self.spectrum.metadata.get('ph1_deg', 0.0):.2f}")
            else:
                assert self.source_spectrum is not None
                if config.baseline_method == "none":
                    self.spectrum = self.source_spectrum.copy()
                else:
                    self.spectrum = correct_baseline(self.source_spectrum, config)
            assert self.spectrum is not None
            self.spectrum.nucleus = self.nucleus_var.get().strip() or self.spectrum.nucleus
            self.spectrum.solvent = self.solvent_var.get().strip() or self.spectrum.solvent
            self.spectrum.spectrometer_mhz = float(self.frequency_var.get())
            self.report = None
            self.dataset_var.set(
                f"{self.spectrum.title}\n{self.spectrum.nucleus}, {self.spectrum.spectrometer_mhz:.2f} MHz, {self.spectrum.solvent}\n{self.spectrum.metadata.get('format', '')}"
            )
            self._plot_spectrum()
            self._clear_results()
            self._set_status(self._txt("谱图处理完成；可运行自动解谱。", "Spectrum processing completed; automatic interpretation is available."))

        self._guard(action, self._txt("正在处理谱图（自动相位/基线可能需要数秒）…", "Processing spectrum; automatic phase and baseline may take a few seconds…"))

    def apply_reference(self) -> None:
        if self.spectrum is None:
            messagebox.showinfo(self.tr.t("dialog.no_data_title"), self._txt("请先载入数据。", "Load data first."), parent=self.root)
            return
        try:
            observed = float(self.reference_observed_var.get())
            target = float(self.reference_target_var.get())
            self._record_operation(self._txt("化学位移定标", "Reference chemical shift"))
            self.spectrum = reference_spectrum(self.spectrum, observed, target)
            if self.source_spectrum is not None:
                self.source_spectrum = reference_spectrum(self.source_spectrum, observed, target)
            self.report = None
            self._plot_spectrum()
            self._set_status(self._txt(f"定标完成：整体移动 {target-observed:+.4f} ppm。", f"Referencing completed: global shift {target-observed:+.4f} ppm."))
        except ValueError as exc:
            messagebox.showerror(self._txt("定标失败", "Referencing failed"), str(exc), parent=self.root)

    def load_candidates(self) -> None:
        path = filedialog.askopenfilename(
            parent=self.root,
            title=self._txt("选择候选结构库", "Choose candidate structure library"),
            filetypes=((self._txt("候选库", "Candidate library"), "*.json *.csv *.tsv"), (self._txt("所有文件", "All files"), "*.*")),
        )
        if not path:
            return
        try:
            self.candidates = load_candidate_library(path)
            self.candidate_path = Path(path)
            self.candidate_label.configure(text=self._txt(f"{len(self.candidates)} 个候选\n{Path(path).name}", f"{len(self.candidates)} candidates\n{Path(path).name}"))
            self._set_status(self._txt(f"已载入候选结构库：{len(self.candidates)} 个候选。", f"Loaded candidate library: {len(self.candidates)} candidates."))
        except Exception as exc:
            messagebox.showerror(self._txt("候选库读取失败", "Could not read candidate library"), str(exc), parent=self.root)

    def open_structure_editor(self) -> None:
        """Open one reusable structure-editor window without slowing startup."""

        if self.structure_editor is not None:
            try:
                if self.structure_editor.window.winfo_exists():
                    self.structure_editor.window.deiconify()
                    self.structure_editor.window.lift()
                    self.structure_editor.window.focus_force()
                    return
            except tk.TclError:
                pass
        from .structure_editor import StructureEditorWindow

        self.structure_editor = StructureEditorWindow(
            self.root,
            language=self.settings.language,
            experimental_report_provider=lambda: self.report,
        )
        self._set_status(self._txt("结构画板已打开：编辑结构后可自动预测 1H、13C、31P 或 19F。", "Structure editor opened; editing can automatically predict 1H, 13C, 31P or 19F."))

    def open_database_window(self) -> None:
        if self.database_window is not None:
            try:
                if self.database_window.window.winfo_exists():
                    self.database_window.window.deiconify()
                    self.database_window.window.lift()
                    return
            except tk.TclError:
                pass
        try:
            from .database_ui import DatabaseWindow

            self.database_window = DatabaseWindow(self.root, self.tr)
            self._set_status(self._txt("数据库关联窗口已打开。", "Database connections opened."))
        except Exception as exc:
            messagebox.showerror(self.tr.t("database.title"), str(exc), parent=self.root)

    def _get_account_store(self) -> AccountStore:
        if self.account_store is None:
            self.account_store = AccountStore()
        return self.account_store

    def open_account_window(self) -> None:
        if self.account_window is not None:
            try:
                if self.account_window.window.winfo_exists():
                    self.account_window.window.deiconify()
                    self.account_window.window.lift()
                    return
            except tk.TclError:
                pass
        try:
            from .account_ui import AccountWindow

            self.account_window = AccountWindow(
                self.root,
                self.tr,
                self._get_account_store(),
                self.current_user,
                self._accept_session,
                self._password_changed,
            )
        except Exception as exc:
            messagebox.showerror(self.tr.t("account.title"), str(exc), parent=self.root)

    def _accept_session(self, session: Session) -> None:
        self.current_session = session
        self.current_user = session.user
        self.account_label_var.set(f"{session.user.username} · {session.user.role}")
        self._set_status(self._txt(f"已登录本地账号：{session.user.username}", f"Signed in locally as {session.user.username}"))

    def _password_changed(self) -> None:
        self.current_session = None
        self.current_user = None
        self.account_label_var.set(self.tr.t("account.guest"))

    def logout(self) -> None:
        if self.current_session is not None and self.account_store is not None:
            self.account_store.revoke_session(self.current_session.token)
        self.current_session = None
        self.current_user = None
        self.account_label_var.set(self.tr.t("account.guest"))
        self._set_status(self._txt("已退出本地账号。", "Signed out of the local account."))

    def set_language(self, language: str) -> None:
        if language not in SUPPORTED_LANGUAGES or language == self.settings.language:
            return
        self.settings.language = language
        save_settings(self.settings)
        self.tr = Translator(language)
        self.language_var.set(language)
        plot_font = configure_matplotlib_fonts(language)
        self.plot_language = (
            "en_US"
            if language == "zh_CN" and not matplotlib_font_supports_cjk(plot_font)
            else language
        )
        self.plot_tr = Translator(self.plot_language)
        self.root.option_add("*Font", (preferred_ui_font(), 10))
        self.root.title(self.tr.t("app.title"))
        for widget in list(self.root.winfo_children()):
            if not isinstance(widget, tk.Toplevel):
                widget.destroy()
        self._configure_style()
        self._build_menu()
        self._build_layout()
        self.account_label_var.set(
            f"{self.current_user.username} · {self.current_user.role}"
            if self.current_user is not None
            else self.tr.t("account.guest")
        )
        if self.spectrum is None:
            self.dataset_var.set(self.tr.t("app.no_data"))
            self._draw_empty()
            self._clear_results()
        else:
            self._plot_spectrum()
            if self.report is not None:
                self._populate_results()
        self._update_history_controls()
        self._set_status(self.tr.t("language.changed"))

    def close_app(self) -> None:
        if self.account_store is not None:
            self.account_store.close()
            self.account_store = None
        self.root.destroy()

    def run_analysis(self) -> None:
        if self.spectrum is None:
            messagebox.showinfo(self.tr.t("dialog.no_data_title"), self.tr.t("dialog.no_data_text"), parent=self.root)
            return

        def action() -> None:
            assert self.spectrum is not None
            self.spectrum.nucleus = self.nucleus_var.get().strip() or "1H"
            self.spectrum.solvent = self.solvent_var.get().strip() or "CDCl3"
            self.spectrum.spectrometer_mhz = float(self.frequency_var.get())
            config = AnalysisConfig(
                snr_threshold=float(self.snr_var.get()),
                group_gap_hz=float(self.group_gap_var.get()),
                molecular_formula=self.formula_var.get().strip(),
                include_demo_candidates=self.candidates is None,
            )
            self._record_operation(self._txt("自动解谱", "Automatic interpretation"))
            self.report = analyze_spectrum(
                self.spectrum,
                config,
                candidates=self.candidates,
                manual_peak_positions=self.manual_peak_positions,
                manual_integrals=self.manual_integrals,
            )
            self._plot_spectrum()
            self._populate_results()
            top = self.report.candidates[0] if self.report.candidates else None
            suffix = self._txt(f"；最高候选 {top.name} {top.score:.1f}/100", f"; top candidate {top.name} {top.score:.1f}/100") if top else ""
            self._set_status(
                self._txt(f"自动解谱完成：{len(self.report.signals)} 个信号，质量 {self.report.quality_score:.0f}/100{suffix}。", f"Interpretation completed: {len(self.report.signals)} signals; quality {self.report.quality_score:.0f}/100{suffix}.")
            )

        self._guard(action, self._txt("正在自动寻峰、归组、积分并评分候选…", "Picking and grouping peaks, integrating, and scoring candidates…"))

    def _draw_empty(self) -> None:
        self.axes.clear()
        self.axes.text(
            0.5,
            0.54,
            self.plot_tr.t("app.welcome"),
            transform=self.axes.transAxes,
            ha="center",
            va="center",
            fontsize=22,
            color="#265d68",
        )
        self.axes.text(
            0.5,
            0.44,
            self.plot_tr.t("app.welcome_hint"),
            transform=self.axes.transAxes,
            ha="center",
            va="center",
            color="#64748b",
        )
        self.axes.set_axis_off()
        self.canvas.draw_idle()

    def _plot_spectrum(self) -> None:
        if self.spectrum is None:
            self._draw_empty()
            return
        x, y = self.spectrum.ppm, self.spectrum.intensity
        self.axes.clear()
        self.axes.plot(x, y, color="#111827", linewidth=0.75)
        self.axes.axhline(0.0, color="#94a3b8", linewidth=0.5)
        self.axes.set_xlim(float(np.max(x)), float(np.min(x)))
        low = float(np.percentile(y, 0.1))
        high = float(np.percentile(y, 99.85))
        span = max(high - low, np.finfo(float).eps)
        self.axes.set_ylim(low - 0.06 * span, high + 0.18 * span)
        self.axes.set_xlabel("δ / ppm")
        self.axes.set_ylabel("强度" if self.plot_language == "zh_CN" else "Intensity")
        self.axes.set_title(self.spectrum.title, loc="left", fontsize=11)
        self.axes.spines[["top", "right"]].set_visible(False)
        self.axes.grid(axis="x", color="#e2e8f0", linewidth=0.5, alpha=0.8)
        if self.report is not None:
            peak_y = []
            peak_x = []
            for signal in self.report.signals:
                index = int(np.argmin(np.abs(x - signal.center_ppm)))
                peak_x.append(signal.center_ppm)
                peak_y.append(y[index])
                self.axes.annotate(
                    f"{signal.center_ppm:.3f}\n{signal.multiplicity}",
                    xy=(signal.center_ppm, y[index]),
                    xytext=(0, 12),
                    textcoords="offset points",
                    ha="center",
                    va="bottom",
                    fontsize=7,
                    color="#9a3412",
                    rotation=55,
                )
            if peak_x:
                self.axes.scatter(peak_x, peak_y, s=16, color="#c2410c", zorder=5)
        for position in self.manual_peak_positions:
            self.axes.axvline(position, color="#7c3aed", linewidth=0.8, linestyle="--", alpha=0.8)
        for integral in self.manual_integrals:
            self.axes.axvspan(integral["low_ppm"], integral["high_ppm"], color="#f59e0b", alpha=0.12)
        self.figure.tight_layout(pad=1.4)
        self.canvas.draw_idle()

    def set_click_mode(self, mode: str | None) -> None:
        self.click_mode = mode
        if mode == "add":
            self._set_status(self._txt("手动加峰模式：单击谱图添加一个峰。", "Manual peak tool: click the spectrum to add a peak."))
        elif mode == "remove":
            self._set_status(self._txt("删除最近峰模式：单击谱图，删除最近的手动峰。", "Remove peak tool: click the spectrum to remove the nearest manual peak."))
        else:
            self._set_status(self._txt("手动峰模式已关闭。", "Manual peak tool is off."))

    def _on_plot_click(self, event) -> None:
        if self.spectrum is None or event.inaxes is not self.axes or event.xdata is None:
            return
        if self.click_mode == "add":
            position = float(event.xdata)
            index = int(np.argmin(np.abs(self.spectrum.ppm - position)))
            snapped = float(self.spectrum.ppm[index])
            if all(abs(snapped - old) > self.spectrum.ppm_step for old in self.manual_peak_positions):
                self._record_operation(self._txt("添加手动峰", "Add manual peak"))
                self.manual_peak_positions.append(snapped)
                self.manual_peak_positions.sort(reverse=True)
                self._set_status(self._txt(f"已添加手动峰 δ {snapped:.4f} ppm；重新自动解谱后纳入归组。", f"Added manual peak δ {snapped:.4f} ppm; rerun interpretation to include it."))
                self._plot_spectrum()
        elif self.click_mode == "remove" and self.manual_peak_positions:
            nearest = min(self.manual_peak_positions, key=lambda value: abs(value - float(event.xdata)))
            self._record_operation(self._txt("删除手动峰", "Remove manual peak"))
            self.manual_peak_positions.remove(nearest)
            self._set_status(self._txt(f"已删除手动峰 δ {nearest:.4f} ppm。", f"Removed manual peak δ {nearest:.4f} ppm."))
            self._plot_spectrum()

    def toggle_integral_mode(self) -> None:
        active = bool(self.integral_mode_var.get())
        self.span_selector.set_active(active)
        self.click_mode = None if active else self.click_mode
        self._set_status(
            self._txt("框选积分模式：在谱图上横向拖动选择积分区间。", "Integration tool: drag horizontally on the spectrum to select a region.")
            if active
            else self._txt("框选积分模式已关闭。", "Integration tool is off.")
        )

    def activate_integral_mode(self) -> None:
        self.integral_mode_var.set(not bool(self.integral_mode_var.get()))
        self.toggle_integral_mode()

    def _on_integral_span(self, xmin: float, xmax: float) -> None:
        if self.spectrum is None:
            return
        low, high = sorted((float(xmin), float(xmax)))
        mask = (self.spectrum.ppm >= low) & (self.spectrum.ppm <= high)
        if mask.sum() < 2:
            return
        area = float(abs(np.trapezoid(np.clip(self.spectrum.intensity[mask], 0.0, None), self.spectrum.ppm[mask])))
        self._record_operation(self._txt("添加积分区间", "Add integration region"))
        self.manual_integrals.append({"high_ppm": high, "low_ppm": low, "area": area})
        self._update_integral_table()
        self._plot_spectrum()
        self._set_status(self._txt(f"已积分 δ {high:.3f}–{low:.3f} ppm，面积 {area:.4g}。", f"Integrated δ {high:.3f}–{low:.3f} ppm; area {area:.4g}."))

    def clear_manual_integrals(self) -> None:
        if not self.manual_integrals:
            return
        self._record_operation(self._txt("清空手动积分", "Clear manual integrals"))
        self.manual_integrals.clear()
        self._update_integral_table()
        self._plot_spectrum()

    def clear_manual_annotations(self) -> None:
        if not self.manual_peak_positions and not self.manual_integrals:
            return
        self._record_operation(self._txt("清空手动标记", "Clear manual annotations"))
        self.manual_peak_positions.clear()
        self.manual_integrals.clear()
        self.click_mode = None
        self.integral_mode_var.set(False)
        self.span_selector.set_active(False)
        self._update_integral_table()
        self._plot_spectrum()
        self._set_status(self._txt("手动峰与手动积分已清空。", "Manual peaks and integrals were cleared."))

    def _clear_results(self) -> None:
        for tree in (self.signal_tree, self.fragment_tree, self.candidate_tree):
            tree.delete(*tree.get_children())
        self._replace_log("")
        self._update_integral_table()

    def _populate_results(self) -> None:
        assert self.report is not None
        self._clear_results()
        for index, signal in enumerate(self.report.signals, 1):
            reference = signal.reference_match.name if signal.reference_match else ""
            self.signal_tree.insert(
                "",
                tk.END,
                values=(
                    index,
                    f"{signal.center_ppm:.3f}",
                    signal.multiplicity,
                    f"{signal.relative_integral:.2f}",
                    "" if signal.estimated_protons is None else f"{signal.estimated_protons:.2f}",
                    ", ".join(f"{j:.1f}" for j in signal.coupling_hz),
                    domain_text(signal.region, self.tr.language),
                    domain_text(reference, self.tr.language),
                    f"{signal.confidence:.0f}",
                ),
            )
        for item in self.report.fragments:
            self.fragment_tree.insert(
                "",
                tk.END,
                values=(domain_text(item.label, self.tr.language), domain_text(item.evidence, self.tr.language), ", ".join(str(i + 1) for i in item.signal_indices), f"{item.confidence:.0f}"),
            )
        for rank, item in enumerate(self.report.candidates, 1):
            self.candidate_tree.insert(
                "",
                tk.END,
                values=(
                    rank,
                    item.name,
                    f"{item.score:.1f}",
                    f"{item.matched}/{item.expected}",
                    "" if item.shift_rmse is None else f"{item.shift_rmse:.3f}",
                    item.formula,
                    item.smiles,
                ),
            )
        details = self._txt(
            [f"谱图质量：{self.report.quality_score:.0f}/100", f"噪声 σ：{self.report.noise_sigma:.4g}"],
            [f"Spectrum quality: {self.report.quality_score:.0f}/100", f"Noise σ: {self.report.noise_sigma:.4g}"],
        )
        details.extend(f"• {domain_text(warning, self.tr.language)}" for warning in self.report.warnings)
        if self.report.candidates:
            details.append(self._txt("\n最高候选评分依据：", "\nEvidence for the top candidate score:"))
            details.extend(f"• {domain_text(line, self.tr.language)}" for line in self.report.candidates[0].explanation)
        self._replace_log("\n".join(details))
        self._update_integral_table()

    def _update_integral_table(self) -> None:
        self.integral_tree.delete(*self.integral_tree.get_children())
        if not self.manual_integrals:
            return
        smallest = min((item["area"] for item in self.manual_integrals if item["area"] > 0), default=1.0)
        for index, item in enumerate(self.manual_integrals, 1):
            self.integral_tree.insert(
                "",
                tk.END,
                values=(
                    index,
                    f"{item['high_ppm']:.3f}",
                    f"{item['low_ppm']:.3f}",
                    f"{item['area']:.5g}",
                    f"{item['area']/smallest:.2f}",
                ),
            )

    def _replace_log(self, text: str) -> None:
        self.log_text.configure(state=tk.NORMAL)
        self.log_text.delete("1.0", tk.END)
        self.log_text.insert(tk.END, text)
        self.log_text.configure(state=tk.DISABLED)

    def _append_log(self, text: str) -> None:
        self.log_text.configure(state=tk.NORMAL)
        self.log_text.insert(tk.END, ("\n" if self.log_text.index("end-1c") != "1.0" else "") + text)
        self.log_text.configure(state=tk.DISABLED)

    def save_processed_csv(self) -> None:
        if self.spectrum is None:
            messagebox.showinfo(self.tr.t("dialog.no_data_title"), self._txt("请先载入并处理数据。", "Load and process data first."), parent=self.root)
            return
        path = filedialog.asksaveasfilename(
            parent=self.root,
            title=self._txt("保存处理后谱图", "Save processed spectrum"),
            defaultextension=".csv",
            filetypes=(("CSV", "*.csv"),),
        )
        if path:
            save_spectrum_csv(self.spectrum, path)
            self._set_status(self._txt(f"已保存处理后谱图：{path}", f"Saved processed spectrum: {path}"))

    def export_report(self) -> None:
        if self.spectrum is None:
            messagebox.showinfo(self.tr.t("dialog.no_data_title"), self._txt("请先载入数据。", "Load data first."), parent=self.root)
            return
        if self.report is None:
            self.run_analysis()
            if self.report is None:
                return
        path = filedialog.asksaveasfilename(
            parent=self.root,
            title=self._txt("导出自动解谱报告", "Export interpretation report"),
            defaultextension=".html",
            filetypes=((self._txt("HTML 报告", "HTML report"), "*.html"), (self._txt("JSON 数据", "JSON data"), "*.json")),
        )
        if path:
            assert self.report is not None
            write_report(self.report, self.spectrum, path)
            self._set_status(self._txt(f"报告已导出：{path}", f"Report exported: {path}"))
            if Path(path).suffix.lower() == ".html" and messagebox.askyesno(self._txt("导出完成", "Export completed"), self._txt("是否在浏览器中打开报告？", "Open the report in a browser?"), parent=self.root):
                webbrowser.open(Path(path).resolve().as_uri())

    def show_about(self) -> None:
        messagebox.showinfo(
            self.tr.t("dialog.about_title"),
            f"Open NMR Workbench {__version__}\n\n"
            + self._txt(
                "面向有机合成研究的一维 NMR 处理、结构画板与可解释预测工作台。\n\n"
                "自动解谱给出信号、积分、多重性、J 值、常见参考物、片段提示以及候选结构一致性得分。"
                "结构画板可预测 1H、13C、31P 与 19F，并显示经验不确定度。"
                "它不能仅凭一张 1H 谱唯一证明未知结构；关键结论仍应结合 13C、二维 NMR、HRMS 与实验背景复核。",
                "A workbench for one-dimensional NMR processing, structure drawing, explainable interpretation and 1H/13C/31P/19F prediction.\n\n"
                "Automatic interpretation reports signals, integrals, multiplicities, J values, common references, fragment evidence and candidate consistency. "
                "A single 1H spectrum cannot uniquely prove an arbitrary unknown structure; confirm critical conclusions with 13C, 2D NMR, HRMS and experimental context.",
            ),
            parent=self.root,
        )


def launch() -> None:
    root = tk.Tk()
    NMRWorkbenchApp(root)
    root.mainloop()


if __name__ == "__main__":
    launch()
