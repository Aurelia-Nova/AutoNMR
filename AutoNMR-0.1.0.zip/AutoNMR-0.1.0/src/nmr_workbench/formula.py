from __future__ import annotations

import re
from collections import defaultdict


_TOKEN = re.compile(r"([A-Z][a-z]?|\(|\)|\d+|[·.])")


def parse_formula(formula: str) -> dict[str, int]:
    """Parse a conventional molecular formular, including simple parentheses."""
    cleaned = re.sub(r"\s+|[+-]\d*$|\d*[+-]$", "", formula.strip())
    if not cleaned:
        return {}
    tokens = _TOKEN.findall(cleaned)
    if "".join(tokens) != cleaned:
        raise ValueError(f"无法解析分子式：{formula}")
    stack: list[dict[str, int]] = [defaultdict(int)]
    i = 0
    while i < len(tokens):
        token = tokens[i]
        if token in {"·", "."}:
            i += 1
            continue
        if token == "(":
            stack.append(defaultdict(int))
            i += 1
            continue
        if token == ")":
            if len(stack) == 1:
                raise ValueError(f"分子式括号不匹配：{formula}")
            group = stack.pop()
            multiplier = 1
            if i + 1 < len(tokens) and tokens[i + 1].isdigit():
                multiplier = int(tokens[i + 1])
                i += 1
            for element, count in group.items():
                stack[-1][element] += count * multiplier
            i += 1
            continue
        if token.isdigit():
            # Leading hydrate coefficient (e.g. 5H2O) is uncommon in analyte
            # formulas.  Apply it to the following element/group when possible.
            if i == 0 or tokens[i - 1] in {"·", "."}:
                multiplier = int(token)
                if i + 1 >= len(tokens) or not re.match(r"[A-Z]", tokens[i + 1]):
                    raise ValueError(f"无法解析分子式系数：{formula}")
                element = tokens[i + 1]
                count = 1
                if i + 2 < len(tokens) and tokens[i + 2].isdigit():
                    count = int(tokens[i + 2])
                    i += 1
                stack[-1][element] += multiplier * count
                i += 2
                continue
            raise ValueError(f"分子式中出现孤立数字：{formula}")
        element = token
        count = 1
        if i + 1 < len(tokens) and tokens[i + 1].isdigit():
            count = int(tokens[i + 1])
            i += 1
        stack[-1][element] += count
        i += 1
    if len(stack) != 1:
        raise ValueError(f"分子式括号不匹配：{formula}")
    return dict(stack[0])


def hydrogen_count(formula: str) -> int | None:
    if not formula.strip():
        return None
    return parse_formula(formula).get("H", 0)


def degree_of_unsaturation(formula: str) -> float | None:
    if not formula.strip():
        return None
    atoms = parse_formula(formula)
    carbon = atoms.get("C", 0)
    hydrogen = atoms.get("H", 0)
    nitrogen = atoms.get("N", 0)
    halogens = sum(atoms.get(x, 0) for x in ("F", "Cl", "Br", "I"))
    return 1.0 + carbon + 0.5 * nitrogen - 0.5 * (hydrogen + halogens)


def formulas_equal(left: str, right: str) -> bool:
    if not left.strip() or not right.strip():
        return False
    return parse_formula(left) == parse_formula(right)

