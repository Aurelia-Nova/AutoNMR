# Open NMR Workbench 0.1 

Bruker 一维 NMR 能运行，同时在增加 JEOL、Agilent/Varian、二维 NMR、质谱、数据驱动预测器或增加其它功能时，不推翻已有界面和数据模型。

## 稳定边界

层、当前能实现及后续扩展方式

自动解谱层能寻峰、归组、积分、参考物、片段、候选评分，后续增加 2D 交叉峰图、混合物去卷积和有版本的推理后端
结构预测支持`PredictionBackendRegistry` + `PredictionRequest`，后续加入HOSE/ML/DFT/数据库服务实现 `PredictionBackend`，可注册 `open_nmr_workbench.predictors` 
当前数据库—— `DatabaseProfile`、`DatabaseConnector` 。浏览器模板不保存凭据，API/OAuth 连接器独立实现
当前账号——本地 `AccountStore`；`AuthBackend` 协议，后续更高级版本版替换为 TLS 服务端、MFA、RBAC 与组织租户
当前版本能力，`EditionPolicy`、`EntitlementProvider`，签名许可或服务端权益只决定功能可用性，不混入科学算法
UI(>^ω^<)喵 Tk 主工作台、结构画板、数据库/账号窗口，UI 调用协议和标准模型，不直接解析厂商二进制或数据库响应

## 新仪器与新谱种

读取器首先声明 `ReaderInfo(id, name, modality, vendor, priority, extensions)`，再实现 `can_read(path)` 和 `read(path)`。例如 JEOL NMR reader 的 `modality` 为 `nmr`、vendor 为 `JEOL`；mzML reader 的 `modality` 为 `mass_spectrometry`。注册表按优先级探测，同一文件可由多个插件尝试，错误彼此隔离。

质谱扩展不应复用 NMR 的 ppm、相位或积分语义。增加 `MassSpectrum`（m/z、intensity、polarity、ionization、collision energy）及独立处理/指认管线，只复用项目、数据库、账号、报告和插件基础设施。

## 高精度预测与自动解谱

当前 `open-rule-v0.1` 是离线可解释基线。更高精度后端必须返回相同的 `PredictionResult`，并记录：模型 ID/版本、训练数据版本、核种、溶剂、温度、浓度、每峰不确定度和适用域警告。实验谱验证层独立于预测层，以匈牙利算法进行一对一指派，避免模型自己给自己评分。

未来推理待定：谱图质量/杂质分离 → 1D/2D 约束图 → 候选生成或检索 → 预测谱与所有实验约束联合评分，任何结果都保留峰、交叉峰、原子和评分项之间的证据链。

## 兼容性原则

- 已发布 JSON 中的字段只增不删；新增字段提供默认值并带 `schema_version`。
- 插件 ID、模型 ID 和数据库 profile ID 稳定，显示名称可以翻译。
