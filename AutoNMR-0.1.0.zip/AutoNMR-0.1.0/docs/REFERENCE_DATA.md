# 氘代溶剂参考数据

0.1.0 的 `deuterated_solvents.json` 收录 12 种溶剂在约 298 K 条件下的 `1H`/`13C` 残余溶剂信号和水峰：THF-d8、CD2Cl2、CDCl3、toluene-d8、C6D6、C6D5Cl、acetone-d6、DMSO-d6、CD3CN、TFE-d3、CD3OD、D2O

主要依据本次提供的正文和 Supporting Information：

- Fulmer, G. R. et al. *Organometallics* **2010**, 29, 2176–2179. DOI `10.1021/om100106e`。
- Fulmer et al. Supporting Information，Table S1，`1H` 与 `13C` 数据。
- 与既有 Gottlieb, H. E.; Kotlyar, V.; Nudelman, A. *J. Org. Chem.* **1997**, 62, 7512–7515，DOI `10.1021/jo971176v` 数据合并。

这些数值用于定标候选和排除残余溶剂/水/常见杂质。实际位移会随温度、浓度、含水量、pH/pD、配位和定标方式变化，软件匹配使用容差，单个匹配不能作为化合物鉴定证据。D2O 的 HOD 只保留一个水峰条目，避免同时作为溶剂残峰重复计数。
