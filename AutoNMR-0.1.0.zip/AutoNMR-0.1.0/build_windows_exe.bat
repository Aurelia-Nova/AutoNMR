@echo off
setlocal EnableExtensions
chcp 65001 >nul 2>&1
set "APP_DIR=%~dp0"
set "VENV_PYTHON=%APP_DIR%.venv\Scripts\python.exe"

if not exist "%VENV_PYTHON%" (
  echo Please run install_windows.bat first.
  pause
  exit /b 1
)
"%VENV_PYTHON%" -I -m pip install "pyinstaller>=6.15,<7"
if errorlevel 1 goto :failed
"%VENV_PYTHON%" -I -m PyInstaller --noconfirm --clean --windowed --name OpenNMRWorkbench --paths "%APP_DIR%src" --collect-data nmr_workbench --collect-all rdkit --distpath "%APP_DIR%dist" --workpath "%APP_DIR%build" --specpath "%APP_DIR%" "%APP_DIR%launcher.py"
if errorlevel 1 goto :failed
echo.
echo Build completed: "%APP_DIR%dist\OpenNMRWorkbench\OpenNMRWorkbench.exe"
pause
exit /b 0

:failed
echo.
echo [ERROR] Build failed. See the message above.
pause
exit /b 1
