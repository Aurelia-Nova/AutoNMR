# Third-party notices

Open NMR Workbench 的自身源码采用 MIT 许可证。安装或打包时还会使用下列独立开源依赖；其版权与许可由各项目保留：

- NumPy — BSD-3-Clause
- SciPy — BSD-3-Clause
- Matplotlib — PSF-based license
- RDKit — BSD-3-Clause
- Pillow（RDKit 运行依赖）— HPND
- PyInstaller（仅构建可执行程序时）— GPL-2.0-or-later with a special exception for bundled applications

本文件是方便用户定位依赖许可的摘要，不替代各软件包随附的完整许可证。发布独立 EXE 时，应保留 PyInstaller 生成目录和依赖包内的许可证/元数据，并按各项目要求分发相应通知。
