param(
    [string]$LogPath = "",
    [switch]$InstallIfMissing
)

$ErrorActionPreference = "SilentlyContinue"
$ProgressPreference = "SilentlyContinue"
$candidates = New-Object System.Collections.Generic.List[string]
$managerPaths = New-Object System.Collections.Generic.List[string]
$modernManagerPaths = New-Object System.Collections.Generic.List[string]
$logLines = New-Object System.Collections.Generic.List[string]

function Add-Log {
    param([string]$Message)
    $script:logLines.Add($Message)
}

function Resolve-ExecutablePath {
    param([string]$Path)
    if ([string]::IsNullOrWhiteSpace($Path)) {
        return $null
    }
    $expanded = [Environment]::ExpandEnvironmentVariables($Path.Trim().Trim('"'))
    if (-not (Test-Path -LiteralPath $expanded -PathType Leaf)) {
        return $null
    }
    return (Resolve-Path -LiteralPath $expanded).Path
}

function Add-Candidate {
    param([string]$Path)
    $resolved = Resolve-ExecutablePath $Path
    if ($resolved -and -not $script:candidates.Contains($resolved)) {
        $script:candidates.Add($resolved)
    }
}

function Add-ManagerPath {
    param([string]$Path)
    $resolved = Resolve-ExecutablePath $Path
    if ($resolved -and -not $script:managerPaths.Contains($resolved)) {
        $script:managerPaths.Add($resolved)
        Add-Log "MANAGER FOUND: $resolved"
    }
}

function Add-ModernManagerPath {
    param([string]$Path)
    if ($Path -and -not $script:modernManagerPaths.Contains($Path)) {
        $script:modernManagerPaths.Add($Path)
    }
}

function Invoke-Manager {
    param(
        [string]$Path,
        [string[]]$Arguments,
        [string]$Label
    )
    try {
        Add-Log "MANAGER COMMAND: $Path $($Arguments -join ' ')"
        $output = @(& $Path @Arguments 2>&1)
        $exitCode = $LASTEXITCODE
        foreach ($line in $output) {
            Add-Log "  $([string]$line)"
        }
        Add-Log "$Label exit code: $exitCode"
        return [PSCustomObject]@{
            ExitCode = $exitCode
            Output = $output
        }
    } catch {
        Add-Log "$Label failed: $($_.Exception.Message)"
        return [PSCustomObject]@{
            ExitCode = -1
            Output = @()
        }
    }
}

function Add-CommandCandidates {
    foreach ($name in @("python3.14.exe", "python3.exe", "python.exe")) {
        Get-Command $name -All -CommandType Application | ForEach-Object {
            Add-Candidate $_.Source
        }
    }
}

function Add-ManagerCommands {
    foreach ($name in @("pymanager.exe", "pymanager", "py.exe", "py")) {
        Get-Command $name -All -CommandType Application | ForEach-Object {
            Add-ManagerPath $_.Source
        }
    }

    $windowsApps = "$env:LOCALAPPDATA\Microsoft\WindowsApps"
    foreach ($name in @("pymanager.exe", "py.exe")) {
        Add-ManagerPath (Join-Path $windowsApps $name)
    }
    if (Test-Path -LiteralPath $windowsApps -PathType Container) {
        Get-ChildItem -LiteralPath $windowsApps -Directory -Filter "PythonSoftwareFoundation.PythonManager_*" | ForEach-Object {
            foreach ($name in @("pymanager.exe", "py.exe")) {
                Add-ManagerPath (Join-Path $_.FullName $name)
            }
        }
    }
}

function Add-RuntimesFromManagers {
    foreach ($manager in $script:managerPaths) {
        $listResult = Invoke-Manager $manager @("list", "--format=exe") "modern manager list"
        if ($listResult.ExitCode -eq 0) {
            Add-ModernManagerPath $manager
            foreach ($line in $listResult.Output) {
                Add-Candidate ([string]$line)
            }
        }

        $legacyResult = Invoke-Manager $manager @("-0p") "legacy launcher list"
        foreach ($line in $legacyResult.Output) {
            $text = [string]$line
            if ($text -match '([A-Za-z]:\\.*?python(?:w|3(?:\.\d+)?)?\.exe)\s*$') {
                Add-Candidate $Matches[1]
            }
        }
    }
}

function Add-RegistryCandidates {
    foreach ($root in @(
        "HKCU:\Software\Python",
        "HKLM:\Software\Python",
        "HKLM:\Software\WOW6432Node\Python"
    )) {
        if (-not (Test-Path -LiteralPath $root)) {
            continue
        }
        Get-ChildItem -LiteralPath $root -Recurse | Where-Object {
            $_.PSChildName -eq "InstallPath"
        } | ForEach-Object {
            $key = Get-Item -LiteralPath $_.PSPath
            $executable = $key.GetValue("ExecutablePath")
            if ($executable) {
                Add-Candidate $executable
            }
            $prefix = $key.GetValue("")
            if ($prefix) {
                Add-Candidate (Join-Path $prefix "python.exe")
                Add-Candidate (Join-Path $prefix "python3.14.exe")
            }
        }
    }
}

function Add-FileSystemCandidates {
    foreach ($path in @(
        $env:OPEN_NMR_PYTHON,
        (Join-Path $PSScriptRoot "python_path.txt"),
        "$env:LOCALAPPDATA\Python\bin\python3.14.exe",
        "$env:LOCALAPPDATA\Python\bin\python.exe",
        "$env:LOCALAPPDATA\Programs\Python\Python314\python.exe",
        "$env:ProgramW6432\Python314\python.exe",
        "$env:ProgramW6432\Python 3.14\python.exe",
        "$env:SystemDrive\Python314\python.exe"
    )) {
        if ($path -and $path.EndsWith("python_path.txt") -and (Test-Path -LiteralPath $path)) {
            Add-Candidate (Get-Content -LiteralPath $path -TotalCount 1)
        } else {
            Add-Candidate $path
        }
    }

    foreach ($root in @(
        "$env:LOCALAPPDATA\Python",
        "$env:LOCALAPPDATA\Programs\Python"
    )) {
        if (Test-Path -LiteralPath $root -PathType Container) {
            Get-ChildItem -LiteralPath $root -Recurse -File -Filter "python.exe" | ForEach-Object {
                Add-Candidate $_.FullName
            }
            Get-ChildItem -LiteralPath $root -Recurse -File -Filter "python3.14.exe" | ForEach-Object {
                Add-Candidate $_.FullName
            }
        }
    }

    foreach ($programRoot in @($env:ProgramW6432, $env:ProgramFiles)) {
        if (-not (Test-Path -LiteralPath $programRoot -PathType Container)) {
            continue
        }
        Get-ChildItem -LiteralPath $programRoot -Directory -Filter "Python*" | ForEach-Object {
            Add-Candidate (Join-Path $_.FullName "python.exe")
        }
    }

    $windowsApps = "$env:LOCALAPPDATA\Microsoft\WindowsApps"
    if (Test-Path -LiteralPath $windowsApps -PathType Container) {
        Get-ChildItem -LiteralPath $windowsApps -File -Filter "python*.exe" | ForEach-Object {
            Add-Candidate $_.FullName
        }
        Get-ChildItem -LiteralPath $windowsApps -Directory -Filter "PythonSoftwareFoundation.PythonManager_*" | ForEach-Object {
            foreach ($name in @("python.exe", "python3.14.exe")) {
                Add-Candidate (Join-Path $_.FullName $name)
            }
        }
    }
}

function Test-Candidate {
    param([string]$Path)
    $process = New-Object System.Diagnostics.Process
    $process.StartInfo = New-Object System.Diagnostics.ProcessStartInfo
    $process.StartInfo.FileName = $Path
    $process.StartInfo.Arguments = '-I -c "import sys,venv,ensurepip,tkinter;print(str(sys.version_info.major)+''.''+str(sys.version_info.minor)+''.''+str(sys.version_info.micro)+''|''+str(64 if sys.maxsize>2**32 else 32))"'
    $process.StartInfo.UseShellExecute = $false
    $process.StartInfo.CreateNoWindow = $true
    $process.StartInfo.RedirectStandardOutput = $true
    $process.StartInfo.RedirectStandardError = $true
    try {
        if (-not $process.Start()) {
            Add-Log "REJECTED (could not start): $Path"
            return $null
        }
        if (-not $process.WaitForExit(15000)) {
            $process.Kill()
            Add-Log "REJECTED (timeout): $Path"
            return $null
        }
        $output = $process.StandardOutput.ReadToEnd().Trim()
        $errorOutput = $process.StandardError.ReadToEnd().Trim()
        if ($process.ExitCode -ne 0 -or $output -notmatch '^(3\.\d+\.\d+)\|(32|64)$') {
            Add-Log "REJECTED (exit $($process.ExitCode)): $Path :: $errorOutput"
            return $null
        }
        $version = [Version]$Matches[1]
        $bits = [int]$Matches[2]
        if ($version.Major -ne 3 -or $version.Minor -lt 10 -or $version.Minor -gt 14 -or $bits -ne 64) {
            Add-Log "REJECTED (Python $version, $bits-bit): $Path"
            return $null
        }
        Add-Log "ACCEPTED (Python $version, $bits-bit): $Path"
        return [PSCustomObject]@{
            Path = $Path
            Version = $version
        }
    } catch {
        Add-Log "REJECTED ($($_.Exception.Message)): $Path"
        return $null
    } finally {
        $process.Dispose()
    }
}

function Get-SelectedCandidate {
    $valid = foreach ($candidate in $script:candidates) {
        Test-Candidate $candidate
    }
    return $valid | Sort-Object -Property @{Expression = {$_.Version}; Descending = $true} | Select-Object -First 1
}

function Save-DetectionLog {
    if (-not $LogPath) {
        return
    }
    @(
        "Open NMR Workbench Python detection"
        "Generated: $(Get-Date -Format o)"
        "Automatic repair/install requested: $([bool]$InstallIfMissing)"
        "Python candidates found: $($script:candidates.Count)"
        "Manager commands found: $($script:managerPaths.Count)"
        ""
    ) + $script:logLines | Set-Content -LiteralPath $LogPath -Encoding UTF8
}

Add-FileSystemCandidates
Add-CommandCandidates
Add-ManagerCommands
Add-RuntimesFromManagers
Add-RegistryCandidates

$selected = Get-SelectedCandidate

if (-not $selected -and $InstallIfMissing) {
    if ($modernManagerPaths.Count -eq 0) {
        Add-Log "AUTOMATIC REPAIR SKIPPED: no working modern Python Install Manager command was found."
    } else {
        Add-Log "AUTOMATIC REPAIR: refreshing runtime registrations and aliases."
        foreach ($manager in $modernManagerPaths) {
            $refreshResult = Invoke-Manager $manager @("install", "--refresh") "manager refresh"
            if ($refreshResult.ExitCode -eq 0) {
                break
            }
        }
        Add-RuntimesFromManagers
        Add-RegistryCandidates
        Add-FileSystemCandidates
        $selected = Get-SelectedCandidate
    }
}

if (-not $selected -and $InstallIfMissing -and $modernManagerPaths.Count -gt 0) {
    Add-Log "AUTOMATIC INSTALL: requesting the standard Python 3.14 runtime."
    foreach ($manager in $modernManagerPaths) {
        $installResult = Invoke-Manager $manager @("install", "3.14") "manager install 3.14"
        if ($installResult.ExitCode -eq 0) {
            break
        }
    }
    Add-RuntimesFromManagers
    Add-RegistryCandidates
    Add-FileSystemCandidates
    $selected = Get-SelectedCandidate
}

Save-DetectionLog

if ($selected) {
    Write-Output $selected.Path
    exit 0
}
exit 1
