"""GUI launcher that preserves startup diagnostics when pythonw has no console."""

from __future__ import annotations

import os
import sys
import traceback
from pathlib import Path


APP_DIR = Path(__file__).resolve().parent
ERROR_LOG = APP_DIR / "run_error.txt"


def _show_startup_error(message: str) -> None:
    try:
        from tkinter import messagebox

        messagebox.showerror("Open NMR Workbench", message)
        return
    except Exception:
        pass
    if os.name == "nt":
        try:
            import ctypes

            ctypes.windll.user32.MessageBoxW(0, message, "Open NMR Workbench", 0x10)
        except Exception:
            pass


def main() -> int:
    try:
        ERROR_LOG.unlink(missing_ok=True)
    except OSError:
        pass
    try:
        os.chdir(APP_DIR)
        from nmr_workbench.ui import launch

        launch()
        return 0
    except Exception:
        details = traceback.format_exc()
        try:
            ERROR_LOG.write_text(details, encoding="utf-8")
        except OSError:
            pass
        _show_startup_error(
            "软件启动失败。请重新运行 install_windows.bat。\n\n"
            f"诊断文件：{ERROR_LOG}"
        )
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
